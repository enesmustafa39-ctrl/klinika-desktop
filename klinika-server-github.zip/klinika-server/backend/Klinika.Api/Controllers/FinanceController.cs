using Klinika.Api.Auth;
using Klinika.Api.Data;
using Klinika.Api.Domain;
using Klinika.Api.Dtos;
using Klinika.Api.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Klinika.Api.Controllers;

/// <summary>Financat: ngarkesat, pagesat, kartela e pacientit dhe lista e debitorëve (kreditë e klientëve).</summary>
[Route("api/finance"), Authorize(Roles = Roles.Finance)]
public class FinanceController : ApiBase
{
    private readonly FinanceService _fin;
    public FinanceController(AppDbContext db, ICurrentUser me, FinanceService fin) : base(db, me) => _fin = fin;

    [HttpGet("statement/{patientId:guid}")]
    public async Task<ActionResult<StatementDto>> Statement(Guid patientId)
    {
        var s = await _fin.StatementAsync(patientId);
        if (s is null) return NotFoundMsg("Pacienti");
        return s;
    }

    /// <summary>Ngarkesat e një pacienti (opsionalisht vetëm të një vizite) – për faturat.</summary>
    [HttpGet("charges")]
    public async Task<List<ChargeDto>> Charges([FromQuery] Guid patientId, [FromQuery] Guid? visitId)
    {
        var q = Db.Charges.AsNoTracking().Where(c => c.PatientId == patientId);
        if (visitId is not null) q = q.Where(c => c.VisitId == visitId);
        return (await q.OrderBy(c => c.Date).ToListAsync()).Select(c => c.ToDto()).ToList();
    }

    [HttpPost("charges")]
    public async Task<ActionResult<ChargeDto>> AddCharge(CreateChargeRequest r)
    {
        if (!await Db.Patients.AnyAsync(p => p.Id == r.PatientId)) return NotFoundMsg("Pacienti");
        if (r.VisitId is { } vid && !await Db.Visits.AnyAsync(v => v.Id == vid && v.PatientId == r.PatientId)) return NotFoundMsg("Vizita");
        ServiceItem? s = r.ServiceItemId is { } sid ? await Db.Services.FirstOrDefaultAsync(x => x.Id == sid) : null;
        var price = r.UnitPrice ?? s?.Price;
        if (price is null) return Fail("Vendosni çmimin ose zgjidhni një shërbim.");
        var desc = r.Description ?? s?.Name;
        if (string.IsNullOrWhiteSpace(desc)) return Fail("Vendosni përshkrimin.");
        var qty = r.Quantity <= 0 ? 1 : r.Quantity;

        var c = new Charge
        {
            PatientId = r.PatientId, VisitId = r.VisitId, ServiceItemId = s?.Id, Description = desc, Quantity = qty,
            UnitPrice = price.Value, Discount = r.Discount, Amount = Math.Max(0, qty * price.Value - r.Discount),
            Date = r.Date?.ToUniversalTime() ?? DateTime.UtcNow, CreatedById = Me.UserId
        };
        Db.Charges.Add(c);
        await Db.SaveChangesAsync();
        return c.ToDto();
    }

    [HttpDelete("charges/{id:guid}"), Authorize(Roles = Roles.Admin)]
    public async Task<IActionResult> DeleteCharge(Guid id)
    {
        var c = await Db.Charges.FirstOrDefaultAsync(x => x.Id == id);
        if (c is null) return NotFoundMsg("Ngarkesa");
        Db.Charges.Remove(c);
        await Db.SaveChangesAsync();
        return NoContent();
    }

    [HttpGet("payments")]
    public async Task<List<PaymentDto>> Payments([FromQuery] DateTime? from, [FromQuery] DateTime? to, [FromQuery] Guid? patientId)
    {
        var q = Db.Payments.AsNoTracking().Include(p => p.Patient).AsQueryable();
        if (patientId is not null) q = q.Where(p => p.PatientId == patientId);
        if (from is not null) q = q.Where(p => p.Date >= from.Value.ToUniversalTime());
        if (to is not null) q = q.Where(p => p.Date < to.Value.ToUniversalTime());
        return (await q.OrderByDescending(p => p.Date).Take(1000).ToListAsync())
            .Select(p => p.ToDto(p.Patient is null ? null : $"{p.Patient.FirstName} {p.Patient.LastName}")).ToList();
    }

    [HttpPost("payments")]
    public async Task<ActionResult<PaymentDto>> AddPayment(CreatePaymentRequest r)
    {
        if (!await Db.Patients.AnyAsync(p => p.Id == r.PatientId)) return NotFoundMsg("Pacienti");
        var p = new Payment
        {
            PatientId = r.PatientId, Amount = r.Amount, Method = r.Method, Date = r.Date?.ToUniversalTime() ?? DateTime.UtcNow,
            Reference = r.Reference, Notes = r.Notes, CreatedById = Me.UserId
        };
        Db.Payments.Add(p);
        await Db.SaveChangesAsync();
        return p.ToDto();
    }

    [HttpDelete("payments/{id:guid}"), Authorize(Roles = Roles.Admin)]
    public async Task<IActionResult> DeletePayment(Guid id)
    {
        var p = await Db.Payments.FirstOrDefaultAsync(x => x.Id == id);
        if (p is null) return NotFoundMsg("Pagesa");
        Db.Payments.Remove(p);
        await Db.SaveChangesAsync();
        return NoContent();
    }

    /// <summary>Lista e klientëve me borxh (balancë pozitive).</summary>
    [HttpGet("debtors")]
    public async Task<List<DebtorDto>> Debtors()
    {
        var rows = await Db.Patients.AsNoTracking().Select(p => new
        {
            p.Id, Name = p.FirstName + " " + p.LastName, p.Phone,
            Charged = Db.Charges.Where(c => c.PatientId == p.Id).Sum(c => (decimal?)c.Amount) ?? 0,
            Paid = Db.Payments.Where(x => x.PatientId == p.Id).Sum(x => (decimal?)x.Amount) ?? 0,
            LastPayment = Db.Payments.Where(x => x.PatientId == p.Id).Max(x => (DateTime?)x.Date)
        }).Where(x => x.Charged - x.Paid > 0).OrderByDescending(x => x.Charged - x.Paid).ToListAsync();

        return rows.Select(x => new DebtorDto(x.Id, x.Name, x.Phone, x.Charged, x.Paid, x.Charged - x.Paid, x.LastPayment)).ToList();
    }
}

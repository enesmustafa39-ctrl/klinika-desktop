using Klinika.Api.Auth;
using Klinika.Api.Data;
using Klinika.Api.Domain;
using Klinika.Api.Dtos;
using Klinika.Api.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;

namespace Klinika.Api.Controllers;

[Route("api/auth")]
public class AuthController : ApiBase
{
    private readonly JwtService _jwt;
    private readonly Passwords _pw;
    private readonly LoginGuard _guard;
    private readonly IMemoryCache _cache;

    public AuthController(AppDbContext db, ICurrentUser me, JwtService jwt, Passwords pw, LoginGuard guard, IMemoryCache cache) : base(db, me)
    { _jwt = jwt; _pw = pw; _guard = guard; _cache = cache; }

    /// <summary>Hyrja për të gjitha rolet (Super Admin, Admin, Staf, Klient).</summary>
    [HttpPost("login"), AllowAnonymous, EnableRateLimiting("login")]
    public async Task<ActionResult<LoginResponse>> Login(LoginRequest r)
    {
        var email = r.Email.Trim().ToLowerInvariant();
        if (_guard.LockedFor(email) is { } wait)
            return Fail($"Shumë prova të gabuara. Provoni përsëri pas {Math.Max(1, (int)Math.Ceiling(wait.TotalMinutes))} minutash.", 429);

        var u = await Db.Users.Include(x => x.Business).FirstOrDefaultAsync(x => x.Email == email);
        if (u is null)
        {
            _pw.VerifyDummy(r.Password);
            _guard.Failed(email);
            return Fail("Email ose fjalëkalim i pasaktë.", 401);
        }
        if (!_pw.VerifyAndUpgrade(u, r.Password))
        {
            _guard.Failed(email);
            return Fail("Email ose fjalëkalim i pasaktë.", 401);
        }
        _guard.Succeeded(email);
        if (!u.IsActive)
            return Fail("Llogaria juaj është çaktivizuar. Kontaktoni administratorin.", 403);
        if (u.Business is { } b && (!b.IsActive || (b.AccessUntil is { } until && until < DateTime.UtcNow)))
            return Fail("Qasja e biznesit është pezulluar ose ka skaduar. Kontaktoni ofruesin e platformës.", 403);
        if (u.Role == UserRole.Klient && u.Business is { } cb && !cb.Has(Features.ClientPortal))
            return Fail("Aplikacioni i klientit nuk është aktiv për këtë klinikë.", 403);

        u.LastLoginAt = DateTime.UtcNow;
        await Db.SaveChangesAsync();

        var (token, exp) = _jwt.Create(u, u.Business, r.RememberMe);
        return new LoginResponse(token, exp, u.ToDto(), u.Business?.ToBrief());
    }

    [HttpGet("me"), Authorize]
    public async Task<ActionResult<LoginResponse>> MeInfo()
    {
        var u = await Db.Users.AsNoTracking().Include(x => x.Business).FirstOrDefaultAsync(x => x.Id == Me.UserId);
        if (u is null) return Unauthorized();
        return new LoginResponse("", DateTime.UtcNow, u.ToDto(), u.Business?.ToBrief());
    }

    /// <summary>
    /// Ndryshimi i fjalëkalimit. Të gjitha seancat e tjera (pajisjet e tjera) mbyllen;
    /// kjo pajisje merr një token të ri që të mos dalë nga llogaria.
    /// </summary>
    [HttpPost("change-password"), Authorize, EnableRateLimiting("login")]
    public async Task<IActionResult> ChangePassword(ChangePasswordRequest r)
    {
        var u = await Db.Users.Include(x => x.Business).FirstOrDefaultAsync(x => x.Id == Me.UserId);
        if (u is null) return Unauthorized();
        if (!_pw.Verify(u, r.CurrentPassword)) return Fail("Fjalëkalimi aktual është i pasaktë.");
        if (r.CurrentPassword == r.NewPassword) return Fail("Fjalëkalimi i ri duhet të jetë i ndryshëm nga ai aktual.");
        _pw.SetPassword(u, r.NewPassword);
        await Db.SaveChangesAsync();
        UserGate.Forget(_cache, u.Id);

        // Ruaj kohëzgjatjen e seancës aktuale (12 orë ose 30 ditë)
        var exp = User.FindFirst("exp")?.Value;
        var remember = long.TryParse(exp, out var unix) && DateTimeOffset.FromUnixTimeSeconds(unix) - DateTimeOffset.UtcNow > TimeSpan.FromDays(1);
        var (token, expires) = _jwt.Create(u, u.Business, remember);
        return Ok(new { message = "Fjalëkalimi u ndryshua me sukses. Pajisjet e tjera u shkëputën.", token, expiresAt = expires });
    }

    /// <summary>Lista e specialiteteve me fushat e kartelës dhe shërbimet fillestare.</summary>
    [HttpGet("/api/specialties"), AllowAnonymous]
    public IEnumerable<SpecialtyDto> Specialties() =>
        SpecialtyCatalog.All.Select(t => new SpecialtyDto(t.Specialty, t.Label, t.DoctorLabel, t.VisitFields, t.Services));
}

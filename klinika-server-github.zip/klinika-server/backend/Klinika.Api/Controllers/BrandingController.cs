using Klinika.Api.Auth;
using Klinika.Api.Data;
using Klinika.Api.Dtos;
using Klinika.Api.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Klinika.Api.Controllers;

/// <summary>
/// Logo dhe foto e sfondit për çdo biznes. Vetëm Super Admini i ngarkon/ndryshon;
/// administratori, stafi dhe pacientët e atij biznesi i shohin.
/// </summary>
public class BrandingController : ApiBase
{
    private const long MaxBytes = 10 * 1024 * 1024; // 10 MB
    // SVG nuk lejohet (mund të përmbajë skripte).
    private static readonly Dictionary<string, string> Allowed = new(StringComparer.OrdinalIgnoreCase)
    {
        [".png"] = "image/png", [".jpg"] = "image/jpeg", [".jpeg"] = "image/jpeg", [".webp"] = "image/webp", [".gif"] = "image/gif",
    };

    private readonly FileStorage _storage;
    public BrandingController(AppDbContext db, ICurrentUser me, FileStorage storage) : base(db, me) => _storage = storage;

    /// <summary>
    /// Publike: emri, logo dhe sfondi i klinikës për faqen e hyrjes (linku /hyrje/{id}).
    /// Kthen vetëm të dhëna që gjithsesi shfaqen publikisht në faqen e hyrjes.
    /// </summary>
    [HttpGet("api/branding/{id:guid}"), AllowAnonymous]
    public async Task<IActionResult> Info(Guid id)
    {
        var b = await Db.Businesses.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id);
        if (b is null) return NotFound();
        Response.Headers.CacheControl = "no-cache";
        return Ok(new { id = b.Id, name = b.Name, logoUrl = b.LogoUrl, backgroundUrl = b.BackgroundUrl });
    }

    /// <summary>Publike (pa hyrje), që logo të shfaqet edhe në faqen e hyrjes. kind = logo | background</summary>
    [HttpGet("api/branding/{id:guid}/{kind}"), AllowAnonymous]
    public async Task<IActionResult> Get(Guid id, string kind)
    {
        var b = await Db.Businesses.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id);
        var rel = kind switch { "logo" => b?.LogoPath, "background" => b?.BackgroundPath, _ => null };
        if (rel is null) return NotFound();
        var full = _storage.FullPath(rel);
        if (!System.IO.File.Exists(full)) return NotFound();
        Response.Headers.CacheControl = "public, max-age=31536000, immutable"; // URL-ja ndryshon me ?v= pas çdo ngarkimi
        return PhysicalFile(full, Allowed.GetValueOrDefault(Path.GetExtension(full), "application/octet-stream"));
    }

    [HttpPost("api/superadmin/businesses/{id:guid}/branding/{kind}"), Authorize(Roles = Roles.SuperAdmin), RequestSizeLimit(12 * 1024 * 1024)]
    public async Task<ActionResult<BusinessBriefDto>> Upload(Guid id, string kind, [FromForm] IFormFile file)
    {
        if (kind is not ("logo" or "background")) return Fail("Lloji duhet të jetë 'logo' ose 'background'.");
        var b = await Db.Businesses.FirstOrDefaultAsync(x => x.Id == id);
        if (b is null) return NotFoundMsg("Biznesi");
        var ext = Path.GetExtension(file.FileName).ToLowerInvariant();
        if (!Allowed.ContainsKey(ext)) return Fail("Lejohen vetëm foto PNG, JPG, WEBP ose GIF.");
        if (file.Length == 0 || file.Length > MaxBytes) return Fail("Foto duhet të jetë deri në 10 MB.");
        if (!await FileStorage.MatchesSignatureAsync(file, ext)) return Fail("Foto nuk është e vlefshme ose është e dëmtuar.");

        var rel = await _storage.SaveAsync(id, file, ext);
        var old = kind == "logo" ? b.LogoPath : b.BackgroundPath;
        if (kind == "logo") b.LogoPath = rel; else b.BackgroundPath = rel;
        b.BrandingUpdatedAt = DateTime.UtcNow;
        await Db.SaveChangesAsync();
        if (old is not null) _storage.Delete(old);
        return b.ToBrief();
    }

    [HttpDelete("api/superadmin/businesses/{id:guid}/branding/{kind}"), Authorize(Roles = Roles.SuperAdmin)]
    public async Task<ActionResult<BusinessBriefDto>> Remove(Guid id, string kind)
    {
        var b = await Db.Businesses.FirstOrDefaultAsync(x => x.Id == id);
        if (b is null) return NotFoundMsg("Biznesi");
        var old = kind == "logo" ? b.LogoPath : b.BackgroundPath;
        if (kind == "logo") b.LogoPath = null; else if (kind == "background") b.BackgroundPath = null; else return Fail("Lloj i panjohur.");
        b.BrandingUpdatedAt = DateTime.UtcNow;
        await Db.SaveChangesAsync();
        if (old is not null) _storage.Delete(old);
        return b.ToBrief();
    }
}

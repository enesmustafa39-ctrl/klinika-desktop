using Klinika.Api.Auth;
using Klinika.Api.Data;
using Klinika.Api.Domain;
using Klinika.Api.Dtos;
using Klinika.Api.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Klinika.Api.Controllers;

/// <summary>
/// Rrezet X & Imazhet e pacientit. Aktiv vetëm për bizneset ku Super Admini ka ndezur funksionin "imaging".
/// </summary>
[Authorize(Roles = Roles.Clinical), RequireFeature(Features.Imaging)]
public class FilesController : ApiBase
{
    private const long MaxBytes = 30 * 1024 * 1024; // 30 MB

    private static readonly Dictionary<string, string> Allowed = new(StringComparer.OrdinalIgnoreCase)
    {
        [".jpg"] = "image/jpeg", [".jpeg"] = "image/jpeg", [".png"] = "image/png", [".webp"] = "image/webp",
        [".gif"] = "image/gif", [".bmp"] = "image/bmp", [".pdf"] = "application/pdf", [".dcm"] = "application/dicom",
    };

    private readonly FileStorage _storage;
    public FilesController(AppDbContext db, ICurrentUser me, FileStorage storage) : base(db, me) => _storage = storage;

    [HttpGet("api/patients/{patientId:guid}/files")]
    public async Task<List<PatientFileDto>> List(Guid patientId, [FromQuery] FileCategory? category)
    {
        var q = Db.PatientFiles.AsNoTracking().Where(f => f.PatientId == patientId);
        if (category is not null) q = q.Where(f => f.Category == category);
        var files = await q.OrderByDescending(f => f.TakenAt).ToListAsync();
        var names = await UploaderNames(files.Select(f => f.UploadedById));
        return files.Select(f => ToDto(f, names)).ToList();
    }

    /// <summary>Ngarko një ose më shumë skedarë (multipart/form-data: files, category, tooth, notes, takenAt, visitId).</summary>
    [HttpPost("api/patients/{patientId:guid}/files"), RequestSizeLimit(160 * 1024 * 1024)]
    public async Task<ActionResult<List<PatientFileDto>>> Upload(Guid patientId, [FromForm] List<IFormFile> files,
        [FromForm] FileCategory category = FileCategory.RrezeX, [FromForm] string? tooth = null, [FromForm] string? notes = null,
        [FromForm] DateTime? takenAt = null, [FromForm] Guid? visitId = null)
    {
        if (!await Db.Patients.AnyAsync(p => p.Id == patientId)) return NotFoundMsg("Pacienti");
        if (files.Count == 0) return Fail("Zgjidhni të paktën një skedar.");
        if (files.Count > 20) return Fail("Mund të ngarkoni maksimumi 20 skedarë njëherësh.");

        foreach (var f in files)
        {
            var ext = Path.GetExtension(f.FileName);
            if (!Allowed.ContainsKey(ext)) return Fail($"Lloji i skedarit \"{f.FileName}\" nuk lejohet. Lejohen: JPG, PNG, WEBP, GIF, BMP, PDF, DICOM.");
            if (f.Length == 0) return Fail($"Skedari \"{f.FileName}\" është bosh.");
            if (f.Length > MaxBytes) return Fail($"Skedari \"{f.FileName}\" është më i madh se 30 MB.");
            if (!await FileStorage.MatchesSignatureAsync(f, ext)) return Fail($"Skedari \"{f.FileName}\" nuk është i vlefshëm ose është i dëmtuar.");
        }
        if (visitId is { } vid && !await Db.Visits.AnyAsync(v => v.Id == vid && v.PatientId == patientId)) return NotFoundMsg("Vizita");

        var saved = new List<PatientFile>();
        foreach (var f in files)
        {
            var ext = Path.GetExtension(f.FileName).ToLowerInvariant();
            var rel = await _storage.SaveAsync(TenantId, f, ext);
            var pf = new PatientFile
            {
                PatientId = patientId, VisitId = visitId, FileName = Path.GetFileName(f.FileName), ContentType = Allowed[ext],
                SizeBytes = f.Length, Category = category, Tooth = tooth?.Trim(), Notes = notes,
                StoragePath = rel, TakenAt = takenAt?.ToUniversalTime() ?? DateTime.UtcNow, UploadedById = Me.UserId
            };
            Db.PatientFiles.Add(pf);
            saved.Add(pf);
        }
        await Db.SaveChangesAsync();
        var names = await UploaderNames(saved.Select(f => f.UploadedById));
        return saved.Select(f => ToDto(f, names)).ToList();
    }

    /// <summary>Përmbajtja e skedarit (për shikuesin). ?download=true për shkarkim.</summary>
    [HttpGet("api/files/{id:guid}/content")]
    public async Task<IActionResult> Content(Guid id, [FromQuery] bool download = false)
    {
        var f = await Db.PatientFiles.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id);
        if (f is null) return NotFoundMsg("Skedari");
        var full = _storage.FullPath(f.StoragePath);
        if (!System.IO.File.Exists(full)) return NotFoundMsg("Skedari në disk");
        Response.Headers.CacheControl = "private, max-age=3600";
        return download
            ? PhysicalFile(full, f.ContentType, Path.GetFileName(f.FileName), enableRangeProcessing: true)
            : PhysicalFile(full, f.ContentType, enableRangeProcessing: true);
    }

    [HttpPut("api/files/{id:guid}")]
    public async Task<ActionResult<PatientFileDto>> Update(Guid id, UpdateFileRequest r)
    {
        var f = await Db.PatientFiles.FirstOrDefaultAsync(x => x.Id == id);
        if (f is null) return NotFoundMsg("Skedari");
        if (r.VisitId is { } vid && !await Db.Visits.AnyAsync(v => v.Id == vid && v.PatientId == f.PatientId)) return NotFoundMsg("Vizita");
        f.Category = r.Category; f.Tooth = r.Tooth?.Trim(); f.Notes = r.Notes; f.VisitId = r.VisitId;
        if (r.TakenAt is { } t) f.TakenAt = t.ToUniversalTime();
        await Db.SaveChangesAsync();
        return ToDto(f, await UploaderNames(new[] { f.UploadedById }));
    }

    [HttpDelete("api/files/{id:guid}"), Authorize(Roles = "Admin,Mjek")]
    public async Task<IActionResult> Delete(Guid id)
    {
        var f = await Db.PatientFiles.FirstOrDefaultAsync(x => x.Id == id);
        if (f is null) return NotFoundMsg("Skedari");
        Db.PatientFiles.Remove(f);
        await Db.SaveChangesAsync();
        _storage.Delete(f.StoragePath);
        return NoContent();
    }

    private async Task<Dictionary<Guid, string>> UploaderNames(IEnumerable<Guid?> ids)
    {
        var list = ids.Where(i => i != null).Select(i => i!.Value).Distinct().ToList();
        return await Db.Users.Where(u => u.BusinessId == TenantId && list.Contains(u.Id)).ToDictionaryAsync(u => u.Id, u => u.FullName);
    }

    private static PatientFileDto ToDto(PatientFile f, Dictionary<Guid, string> names) => new(f.Id, f.PatientId, f.VisitId,
        f.FileName, f.ContentType, f.SizeBytes, f.Category, Labels.FileCategoryLabel(f.Category), f.Tooth, f.Notes, f.TakenAt,
        f.CreatedAt, f.ContentType.StartsWith("image/"),
        f.UploadedById is { } u ? names.GetValueOrDefault(u) : null);
}

using Klinika.Api.Auth;
using Klinika.Api.Data;
using Klinika.Api.Domain;
using Klinika.Api.Dtos;
using Klinika.Api.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;

namespace Klinika.Api.Controllers;

/// <summary>Menaxhimi i stafit të biznesit (vetëm Administratori mund të shtojë/ndryshojë).</summary>
[Route("api/staff"), Authorize(Roles = Roles.Staff)]
public class StaffController : ApiBase
{
    private static readonly UserRole[] StaffRoles = { UserRole.Admin, UserRole.Mjek, UserRole.Infermier, UserRole.Recepsion };
    private readonly Passwords _pw;
    private readonly IMemoryCache _cache;
    public StaffController(AppDbContext db, ICurrentUser me, Passwords pw, IMemoryCache cache) : base(db, me) { _pw = pw; _cache = cache; }

    [HttpGet]
    public async Task<List<UserDto>> List([FromQuery] bool includeInactive = false)
    {
        var q = Db.Users.AsNoTracking().Where(u => u.BusinessId == TenantId && u.Role != UserRole.Klient);
        if (!includeInactive || Me.Role != UserRole.Admin) q = q.Where(u => u.IsActive);
        return (await q.OrderBy(u => u.Role).ThenBy(u => u.FullName).ToListAsync()).Select(u => u.ToDto()).ToList();
    }

    [HttpPost, Authorize(Roles = Roles.Admin)]
    public async Task<ActionResult<UserDto>> Create(CreateStaffRequest r)
    {
        if (!StaffRoles.Contains(r.Role)) return Fail("Roli i zgjedhur nuk lejohet për stafin.");
        var biz = await Db.Businesses.FirstAsync(b => b.Id == TenantId);
        var count = await Db.Users.CountAsync(u => u.BusinessId == TenantId && u.Role != UserRole.Klient && u.IsActive);
        if (count >= biz.MaxStaff) return Fail($"Keni arritur limitin e stafit ({biz.MaxStaff}). Kontaktoni ofruesin.");

        var email = r.Email.Trim().ToLowerInvariant();
        if (await Db.Users.AnyAsync(u => u.Email == email)) return Fail("Ky email përdoret tashmë.");

        var u = new User { BusinessId = TenantId, FullName = r.FullName.Trim(), Email = email, Phone = r.Phone, Role = r.Role, Title = r.Title };
        u.PasswordHash = _pw.Hash(u, r.Password);
        Db.Users.Add(u);
        await Db.SaveChangesAsync();
        return u.ToDto();
    }

    [HttpPut("{id:guid}"), Authorize(Roles = Roles.Admin)]
    public async Task<ActionResult<UserDto>> Update(Guid id, UpdateStaffRequest r)
    {
        var u = await Db.Users.FirstOrDefaultAsync(x => x.Id == id && x.BusinessId == TenantId && x.Role != UserRole.Klient);
        if (u is null) return NotFoundMsg("Anëtari i stafit");
        if (!StaffRoles.Contains(r.Role)) return Fail("Roli i zgjedhur nuk lejohet.");
        if (u.Id == Me.UserId && (!r.IsActive || r.Role != UserRole.Admin))
            return Fail("Nuk mund ta çaktivizoni ose t'i hiqni rolin e administratorit vetes.");
        // Ndryshimi i rolit ose çaktivizimi e nxjerr menjëherë nga të gjitha pajisjet.
        if (u.Role != r.Role || u.IsActive != r.IsActive) u.TokenVersion++;
        u.FullName = r.FullName.Trim(); u.Phone = r.Phone; u.Role = r.Role; u.Title = r.Title; u.IsActive = r.IsActive;
        await Db.SaveChangesAsync();
        UserGate.Forget(_cache, u.Id);
        return u.ToDto();
    }

    [HttpPost("{id:guid}/reset-password"), Authorize(Roles = Roles.Admin)]
    public async Task<IActionResult> ResetPassword(Guid id, ResetPasswordRequest r)
    {
        var u = await Db.Users.FirstOrDefaultAsync(x => x.Id == id && x.BusinessId == TenantId);
        if (u is null) return NotFoundMsg("Përdoruesi");
        _pw.SetPassword(u, r.NewPassword);
        await Db.SaveChangesAsync();
        UserGate.Forget(_cache, u.Id);
        return Ok(new { message = "Fjalëkalimi u rivendos." });
    }

    /// <summary>Informacioni i biznesit aktual (për stafin).</summary>
    [HttpGet("/api/business")]
    public async Task<IActionResult> Business()
    {
        var b = await Db.Businesses.AsNoTracking().FirstAsync(x => x.Id == TenantId);
        return Ok(new { business = b.ToBrief(), b.Address, b.City, b.Phone, b.Email, b.NIPT, b.InvoiceFooter, b.TimeZone,
            visitFields = BusinessConfig.VisitFields(b) });
    }
}

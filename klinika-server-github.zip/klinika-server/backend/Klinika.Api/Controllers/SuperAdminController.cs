using Klinika.Api.Auth;
using Klinika.Api.Data;
using Klinika.Api.Domain;
using Klinika.Api.Dtos;
using Klinika.Api.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;

namespace Klinika.Api.Controllers;

/// <summary>Moduli i Super Adminit: regjistrimi dhe menaxhimi i bizneseve (klinikave).</summary>
[Route("api/superadmin"), Authorize(Roles = Roles.SuperAdmin)]
public class SuperAdminController : ApiBase
{
    private readonly Provisioning _prov;
    private readonly Passwords _pw;
    private readonly FileStorage _storage;
    private readonly IMemoryCache _cache;

    public SuperAdminController(AppDbContext db, ICurrentUser me, Provisioning prov, Passwords pw, FileStorage storage, IMemoryCache cache) : base(db, me)
    { _prov = prov; _pw = pw; _storage = storage; _cache = cache; }

    /// <summary>Katalogu i funksioneve shtesë që mund të aktivizohen për çdo biznes veçmas.</summary>
    [HttpGet("features")]
    public IEnumerable<FeatureInfo> FeatureCatalog() => Features.All;

    /// <summary>
    /// Aktivizo/çaktivizo funksionet dhe fushat e personalizuara VETËM për këtë biznes.
    /// Bizneset e tjera (edhe me të njëjtin specialitet) nuk preken.
    /// </summary>
    [HttpPut("businesses/{id:guid}/features")]
    public async Task<ActionResult<BusinessDto>> UpdateFeatures(Guid id, UpdateFeaturesRequest r)
    {
        var b = await Db.Businesses.FindAsync(id);
        if (b is null) return NotFoundMsg("Biznesi");

        var unknown = r.Features.Where(f => !Features.IsKnown(f)).ToList();
        if (unknown.Count > 0) return Fail($"Funksion i panjohur: {string.Join(", ", unknown)}");

        var custom = new List<FieldDef>();
        var reserved = SpecialtyCatalog.Get(b.Specialty).VisitFields.Select(f => f.Key).ToHashSet();
        foreach (var f in r.CustomFields ?? new())
        {
            if (string.IsNullOrWhiteSpace(f.Label)) continue;
            var key = string.IsNullOrWhiteSpace(f.Key) ? Slug(f.Label) : Slug(f.Key);
            if (reserved.Contains(key) || custom.Any(c => c.Key == key)) key = $"{key}_{custom.Count + 1}";
            var type = f.Type is "text" or "number" or "select" or "date" ? f.Type : "text";
            var options = type == "select" ? f.Options?.Where(o => !string.IsNullOrWhiteSpace(o)).Select(o => o.Trim()).ToArray() : null;
            if (type == "select" && (options is null || options.Length == 0)) return Fail($"Fusha \"{f.Label}\" është listë, por nuk ka opsione.");
            custom.Add(new FieldDef(key, f.Label.Trim(), type, options));
        }

        b.Features = r.Features.Distinct().ToList();
        b.CustomFieldsJson = BusinessConfig.SerializeCustomFields(custom);
        await Db.SaveChangesAsync();
        UserGate.ForgetBusiness(_cache, b.Id);
        return (await ToDtos(new() { b }))[0];
    }

    private static string Slug(string s)
    {
        var map = new Dictionary<char, string> { ['ë'] = "e", ['ç'] = "c", ['Ë'] = "e", ['Ç'] = "c" };
        var chars = s.Trim().ToLowerInvariant().Select(c => map.TryGetValue(c, out var r) ? r : char.IsLetterOrDigit(c) ? c.ToString() : "_");
        var slug = string.Join("", chars).Trim('_');
        while (slug.Contains("__")) slug = slug.Replace("__", "_");
        return "x_" + (slug.Length == 0 ? "fushe" : slug[..Math.Min(slug.Length, 40)]);
    }

    [HttpGet("stats")]
    public async Task<PlatformStatsDto> Stats()
    {
        var biz = await Db.Businesses.AsNoTracking().ToListAsync();
        return new PlatformStatsDto(
            biz.Count, biz.Count(b => b.IsActive),
            await Db.Users.CountAsync(u => u.Role != UserRole.SuperAdmin && u.Role != UserRole.Klient),
            await Db.Patients.IgnoreQueryFilters().CountAsync(),
            biz.GroupBy(b => SpecialtyCatalog.Get(b.Specialty).Label).ToDictionary(g => g.Key, g => g.Count()));
    }

    [HttpGet("businesses")]
    public async Task<List<BusinessDto>> List([FromQuery] string? q, [FromQuery] Specialty? specialty, [FromQuery] bool? active)
    {
        var query = Db.Businesses.AsNoTracking().AsQueryable();
        if (!string.IsNullOrWhiteSpace(q))
        {
            var s = q.Trim().ToLower();
            // Kërkim edhe sipas email-it të administratorit/stafit (p.sh. "admin@kardiocenter.com")
            var byEmail = Db.Users.Where(u => u.BusinessId != null && u.Role != UserRole.Klient && u.Email.Contains(s))
                .Select(u => u.BusinessId!.Value);
            query = query.Where(b => b.Name.ToLower().Contains(s) || (b.City != null && b.City.ToLower().Contains(s))
                || (b.NIPT != null && b.NIPT.ToLower().Contains(s)) || (b.Email != null && b.Email.ToLower().Contains(s))
                || byEmail.Contains(b.Id));
        }
        if (specialty is not null) query = query.Where(b => b.Specialty == specialty);
        if (active is not null) query = query.Where(b => b.IsActive == active);

        var list = await query.OrderByDescending(b => b.CreatedAt).ToListAsync();
        return await ToDtos(list);
    }

    [HttpGet("businesses/{id:guid}")]
    public async Task<ActionResult<BusinessDto>> Get(Guid id)
    {
        var b = await Db.Businesses.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id);
        if (b is null) return NotFoundMsg("Biznesi");
        return (await ToDtos(new() { b }))[0];
    }

    /// <summary>Regjistro biznes të ri: zgjidh specialitetin (p.sh. Mjek Familjeje) dhe krijo llogarinë e administratorit.</summary>
    [HttpPost("businesses")]
    public async Task<ActionResult<BusinessDto>> Create(CreateBusinessRequest r)
    {
        var b = await _prov.CreateBusinessAsync(r);
        return CreatedAtAction(nameof(Get), new { id = b.Id }, (await ToDtos(new() { b }))[0]);
    }

    [HttpPut("businesses/{id:guid}")]
    public async Task<ActionResult<BusinessDto>> Update(Guid id, UpdateBusinessRequest r)
    {
        var b = await Db.Businesses.FindAsync(id);
        if (b is null) return NotFoundMsg("Biznesi");
        b.Name = r.Name.Trim(); b.Specialty = r.Specialty; b.NIPT = r.NIPT; b.Address = r.Address; b.City = r.City;
        b.Phone = r.Phone; b.Email = r.Email; b.Currency = string.IsNullOrWhiteSpace(r.Currency) ? b.Currency : r.Currency!.ToUpperInvariant();
        b.AccessUntil = r.AccessUntil; b.MaxStaff = r.MaxStaff ?? b.MaxStaff; b.Notes = r.Notes;
        await Db.SaveChangesAsync();
        return (await ToDtos(new() { b }))[0];
    }

    /// <summary>Jep ose pezullo qasjen e biznesit.</summary>
    [HttpPost("businesses/{id:guid}/access")]
    public async Task<IActionResult> SetAccess(Guid id, SetAccessRequest r)
    {
        var b = await Db.Businesses.FindAsync(id);
        if (b is null) return NotFoundMsg("Biznesi");
        b.IsActive = r.IsActive; b.AccessUntil = r.AccessUntil;
        await Db.SaveChangesAsync();
        UserGate.ForgetBusiness(_cache, b.Id);
        return Ok(new { message = r.IsActive ? "Qasja u aktivizua." : "Qasja u pezullua." });
    }

    [HttpGet("businesses/{id:guid}/users")]
    public async Task<List<UserDto>> Users(Guid id) =>
        (await Db.Users.AsNoTracking().Where(u => u.BusinessId == id && u.Role != UserRole.Klient)
            .OrderBy(u => u.Role).ThenBy(u => u.FullName).ToListAsync()).Select(u => u.ToDto()).ToList();

    [HttpPost("users/{userId:guid}/reset-password")]
    public async Task<IActionResult> ResetPassword(Guid userId, ResetPasswordRequest r)
    {
        var u = await Db.Users.FindAsync(userId);
        if (u is null) return NotFoundMsg("Përdoruesi");
        _pw.SetPassword(u, r.NewPassword);
        await Db.SaveChangesAsync();
        UserGate.Forget(_cache, u.Id);
        return Ok(new { message = "Fjalëkalimi u rivendos." });
    }

    /// <summary>Fshin përgjithmonë biznesin me të gjitha të dhënat. Kërkon ?confirm=EMRI_I_BIZNESIT.</summary>
    [HttpDelete("businesses/{id:guid}")]
    public async Task<IActionResult> Delete(Guid id, [FromQuery] string confirm)
    {
        var b = await Db.Businesses.FindAsync(id);
        if (b is null) return NotFoundMsg("Biznesi");
        if (confirm != b.Name) return Fail("Për konfirmim shkruani saktë emrin e biznesit.");
        await Db.PatientFiles.IgnoreQueryFilters().Where(x => x.BusinessId == id).ExecuteDeleteAsync();
        var dir = _storage.FullPath(id.ToString("N"));
        if (Directory.Exists(dir)) Directory.Delete(dir, recursive: true);
        await Db.Appointments.IgnoreQueryFilters().Where(x => x.BusinessId == id).ExecuteDeleteAsync();
        await Db.Payments.IgnoreQueryFilters().Where(x => x.BusinessId == id).ExecuteDeleteAsync();
        await Db.Charges.IgnoreQueryFilters().Where(x => x.BusinessId == id).ExecuteDeleteAsync();
        await Db.Visits.IgnoreQueryFilters().Where(x => x.BusinessId == id).ExecuteDeleteAsync();
        await Db.Patients.IgnoreQueryFilters().Where(x => x.BusinessId == id).ExecuteDeleteAsync();
        await Db.Services.IgnoreQueryFilters().Where(x => x.BusinessId == id).ExecuteDeleteAsync();
        await Db.Users.Where(x => x.BusinessId == id).ExecuteDeleteAsync();
        Db.Businesses.Remove(b);
        await Db.SaveChangesAsync();
        return NoContent();
    }

    private async Task<List<BusinessDto>> ToDtos(List<Business> list)
    {
        var ids = list.Select(b => b.Id).ToList();
        var staff = await Db.Users.Where(u => u.BusinessId != null && ids.Contains(u.BusinessId.Value) && u.Role != UserRole.Klient)
            .GroupBy(u => u.BusinessId!.Value).Select(g => new { g.Key, C = g.Count() }).ToDictionaryAsync(x => x.Key, x => x.C);
        var patients = await Db.Patients.IgnoreQueryFilters().Where(p => ids.Contains(p.BusinessId))
            .GroupBy(p => p.BusinessId).Select(g => new { g.Key, C = g.Count() }).ToDictionaryAsync(x => x.Key, x => x.C);
        var admins = (await Db.Users.Where(u => u.BusinessId != null && ids.Contains(u.BusinessId.Value) && u.Role == UserRole.Admin)
            .OrderBy(u => u.CreatedAt).Select(u => new { Bid = u.BusinessId!.Value, u.Email }).ToListAsync())
            .GroupBy(x => x.Bid).ToDictionary(g => g.Key, g => g.First().Email);

        return list.Select(b => new BusinessDto(b.Id, b.Name, b.Specialty, SpecialtyCatalog.Get(b.Specialty).Label, b.NIPT,
            b.Address, b.City, b.Phone, b.Email, b.Currency, b.IsActive, b.AccessUntil, b.MaxStaff, b.Notes, b.CreatedAt,
            staff.GetValueOrDefault(b.Id), patients.GetValueOrDefault(b.Id), b.Features, BusinessConfig.CustomFields(b),
            admins.GetValueOrDefault(b.Id), b.LogoUrl, b.BackgroundUrl)).ToList();
    }
}

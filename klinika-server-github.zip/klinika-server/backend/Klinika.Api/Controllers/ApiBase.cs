using Klinika.Api.Auth;
using Klinika.Api.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Klinika.Api.Controllers;

[ApiController]
[Produces("application/json")]
public abstract class ApiBase : ControllerBase
{
    protected readonly AppDbContext Db;
    protected readonly ICurrentUser Me;

    protected ApiBase(AppDbContext db, ICurrentUser me) { Db = db; Me = me; }

    protected Guid TenantId => Me.BusinessId ?? throw new AppException("Llogaria nuk i përket asnjë biznesi.", 403);

    protected ObjectResult Fail(string message, int status = 400) => StatusCode(status, new { message });

    /// <summary>A është ky përdorues anëtar i stafit të biznesit aktual? (për DoctorId / StaffId nga kërkesa)</summary>
    protected Task<bool> IsOwnStaff(Guid userId) => Db.Users.AnyAsync(u =>
        u.Id == userId && u.BusinessId == TenantId && u.Role != Domain.UserRole.Klient && u.Role != Domain.UserRole.SuperAdmin);

    /// <summary>Emrat e stafit vetëm nga biznesi aktual.</summary>
    protected async Task<Dictionary<Guid, string>> StaffNames(IEnumerable<Guid> ids)
    {
        var list = ids.Distinct().ToList();
        if (list.Count == 0) return new();
        return await Db.Users.Where(u => u.BusinessId == TenantId && list.Contains(u.Id)).ToDictionaryAsync(u => u.Id, u => u.FullName);
    }
    protected ObjectResult NotFoundMsg(string what = "Rekordi") => StatusCode(404, new { message = $"{what} nuk u gjet." });
}

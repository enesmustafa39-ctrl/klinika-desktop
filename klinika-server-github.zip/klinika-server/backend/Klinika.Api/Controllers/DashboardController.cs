using Klinika.Api.Auth;
using Klinika.Api.Data;
using Klinika.Api.Domain;
using Klinika.Api.Dtos;
using Klinika.Api.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Klinika.Api.Controllers;

[Route("api/dashboard"), Authorize(Roles = Roles.Staff)]
public class DashboardController : ApiBase
{
    public DashboardController(AppDbContext db, ICurrentUser me) : base(db, me) { }

    [HttpGet]
    public async Task<DashboardDto> Get()
    {
        var now = DateTime.UtcNow;
        var today = now.Date;
        var month = new DateTime(now.Year, now.Month, 1, 0, 0, 0, DateTimeKind.Utc);
        var sixAgo = month.AddMonths(-5);

        var charged = await Db.Charges.SumAsync(c => (decimal?)c.Amount) ?? 0;
        var paid = await Db.Payments.SumAsync(p => (decimal?)p.Amount) ?? 0;
        var debtors = await Db.Patients.CountAsync(p =>
            (Db.Charges.Where(c => c.PatientId == p.Id).Sum(c => (decimal?)c.Amount) ?? 0)
            > (Db.Payments.Where(x => x.PatientId == p.Id).Sum(x => (decimal?)x.Amount) ?? 0));

        var upcoming = await Db.Appointments.AsNoTracking().Include(a => a.Patient).Include(a => a.Staff)
            .Where(a => a.StartsAt >= today && a.StartsAt < today.AddDays(1) && a.Status != AppointmentStatus.Anuluar)
            .OrderBy(a => a.StartsAt).ToListAsync();

        var ch6 = await Db.Charges.Where(c => c.Date >= sixAgo).GroupBy(c => new { c.Date.Year, c.Date.Month })
            .Select(g => new { g.Key.Year, g.Key.Month, S = g.Sum(c => c.Amount) }).ToListAsync();
        var pa6 = await Db.Payments.Where(c => c.Date >= sixAgo).GroupBy(c => new { c.Date.Year, c.Date.Month })
            .Select(g => new { g.Key.Year, g.Key.Month, S = g.Sum(c => c.Amount) }).ToListAsync();
        var series = Enumerable.Range(0, 6).Select(i => sixAgo.AddMonths(i)).Select(m => new MonthPoint(
            $"{Labels.Months[m.Month - 1]} {m:yy}",
            ch6.FirstOrDefault(x => x.Year == m.Year && x.Month == m.Month)?.S ?? 0,
            pa6.FirstOrDefault(x => x.Year == m.Year && x.Month == m.Month)?.S ?? 0)).ToList();

        return new DashboardDto(
            await Db.Patients.CountAsync(p => !p.IsArchived),
            await Db.Patients.CountAsync(p => p.CreatedAt >= month),
            await Db.Visits.CountAsync(v => v.VisitDate >= today && v.VisitDate < today.AddDays(1)),
            await Db.Visits.CountAsync(v => v.VisitDate >= month),
            upcoming.Count,
            await Db.Payments.Where(p => p.Date >= month).SumAsync(p => (decimal?)p.Amount) ?? 0,
            await Db.Charges.Where(p => p.Date >= month).SumAsync(p => (decimal?)p.Amount) ?? 0,
            charged - paid, debtors,
            upcoming.Select(a => a.ToDto()).ToList(), series);
    }
}

using Klinika.Api.Auth;
using Klinika.Api.Data;
using Klinika.Api.Domain;
using Klinika.Api.Dtos;
using Klinika.Api.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;

namespace Klinika.Api.Controllers;

/// <summary>Kartela e pacientëve / klientëve.</summary>
[Route("api/patients"), Authorize(Roles = Roles.Staff)]
public class PatientsController : ApiBase
{
    private readonly Passwords _pw;
    private readonly IMemoryCache _cache;
    public PatientsController(AppDbContext db, ICurrentUser me, Passwords pw, IMemoryCache cache) : base(db, me) { _pw = pw; _cache = cache; }

    [HttpGet]
    public async Task<PagedResult<PatientDto>> List([FromQuery] string? q, [FromQuery] bool archived = false,
        [FromQuery] bool debtorsOnly = false, [FromQuery] int page = 1, [FromQuery] int pageSize = 25)
    {
        pageSize = Math.Clamp(pageSize, 1, 200);
        var query = Db.Patients.AsNoTracking().Where(p => p.IsArchived == archived);
        if (!string.IsNullOrWhiteSpace(q))
        {
            var s = q.Trim().ToLower();
            query = query.Where(p => (p.FirstName + " " + p.LastName).ToLower().Contains(s)
                || (p.Phone != null && p.Phone.Contains(s)) || (p.PersonalNumber != null && p.PersonalNumber.ToLower().Contains(s)));
        }

        var projected = Project(query);
        if (debtorsOnly) projected = projected.Where(x => x.Balance > 0);

        var total = await projected.CountAsync();
        var rows = await projected.OrderBy(x => x.P.LastName).ThenBy(x => x.P.FirstName)
            .Skip((page - 1) * pageSize).Take(pageSize).ToListAsync();
        var portal = await PortalSet(rows.Select(r => r.P.Id));
        return new(rows.Select(r => ToDto(r.P, r.Balance, portal.Contains(r.P.Id), r.LastVisit)).ToList(), total, page, pageSize);
    }

    [HttpGet("{id:guid}")]
    public async Task<ActionResult<PatientDto>> Get(Guid id)
    {
        var r = await Project(Db.Patients.AsNoTracking().Where(p => p.Id == id)).FirstOrDefaultAsync();
        if (r is null) return NotFoundMsg("Pacienti");
        var portal = await PortalSet(new[] { id });
        return ToDto(r.P, r.Balance, portal.Contains(id), r.LastVisit);
    }

    [HttpPost]
    public async Task<ActionResult<PatientDto>> Create(PatientUpsert r)
    {
        if (!string.IsNullOrWhiteSpace(r.PersonalNumber) && await Db.Patients.AnyAsync(p => p.PersonalNumber == r.PersonalNumber))
            return Fail("Ekziston tashmë një pacient me këtë numër personal.");
        var p = new Patient();
        Apply(p, r);
        Db.Patients.Add(p);
        await Db.SaveChangesAsync();
        return ToDto(p, 0, false, null);
    }

    [HttpPut("{id:guid}")]
    public async Task<ActionResult<PatientDto>> Update(Guid id, PatientUpsert r)
    {
        var p = await Db.Patients.FirstOrDefaultAsync(x => x.Id == id);
        if (p is null) return NotFoundMsg("Pacienti");
        Apply(p, r);
        await Db.SaveChangesAsync();
        return await Get(id);
    }

    /// <summary>Arkivo / rikthe pacientin (nuk fshihet historiku).</summary>
    [HttpPost("{id:guid}/archive")]
    public async Task<IActionResult> Archive(Guid id, [FromQuery] bool archived = true)
    {
        var p = await Db.Patients.FirstOrDefaultAsync(x => x.Id == id);
        if (p is null) return NotFoundMsg("Pacienti");
        p.IsArchived = archived;
        await Db.SaveChangesAsync();
        return Ok(new { message = archived ? "Pacienti u arkivua." : "Pacienti u rikthye." });
    }

    /// <summary>Krijo ose përditëso qasjen e pacientit në aplikacionin mobil (Moduli i Klientit).</summary>
    [HttpPost("{id:guid}/portal-access"), Authorize(Roles = "Admin,Recepsion"), RequireFeature(Features.ClientPortal)]
    public async Task<IActionResult> PortalAccess(Guid id, PortalAccessRequest r)
    {
        var p = await Db.Patients.FirstOrDefaultAsync(x => x.Id == id);
        if (p is null) return NotFoundMsg("Pacienti");
        var email = r.Email.Trim().ToLowerInvariant();

        var u = await Db.Users.FirstOrDefaultAsync(x => x.PatientId == id && x.Role == UserRole.Klient);
        if (await Db.Users.AnyAsync(x => x.Email == email && (u == null || x.Id != u.Id)))
            return Fail("Ky email përdoret tashmë nga një llogari tjetër.");

        if (u is null)
        {
            u = new User { BusinessId = TenantId, PatientId = id, Role = UserRole.Klient };
            Db.Users.Add(u);
        }
        u.FullName = $"{p.FirstName} {p.LastName}"; u.Email = email; u.IsActive = true;
        _pw.SetPassword(u, r.Password);
        p.Email ??= email;
        await Db.SaveChangesAsync();
        UserGate.Forget(_cache, u.Id);
        return Ok(new { message = "Qasja e klientit u krijua. Pacienti mund të hyjë në aplikacionin mobil." });
    }

    [HttpDelete("{id:guid}/portal-access"), Authorize(Roles = "Admin,Recepsion")]
    public async Task<IActionResult> RevokePortal(Guid id)
    {
        var u = await Db.Users.FirstOrDefaultAsync(x => x.PatientId == id && x.Role == UserRole.Klient && x.BusinessId == TenantId);
        if (u is not null) { u.IsActive = false; u.TokenVersion++; await Db.SaveChangesAsync(); UserGate.Forget(_cache, u.Id); }
        return Ok(new { message = "Qasja e klientit u çaktivizua." });
    }

    // ---- helpers ----
    private class Row
    {
        public Patient P { get; init; } = null!;
        public decimal Balance { get; init; }
        public DateTime? LastVisit { get; init; }
    }

    private IQueryable<Row> Project(IQueryable<Patient> q) => q.Select(p => new Row
    {
        P = p,
        Balance = (Db.Charges.Where(c => c.PatientId == p.Id).Sum(c => (decimal?)c.Amount) ?? 0)
        - (Db.Payments.Where(x => x.PatientId == p.Id).Sum(x => (decimal?)x.Amount) ?? 0),
        LastVisit = Db.Visits.Where(v => v.PatientId == p.Id).Max(v => (DateTime?)v.VisitDate)
    });

    private async Task<HashSet<Guid>> PortalSet(IEnumerable<Guid> ids)
    {
        var list = ids.ToList();
        return (await Db.Users.Where(u => u.Role == UserRole.Klient && u.IsActive && u.PatientId != null && list.Contains(u.PatientId.Value))
            .Select(u => u.PatientId!.Value).ToListAsync()).ToHashSet();
    }

    private static void Apply(Patient p, PatientUpsert r)
    {
        p.FirstName = r.FirstName.Trim(); p.LastName = r.LastName.Trim(); p.PersonalNumber = r.PersonalNumber?.Trim();
        p.BirthDate = r.BirthDate; p.Gender = r.Gender; p.Phone = r.Phone; p.Email = r.Email; p.Address = r.Address;
        p.BloodType = r.BloodType; p.Allergies = r.Allergies; p.ChronicConditions = r.ChronicConditions; p.Notes = r.Notes;
    }

    private static PatientDto ToDto(Patient p, decimal balance, bool portal, DateTime? lastVisit) => new(p.Id, p.FirstName, p.LastName,
        $"{p.FirstName} {p.LastName}", p.PersonalNumber, p.BirthDate, Mapping.Age(p.BirthDate), p.Gender, p.Phone, p.Email,
        p.Address, p.BloodType, p.Allergies, p.ChronicConditions, p.Notes, p.IsArchived, p.CreatedAt, balance, portal, lastVisit);
}

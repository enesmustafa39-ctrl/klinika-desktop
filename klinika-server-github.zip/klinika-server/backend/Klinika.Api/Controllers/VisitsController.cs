using System.Text.Json;
using Klinika.Api.Auth;
using Klinika.Api.Data;
using Klinika.Api.Domain;
using Klinika.Api.Dtos;
using Klinika.Api.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Klinika.Api.Controllers;

/// <summary>Historiku mjekësor i klientëve (vizitat). Vetëm stafi klinik.</summary>
[Route("api/visits"), Authorize(Roles = Roles.Clinical)]
public class VisitsController : ApiBase
{
    public VisitsController(AppDbContext db, ICurrentUser me) : base(db, me) { }

    [HttpGet]
    public async Task<List<VisitDto>> List([FromQuery] Guid? patientId, [FromQuery] DateTime? from, [FromQuery] DateTime? to,
        [FromQuery] Guid? doctorId, [FromQuery] int take = 100)
    {
        var q = Db.Visits.AsNoTracking().Include(v => v.Patient).Include(v => v.Doctor).AsQueryable();
        if (patientId is not null) q = q.Where(v => v.PatientId == patientId);
        if (doctorId is not null) q = q.Where(v => v.DoctorId == doctorId);
        if (from is not null) q = q.Where(v => v.VisitDate >= from.Value.ToUniversalTime());
        if (to is not null) q = q.Where(v => v.VisitDate < to.Value.ToUniversalTime());
        var visits = await q.OrderByDescending(v => v.VisitDate).Take(Math.Clamp(take, 1, 500)).ToListAsync();
        var sums = await ChargeSums(visits.Select(v => v.Id));
        return visits.Select(v => v.ToDto(sums.GetValueOrDefault(v.Id))).ToList();
    }

    [HttpGet("{id:guid}")]
    public async Task<ActionResult<VisitDto>> Get(Guid id)
    {
        var v = await Db.Visits.AsNoTracking().Include(x => x.Patient).Include(x => x.Doctor).FirstOrDefaultAsync(x => x.Id == id);
        if (v is null) return NotFoundMsg("Vizita");
        var sums = await ChargeSums(new[] { id });
        return v.ToDto(sums.GetValueOrDefault(id));
    }

    /// <summary>Regjistro vizitë të re. Opsionalisht shto ngarkesat (shërbimet e kryera) që kalojnë në borxhin e pacientit.</summary>
    [HttpPost]
    public async Task<ActionResult<VisitDto>> Create(VisitUpsert r)
    {
        if (r.DoctorId is { } d && !await IsOwnStaff(d)) return NotFoundMsg("Mjeku");
        if (!await Db.Patients.AnyAsync(p => p.Id == r.PatientId)) return NotFoundMsg("Pacienti");
        var v = new Visit { PatientId = r.PatientId };
        Apply(v, r);
        v.DoctorId ??= Me.Role == UserRole.Mjek || Me.Role == UserRole.Admin ? Me.UserId : null;
        Db.Visits.Add(v);

        if (r.Charges is { Count: > 0 })
        {
            var ids = r.Charges.Where(c => c.ServiceItemId != null).Select(c => c.ServiceItemId!.Value).ToList();
            var services = await Db.Services.Where(s => ids.Contains(s.Id)).ToDictionaryAsync(s => s.Id);
            foreach (var line in r.Charges)
            {
                ServiceItem? s = line.ServiceItemId is { } sid ? services.GetValueOrDefault(sid) : null;
                var price = line.UnitPrice ?? s?.Price ?? 0;
                var qty = line.Quantity <= 0 ? 1 : line.Quantity;
                Db.Charges.Add(new Charge
                {
                    PatientId = r.PatientId, VisitId = v.Id, ServiceItemId = s?.Id,
                    Description = line.Description ?? s?.Name ?? "Shërbim", Quantity = qty, UnitPrice = price,
                    Discount = line.Discount, Amount = Math.Max(0, qty * price - line.Discount), Date = v.VisitDate,
                    CreatedById = Me.UserId
                });
            }
        }
        await Db.SaveChangesAsync();
        return await Get(v.Id);
    }

    [HttpPut("{id:guid}")]
    public async Task<ActionResult<VisitDto>> Update(Guid id, VisitUpsert r)
    {
        if (r.DoctorId is { } d && !await IsOwnStaff(d)) return NotFoundMsg("Mjeku");
        var v = await Db.Visits.FirstOrDefaultAsync(x => x.Id == id);
        if (v is null) return NotFoundMsg("Vizita");
        Apply(v, r);
        await Db.SaveChangesAsync();
        return await Get(id);
    }

    [HttpDelete("{id:guid}"), Authorize(Roles = "Admin,Mjek")]
    public async Task<IActionResult> Delete(Guid id)
    {
        var v = await Db.Visits.FirstOrDefaultAsync(x => x.Id == id);
        if (v is null) return NotFoundMsg("Vizita");
        // Ngarkesat e lidhura mbeten në llogari, por shkëputen nga vizita.
        await Db.Charges.Where(c => c.VisitId == id).ExecuteUpdateAsync(s => s.SetProperty(c => c.VisitId, (Guid?)null));
        Db.Visits.Remove(v);
        await Db.SaveChangesAsync();
        return NoContent();
    }

    private static void Apply(Visit v, VisitUpsert r)
    {
        v.DoctorId = r.DoctorId ?? v.DoctorId;
        v.VisitDate = r.VisitDate?.ToUniversalTime() ?? v.VisitDate;
        v.Complaint = r.Complaint; v.Diagnosis = r.Diagnosis; v.Treatment = r.Treatment; v.Prescription = r.Prescription;
        v.Notes = r.Notes; v.NextVisitDate = r.NextVisitDate;
        v.FieldsJson = JsonSerializer.Serialize(r.Fields ?? new());
    }

    private async Task<Dictionary<Guid, decimal>> ChargeSums(IEnumerable<Guid> ids)
    {
        var list = ids.ToList();
        return await Db.Charges.Where(c => c.VisitId != null && list.Contains(c.VisitId.Value))
            .GroupBy(c => c.VisitId!.Value).Select(g => new { g.Key, S = g.Sum(c => c.Amount) })
            .ToDictionaryAsync(x => x.Key, x => x.S);
    }
}

using Klinika.Api.Auth;
using Klinika.Api.Data;
using Klinika.Api.Domain;
using Klinika.Api.Dtos;
using Klinika.Api.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Klinika.Api.Controllers;

/// <summary>Moduli i Klientit (aplikacioni mobil): pacienti sheh VETËM të dhënat e veta.</summary>
[Route("api/me"), Authorize(Roles = Roles.Client)]
public class ClientController : ApiBase
{
    private readonly FinanceService _fin;
    public ClientController(AppDbContext db, ICurrentUser me, FinanceService fin) : base(db, me) => _fin = fin;

    private Guid PatientId => Me.PatientId ?? throw new AppException("Llogaria nuk është e lidhur me një pacient.", 403);

    [HttpGet("profile")]
    public async Task<IActionResult> Profile()
    {
        var p = await Db.Patients.AsNoTracking().FirstOrDefaultAsync(x => x.Id == PatientId);
        if (p is null) return NotFoundMsg("Profili");
        var b = await Db.Businesses.AsNoTracking().FirstAsync(x => x.Id == TenantId);
        return Ok(new
        {
            p.Id, fullName = $"{p.FirstName} {p.LastName}", p.BirthDate, age = Mapping.Age(p.BirthDate), p.Phone, p.Email,
            p.BloodType, p.Allergies, p.ChronicConditions,
            business = new { b.Id, b.Name, b.Phone, b.Address, b.City, b.Currency, specialty = SpecialtyCatalog.Get(b.Specialty).Label }
        });
    }

    /// <summary>Historiku i vizitave (pa shënimet e brendshme të stafit).</summary>
    [HttpGet("visits")]
    public async Task<List<object>> Visits()
    {
        var b = await Db.Businesses.AsNoTracking().FirstAsync(x => x.Id == TenantId);
        var labels = BusinessConfig.VisitFields(b).GroupBy(f => f.Key).ToDictionary(g => g.Key, g => g.First().Label);
        var visits = await Db.Visits.AsNoTracking().Include(v => v.Doctor).Where(v => v.PatientId == PatientId)
            .OrderByDescending(v => v.VisitDate).ToListAsync();
        return visits.Select(v => (object)new
        {
            v.Id, v.VisitDate, doctor = v.Doctor?.FullName, v.Complaint, v.Diagnosis, v.Treatment, v.Prescription, v.NextVisitDate,
            fields = Mapping.ParseFields(v.FieldsJson).Where(kv => !string.IsNullOrWhiteSpace(kv.Value))
                .Select(kv => new { label = labels.GetValueOrDefault(kv.Key, kv.Key), value = kv.Value })
        }).ToList();
    }

    /// <summary>Kartela financiare: sa ka paguar dhe sa i ka mbetur borxh.</summary>
    [HttpGet("statement")]
    public async Task<ActionResult<StatementDto>> Statement()
    {
        var s = await _fin.StatementAsync(PatientId);
        if (s is null) return NotFoundMsg("Kartela");
        return s;
    }

    [HttpGet("appointments")]
    public async Task<List<AppointmentDto>> Appointments()
    {
        var list = await Db.Appointments.AsNoTracking().Include(a => a.Patient).Include(a => a.Staff)
            .Where(a => a.PatientId == PatientId).OrderByDescending(a => a.StartsAt).Take(100).ToListAsync();
        var names = await Db.Services.AsNoTracking().ToDictionaryAsync(s => s.Id, s => s.Name);
        return list.Select(a => a.ToDto(a.ServiceItemId is { } s ? names.GetValueOrDefault(s) : null)).ToList();
    }

    /// <summary>Planet e trajtimit të pacientit me këstet (sa ka paguar, sa i mbetet).</summary>
    [HttpGet("plans"), RequireFeature(Features.TreatmentPlans)]
    public async Task<List<PlanDto>> Plans()
    {
        var plans = await Db.TreatmentPlans.AsNoTracking().Include(p => p.Items).Include(p => p.Installments)
            .Where(p => p.PatientId == PatientId && p.Status != PlanStatus.Anuluar)
            .OrderByDescending(p => p.CreatedAt).ToListAsync();
        var b = await Db.Businesses.AsNoTracking().FirstAsync(x => x.Id == TenantId);
        var today = ClinicTime.Today(b.TimeZone);
        var dids = plans.Where(p => p.DoctorId != null).Select(p => p.DoctorId!.Value).ToList();
        var doctors = await Db.Users.Where(u => u.BusinessId == TenantId && dids.Contains(u.Id)).ToDictionaryAsync(u => u.Id, u => u.FullName);
        return plans.Select(p => PlanMapper.ToDto(p, "", p.DoctorId is { } d ? doctors.GetValueOrDefault(d) : null, today)).ToList();
    }

    [HttpGet("services")]
    public async Task<List<ServiceDto>> Services() =>
        (await Db.Services.AsNoTracking().Where(s => s.IsActive).OrderBy(s => s.Name).ToListAsync()).Select(s => s.ToDto()).ToList();

    /// <summary>Kërkesë për termin — stafi e konfirmon nga paneli.</summary>
    [HttpPost("appointments"), RequireFeature(Features.OnlineBooking)]
    public async Task<ActionResult<AppointmentDto>> RequestAppointment(ClientAppointmentRequest r)
    {
        if (r.StartsAt.ToUniversalTime() < DateTime.UtcNow.AddMinutes(30)) return Fail("Zgjidhni një orar në të ardhmen.");
        var pending = await Db.Appointments.CountAsync(a => a.PatientId == PatientId && a.StartsAt > DateTime.UtcNow
            && a.Status == AppointmentStatus.Planifikuar && a.RequestedByClient);
        if (pending >= 3) return Fail("Keni tashmë 3 kërkesa në pritje. Prisni konfirmimin e klinikës.");

        var svc = r.ServiceItemId is { } sid ? await Db.Services.FirstOrDefaultAsync(s => s.Id == sid) : null;
        var a = new Appointment
        {
            PatientId = PatientId, ServiceItemId = svc?.Id, StartsAt = r.StartsAt.ToUniversalTime(),
            DurationMinutes = svc?.DurationMinutes ?? 30, Notes = r.Notes, RequestedByClient = true
        };
        Db.Appointments.Add(a);
        await Db.SaveChangesAsync();
        var full = await Db.Appointments.AsNoTracking().Include(x => x.Patient).FirstAsync(x => x.Id == a.Id);
        return full.ToDto(svc?.Name);
    }

    [HttpPost("appointments/{id:guid}/cancel")]
    public async Task<IActionResult> Cancel(Guid id)
    {
        var a = await Db.Appointments.FirstOrDefaultAsync(x => x.Id == id && x.PatientId == PatientId);
        if (a is null) return NotFoundMsg("Termini");
        if (a.StartsAt < DateTime.UtcNow) return Fail("Nuk mund të anuloni një termin të kaluar.");
        a.Status = AppointmentStatus.Anuluar;
        await Db.SaveChangesAsync();
        return Ok(new { message = "Termini u anulua." });
    }
}

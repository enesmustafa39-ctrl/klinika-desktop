using Klinika.Api.Auth;
using Klinika.Api.Data;
using Klinika.Api.Domain;
using Klinika.Api.Dtos;
using Klinika.Api.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Klinika.Api.Controllers;

/// <summary>Odontogrami – gjendja e çdo dhëmbi të pacientit (numërimi FDI).</summary>
[Authorize(Roles = Roles.Clinical), RequireFeature(Features.Odontogram)]
public class DentalController : ApiBase
{
    public DentalController(AppDbContext db, ICurrentUser me) : base(db, me) { }

    [HttpGet("api/patients/{patientId:guid}/teeth")]
    public async Task<List<ToothDto>> List(Guid patientId)
    {
        var rows = await Db.ToothRecords.AsNoTracking().Where(t => t.PatientId == patientId).OrderBy(t => t.Tooth).ToListAsync();
        var ids = rows.Where(r => r.UpdatedById != null).Select(r => r.UpdatedById!.Value).Distinct().ToList();
        var names = await Db.Users.Where(u => u.BusinessId == TenantId && ids.Contains(u.Id)).ToDictionaryAsync(u => u.Id, u => u.FullName);
        return rows.Select(r => ToDto(r, names)).ToList();
    }

    [HttpPut("api/patients/{patientId:guid}/teeth/{tooth:int}")]
    public async Task<ActionResult<ToothDto?>> Upsert(Guid patientId, int tooth, UpsertToothRequest r)
    {
        if (!IsValidTooth(tooth)) return Fail("Numër dhëmbi i pavlefshëm (FDI 11–48 ose 51–85).");
        if (!await Db.Patients.AnyAsync(p => p.Id == patientId)) return NotFoundMsg("Pacienti");

        var rec = await Db.ToothRecords.FirstOrDefaultAsync(t => t.PatientId == patientId && t.Tooth == tooth);
        var surfaces = new string((r.Surfaces ?? "").ToUpperInvariant().Where(c => "MODBL".Contains(c)).Distinct().ToArray());

        // I shëndoshë pa shënime = rikthim në gjendjen fillestare
        if (r.Condition == ToothCondition.Shendoshe && surfaces.Length == 0 && string.IsNullOrWhiteSpace(r.Notes))
        {
            if (rec is not null) { Db.ToothRecords.Remove(rec); await Db.SaveChangesAsync(); }
            return Ok(null);
        }

        if (rec is null)
        {
            rec = new ToothRecord { PatientId = patientId, Tooth = tooth };
            Db.ToothRecords.Add(rec);
        }
        rec.Condition = r.Condition;
        rec.Surfaces = surfaces.Length == 0 ? null : surfaces;
        rec.Notes = string.IsNullOrWhiteSpace(r.Notes) ? null : r.Notes.Trim();
        rec.UpdatedAt = DateTime.UtcNow;
        rec.UpdatedById = Me.UserId;
        await Db.SaveChangesAsync();
        var names = await Db.Users.Where(u => u.Id == Me.UserId).ToDictionaryAsync(u => u.Id, u => u.FullName);
        return ToDto(rec, names);
    }

    private static bool IsValidTooth(int t)
    {
        int q = t / 10, n = t % 10;
        return (q is >= 1 and <= 4 && n is >= 1 and <= 8) || (q is >= 5 and <= 8 && n is >= 1 and <= 5);
    }

    private static ToothDto ToDto(ToothRecord r, Dictionary<Guid, string> names) => new(r.Tooth, r.Condition,
        Labels.Tooth(r.Condition), r.Surfaces, r.Notes, r.UpdatedAt, r.UpdatedById is { } u ? names.GetValueOrDefault(u) : null);
}

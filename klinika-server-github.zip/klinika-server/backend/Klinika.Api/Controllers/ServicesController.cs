using Klinika.Api.Auth;
using Klinika.Api.Data;
using Klinika.Api.Domain;
using Klinika.Api.Dtos;
using Klinika.Api.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Klinika.Api.Controllers;

/// <summary>Katalogu i shërbimeve dhe çmimeve të biznesit.</summary>
[Route("api/services"), Authorize(Roles = Roles.Staff)]
public class ServicesController : ApiBase
{
    public ServicesController(AppDbContext db, ICurrentUser me) : base(db, me) { }

    [HttpGet]
    public async Task<List<ServiceDto>> List([FromQuery] bool includeInactive = false)
    {
        var q = Db.Services.AsNoTracking();
        if (!includeInactive) q = q.Where(s => s.IsActive);
        return (await q.OrderBy(s => s.Category).ThenBy(s => s.Name).ToListAsync()).Select(s => s.ToDto()).ToList();
    }

    [HttpPost, Authorize(Roles = Roles.Admin)]
    public async Task<ActionResult<ServiceDto>> Create(ServiceUpsert r)
    {
        var s = new ServiceItem { Name = r.Name.Trim(), Category = r.Category, Price = r.Price, DurationMinutes = r.DurationMinutes, IsActive = r.IsActive };
        Db.Services.Add(s);
        await Db.SaveChangesAsync();
        return s.ToDto();
    }

    [HttpPut("{id:guid}"), Authorize(Roles = Roles.Admin)]
    public async Task<ActionResult<ServiceDto>> Update(Guid id, ServiceUpsert r)
    {
        var s = await Db.Services.FirstOrDefaultAsync(x => x.Id == id);
        if (s is null) return NotFoundMsg("Shërbimi");
        s.Name = r.Name.Trim(); s.Category = r.Category; s.Price = r.Price; s.DurationMinutes = r.DurationMinutes; s.IsActive = r.IsActive;
        await Db.SaveChangesAsync();
        return s.ToDto();
    }

    [HttpDelete("{id:guid}"), Authorize(Roles = Roles.Admin)]
    public async Task<IActionResult> Delete(Guid id)
    {
        var s = await Db.Services.FirstOrDefaultAsync(x => x.Id == id);
        if (s is null) return NotFoundMsg("Shërbimi");
        s.IsActive = false; // ruhet për historikun e ngarkesave
        await Db.SaveChangesAsync();
        return NoContent();
    }

    /// <summary>Rimerr shërbimet e paracaktuara të specialitetit (shton vetëm ato që mungojnë).</summary>
    [HttpPost("import-defaults"), Authorize(Roles = Roles.Admin)]
    public async Task<IActionResult> ImportDefaults()
    {
        var biz = await Db.Businesses.FirstAsync(b => b.Id == TenantId);
        var existing = (await Db.Services.Select(s => s.Name).ToListAsync()).ToHashSet(StringComparer.OrdinalIgnoreCase);
        var added = 0;
        foreach (var t in SpecialtyCatalog.Get(biz.Specialty).Services.Where(t => !existing.Contains(t.Name)))
        {
            Db.Services.Add(new ServiceItem { Name = t.Name, Category = t.Category, Price = t.Price, DurationMinutes = t.DurationMinutes });
            added++;
        }
        await Db.SaveChangesAsync();
        return Ok(new { message = $"U shtuan {added} shërbime." });
    }
}

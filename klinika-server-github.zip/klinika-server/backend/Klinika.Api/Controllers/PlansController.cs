using Klinika.Api.Auth;
using Klinika.Api.Data;
using Klinika.Api.Domain;
using Klinika.Api.Dtos;
using Klinika.Api.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Klinika.Api.Controllers;

/// <summary>
/// Planet e trajtimit me këste. Rrjedha:
/// 1) Mjeku krijon planin (I propozuar) → 2) pacienti pranon → "Aktivizo": totali ngarkohet në llogari
/// 3) çdo këst i paguar krijon një Pagesë → borxhi zvogëlohet automatikisht.
/// </summary>
[Authorize(Roles = Roles.Staff), RequireFeature(Features.TreatmentPlans)]
public class PlansController : ApiBase
{
    public PlansController(AppDbContext db, ICurrentUser me) : base(db, me) { }

    [HttpGet("api/patients/{patientId:guid}/plans")]
    public async Task<List<PlanDto>> ForPatient(Guid patientId)
    {
        var plans = await Query().Where(p => p.PatientId == patientId).OrderByDescending(p => p.CreatedAt).ToListAsync();
        return await ToDtos(plans);
    }

    [HttpGet("api/plans/{id:guid}")]
    public async Task<ActionResult<PlanDto>> Get(Guid id)
    {
        var p = await Query().FirstOrDefaultAsync(x => x.Id == id);
        if (p is null) return NotFoundMsg("Plani");
        return (await ToDtos(new List<TreatmentPlan> { p }))[0];
    }

    [HttpPost("api/plans"), Authorize(Roles = "Admin,Mjek")]
    public async Task<ActionResult<PlanDto>> Create(CreatePlanRequest r)
    {
        if (r.DoctorId is { } d && !await IsOwnStaff(d)) return NotFoundMsg("Mjeku");
        if (!await Db.Patients.AnyAsync(p => p.Id == r.PatientId)) return NotFoundMsg("Pacienti");
        if (r.Items is null || r.Items.Count == 0) return Fail("Shtoni të paktën një shërbim në plan.");

        var plan = new TreatmentPlan
        {
            PatientId = r.PatientId, Title = r.Title.Trim(), Notes = r.Notes, CreatedById = Me.UserId,
            DoctorId = r.DoctorId ?? (Me.Role is UserRole.Mjek or UserRole.Admin ? Me.UserId : null)
        };
        plan.Items.AddRange(await BuildItems(r.Items));
        var today = await Today();
        plan.Installments.AddRange(PlanMapper.BuildInstallments(plan.Items.Sum(i => i.Amount), r.Installments,
            r.FirstDueDate ?? today, r.IntervalMonths));
        Db.TreatmentPlans.Add(plan);
        if (r.Activate) Activate(plan);
        await Db.SaveChangesAsync();
        return await Get(plan.Id);
    }

    [HttpPut("api/plans/{id:guid}"), Authorize(Roles = "Admin,Mjek")]
    public async Task<ActionResult<PlanDto>> Update(Guid id, UpdatePlanRequest r)
    {
        if (r.DoctorId is { } d && !await IsOwnStaff(d)) return NotFoundMsg("Mjeku");
        var p = await Query().FirstOrDefaultAsync(x => x.Id == id);
        if (p is null) return NotFoundMsg("Plani");
        p.Title = r.Title.Trim(); p.Notes = r.Notes; p.DoctorId = r.DoctorId ?? p.DoctorId;

        if (p.Status == PlanStatus.Propozuar && r.Items is { Count: > 0 })
        {
            Db.TreatmentPlanItems.RemoveRange(p.Items);
            Db.PlanInstallments.RemoveRange(p.Installments);
            var items = await BuildItems(r.Items);
            foreach (var i in items) { i.PlanId = p.Id; Db.TreatmentPlanItems.Add(i); }
            var inst = PlanMapper.BuildInstallments(items.Sum(i => i.Amount), r.Installments ?? p.Installments.Count,
                r.FirstDueDate ?? p.Installments.OrderBy(i => i.Number).Select(i => (DateOnly?)i.DueDate).FirstOrDefault() ?? await Today(),
                r.IntervalMonths ?? 1);
            foreach (var i in inst) { i.PlanId = p.Id; Db.PlanInstallments.Add(i); }
        }
        else if (r.Items is { Count: > 0 })
        {
            return Fail("Shërbimet dhe këstet mund të ndryshohen vetëm kur plani është 'I propozuar'.");
        }
        await Db.SaveChangesAsync();
        return await Get(id);
    }

    /// <summary>Pacienti e pranoi planin: totali ngarkohet në llogarinë e tij.</summary>
    [HttpPost("api/plans/{id:guid}/activate"), Authorize(Roles = "Admin,Mjek,Recepsion")]
    public async Task<ActionResult<PlanDto>> ActivatePlan(Guid id)
    {
        var p = await Query().FirstOrDefaultAsync(x => x.Id == id);
        if (p is null) return NotFoundMsg("Plani");
        if (p.Status != PlanStatus.Propozuar) return Fail("Vetëm planet 'I propozuar' mund të aktivizohen.");
        Activate(p);
        await Db.SaveChangesAsync();
        return await Get(id);
    }

    [HttpPost("api/plans/{id:guid}/items/{itemId:guid}/toggle"), Authorize(Roles = Roles.Clinical)]
    public async Task<ActionResult<PlanDto>> ToggleItem(Guid id, Guid itemId)
    {
        var item = await Db.TreatmentPlanItems.FirstOrDefaultAsync(i => i.Id == itemId && i.PlanId == id);
        if (item is null) return NotFoundMsg("Shërbimi i planit");
        item.Done = !item.Done;
        item.DoneAt = item.Done ? DateTime.UtcNow : null;
        await Db.SaveChangesAsync();
        return await Get(id);
    }

    [HttpPost("api/plans/{id:guid}/installments/{instId:guid}/pay"), Authorize(Roles = Roles.Finance)]
    public async Task<ActionResult<PlanDto>> Pay(Guid id, Guid instId, PayInstallmentRequest r)
    {
        var p = await Query().FirstOrDefaultAsync(x => x.Id == id);
        if (p is null) return NotFoundMsg("Plani");
        if (p.Status != PlanStatus.Aktiv) return Fail("Aktivizoni planin para se të regjistroni këste.");
        var inst = p.Installments.FirstOrDefault(i => i.Id == instId);
        if (inst is null) return NotFoundMsg("Kësti");
        if (inst.PaidAt is not null) return Fail("Ky këst është paguar tashmë.");

        var date = r.Date?.ToUniversalTime() ?? DateTime.UtcNow;
        var pay = new Payment
        {
            PatientId = p.PatientId, Amount = inst.Amount, Method = r.Method, Date = date, CreatedById = Me.UserId,
            Reference = string.IsNullOrWhiteSpace(r.Reference) ? $"Kësti {inst.Number} – {p.Title}" : r.Reference
        };
        Db.Payments.Add(pay);
        inst.PaidAt = date;
        inst.PaymentId = pay.Id;
        await Db.SaveChangesAsync();
        return await Get(id);
    }

    /// <summary>Anulon pagesën e një kësti (p.sh. u regjistrua gabimisht).</summary>
    [HttpPost("api/plans/{id:guid}/installments/{instId:guid}/unpay"), Authorize(Roles = Roles.Admin)]
    public async Task<ActionResult<PlanDto>> Unpay(Guid id, Guid instId)
    {
        var inst = await Db.PlanInstallments.FirstOrDefaultAsync(i => i.Id == instId && i.PlanId == id);
        if (inst is null) return NotFoundMsg("Kësti");
        if (inst.PaymentId is { } pid)
        {
            var pay = await Db.Payments.FirstOrDefaultAsync(x => x.Id == pid);
            if (pay is not null) Db.Payments.Remove(pay);
        }
        inst.PaidAt = null; inst.PaymentId = null;
        await Db.SaveChangesAsync();
        return await Get(id);
    }

    [HttpPost("api/plans/{id:guid}/complete"), Authorize(Roles = "Admin,Mjek")]
    public async Task<ActionResult<PlanDto>> Complete(Guid id)
    {
        var p = await Db.TreatmentPlans.FirstOrDefaultAsync(x => x.Id == id);
        if (p is null) return NotFoundMsg("Plani");
        if (p.Status != PlanStatus.Aktiv) return Fail("Vetëm planet aktive mund të përfundohen.");
        p.Status = PlanStatus.Perfunduar;
        await Db.SaveChangesAsync();
        return await Get(id);
    }

    /// <summary>Anulon planin. Nëse ishte aktiv, pjesa e papaguar hiqet nga borxhi i pacientit.</summary>
    [HttpPost("api/plans/{id:guid}/cancel"), Authorize(Roles = "Admin,Mjek")]
    public async Task<ActionResult<PlanDto>> Cancel(Guid id)
    {
        var p = await Query().FirstOrDefaultAsync(x => x.Id == id);
        if (p is null) return NotFoundMsg("Plani");
        if (p.Status is PlanStatus.Anuluar or PlanStatus.Perfunduar) return Fail("Plani është mbyllur tashmë.");
        if (p.Status == PlanStatus.Aktiv)
        {
            var unpaid = p.Items.Sum(i => i.Amount) - p.Installments.Where(i => i.PaidAt != null).Sum(i => i.Amount);
            if (unpaid > 0)
                Db.Charges.Add(new Charge
                {
                    PatientId = p.PatientId, Description = $"Anulim i planit: {p.Title}", Quantity = 1,
                    UnitPrice = -unpaid, Amount = -unpaid, Date = DateTime.UtcNow, CreatedById = Me.UserId
                });
        }
        p.Status = PlanStatus.Anuluar;
        await Db.SaveChangesAsync();
        return await Get(id);
    }

    [HttpDelete("api/plans/{id:guid}"), Authorize(Roles = "Admin,Mjek")]
    public async Task<IActionResult> Delete(Guid id)
    {
        var p = await Db.TreatmentPlans.FirstOrDefaultAsync(x => x.Id == id);
        if (p is null) return NotFoundMsg("Plani");
        if (p.Status != PlanStatus.Propozuar) return Fail("Vetëm planet 'I propozuar' mund të fshihen. Planet aktive anulohen.");
        Db.TreatmentPlans.Remove(p);
        await Db.SaveChangesAsync();
        return NoContent();
    }

    /// <summary>Këstet me vonesë për të gjithë pacientët e klinikës.</summary>
    [HttpGet("api/plans/overdue"), Authorize(Roles = Roles.Finance)]
    public async Task<List<OverdueInstallmentDto>> Overdue()
    {
        var today = await Today();
        var rows = await (from i in Db.PlanInstallments
                          join p in Db.TreatmentPlans on i.PlanId equals p.Id
                          join pt in Db.Patients on p.PatientId equals pt.Id
                          where i.PaidAt == null && i.DueDate < today && p.Status == PlanStatus.Aktiv
                          orderby i.DueDate
                          select new { p.Id, p.Title, PatientId = pt.Id, pt.FirstName, pt.LastName, pt.Phone, InstId = i.Id, i.Number, i.DueDate, i.Amount })
            .ToListAsync();
        return rows.Select(x => new OverdueInstallmentDto(x.Id, x.Title, x.PatientId, $"{x.FirstName} {x.LastName}", x.Phone,
            x.InstId, x.Number, x.DueDate, x.Amount, today.DayNumber - x.DueDate.DayNumber)).ToList();
    }

    // ---------- ndihmëse ----------
    private IQueryable<TreatmentPlan> Query() => Db.TreatmentPlans.Include(p => p.Items).Include(p => p.Installments);

    private void Activate(TreatmentPlan p)
    {
        var total = p.Items.Sum(i => i.Amount);
        var charge = new Charge
        {
            PatientId = p.PatientId, Description = $"Plani i trajtimit: {p.Title}", Quantity = 1,
            UnitPrice = total, Amount = total, Date = DateTime.UtcNow, CreatedById = Me.UserId
        };
        Db.Charges.Add(charge);
        p.ChargeId = charge.Id;
        p.Status = PlanStatus.Aktiv;
        p.ActivatedAt = DateTime.UtcNow;
    }

    private async Task<List<TreatmentPlanItem>> BuildItems(List<PlanItemInput> input)
    {
        var ids = input.Where(i => i.ServiceItemId != null).Select(i => i.ServiceItemId!.Value).ToList();
        var services = await Db.Services.Where(s => ids.Contains(s.Id)).ToDictionaryAsync(s => s.Id);
        var list = new List<TreatmentPlanItem>();
        var order = 0;
        foreach (var line in input)
        {
            ServiceItem? s = line.ServiceItemId is { } sid ? services.GetValueOrDefault(sid) : null;
            var desc = string.IsNullOrWhiteSpace(line.Description) ? s?.Name : line.Description.Trim();
            if (string.IsNullOrWhiteSpace(desc)) continue;
            var qty = line.Quantity <= 0 ? 1 : line.Quantity;
            var price = line.UnitPrice ?? s?.Price ?? 0;
            var discount = Math.Max(0, line.Discount);
            list.Add(new TreatmentPlanItem
            {
                ServiceItemId = s?.Id, Description = desc!, Tooth = string.IsNullOrWhiteSpace(line.Tooth) ? null : line.Tooth.Trim(),
                Quantity = qty, UnitPrice = price, Discount = discount, Amount = Math.Max(0, qty * price - discount), SortOrder = order++
            });
        }
        return list;
    }

    private async Task<DateOnly> Today()
    {
        var tz = await Db.Businesses.Where(b => b.Id == TenantId).Select(b => b.TimeZone).FirstAsync();
        return ClinicTime.Today(tz);
    }

    private async Task<List<PlanDto>> ToDtos(List<TreatmentPlan> plans)
    {
        var today = await Today();
        var pids = plans.Select(p => p.PatientId).Distinct().ToList();
        var patients = await Db.Patients.Where(p => pids.Contains(p.Id))
            .ToDictionaryAsync(p => p.Id, p => p.FirstName + " " + p.LastName);
        var dids = plans.Where(p => p.DoctorId != null).Select(p => p.DoctorId!.Value).Distinct().ToList();
        var doctors = await Db.Users.Where(u => u.BusinessId == TenantId && dids.Contains(u.Id)).ToDictionaryAsync(u => u.Id, u => u.FullName);
        return plans.Select(p => PlanMapper.ToDto(p, patients.GetValueOrDefault(p.PatientId, ""),
            p.DoctorId is { } d ? doctors.GetValueOrDefault(d) : null, today)).ToList();
    }
}

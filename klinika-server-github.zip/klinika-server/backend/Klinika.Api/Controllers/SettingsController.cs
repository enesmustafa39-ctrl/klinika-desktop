using Klinika.Api.Auth;
using Klinika.Api.Data;
using Klinika.Api.Dtos;
using Klinika.Api.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Klinika.Api.Controllers;

/// <summary>Cilësimet e klinikës (Administratori): kontaktet, kujtesat, fatura, zona kohore.</summary>
[Route("api/business/settings"), Authorize(Roles = Roles.Admin)]
public class SettingsController : ApiBase
{
    private readonly IMessageSender _sender;
    public SettingsController(AppDbContext db, ICurrentUser me, IMessageSender sender) : base(db, me) => _sender = sender;

    [HttpGet]
    public async Task<BusinessSettingsDto> Get()
    {
        var b = await Db.Businesses.AsNoTracking().FirstAsync(x => x.Id == TenantId);
        return new BusinessSettingsDto(b.Name, b.NIPT, b.Address, b.City, b.Phone, b.Email, b.TimeZone, b.PhoneCountryCode,
            b.ReminderHoursBefore, string.IsNullOrWhiteSpace(b.ReminderTemplate) ? Reminders.DefaultTemplate : b.ReminderTemplate!,
            Reminders.DefaultTemplate, b.InvoiceFooter, _sender.IsConfigured, _sender.Channel);
    }

    [HttpPut]
    public async Task<ActionResult<BusinessSettingsDto>> Update(UpdateSettingsRequest r)
    {
        var b = await Db.Businesses.FirstAsync(x => x.Id == TenantId);
        if (!string.IsNullOrWhiteSpace(r.TimeZone))
        {
            if (ClinicTime.Zone(r.TimeZone) == TimeZoneInfo.Utc && r.TimeZone != "UTC") return Fail("Zona kohore nuk njihet.");
            b.TimeZone = r.TimeZone.Trim();
        }
        b.Address = r.Address; b.City = r.City; b.Phone = r.Phone; b.Email = r.Email;
        b.PhoneCountryCode = new string((r.PhoneCountryCode ?? "").Where(char.IsDigit).ToArray());
        b.ReminderHoursBefore = Math.Clamp(r.ReminderHoursBefore, 1, 168);
        b.ReminderTemplate = string.IsNullOrWhiteSpace(r.ReminderTemplate) || r.ReminderTemplate.Trim() == Reminders.DefaultTemplate
            ? null : r.ReminderTemplate.Trim();
        b.InvoiceFooter = r.InvoiceFooter;
        await Db.SaveChangesAsync();
        return await Get();
    }
}

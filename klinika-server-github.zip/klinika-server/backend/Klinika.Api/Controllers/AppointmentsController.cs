using Klinika.Api.Auth;
using Klinika.Api.Data;
using Klinika.Api.Domain;
using Klinika.Api.Dtos;
using Klinika.Api.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Klinika.Api.Controllers;

/// <summary>Terminet (takimet).</summary>
[Route("api/appointments"), Authorize(Roles = Roles.Staff)]
public class AppointmentsController : ApiBase
{
    private readonly IMessageSender _sender;
    public AppointmentsController(AppDbContext db, ICurrentUser me, IMessageSender sender) : base(db, me) => _sender = sender;

    /// <summary>Teksti i kujtesës + lidhjet WhatsApp / Viber / SMS për dërgim me një klik.</summary>
    [HttpGet("{id:guid}/reminder"), RequireFeature(Features.Reminders)]
    public async Task<ActionResult<ReminderPreviewDto>> Reminder(Guid id)
    {
        var a = await Db.Appointments.AsNoTracking().Include(x => x.Patient).Include(x => x.Staff).FirstOrDefaultAsync(x => x.Id == id);
        if (a is null) return NotFoundMsg("Termini");
        var b = await Db.Businesses.AsNoTracking().FirstAsync(x => x.Id == TenantId);
        var service = a.ServiceItemId is { } sid ? await Db.Services.Where(s => s.Id == sid).Select(s => s.Name).FirstOrDefaultAsync() : null;
        var text = Reminders.Render(b, a, service);
        var phone = Reminders.NormalizePhone(a.Patient?.Phone, b.PhoneCountryCode);
        return new ReminderPreviewDto(text, phone,
            phone is null ? null : Reminders.WhatsAppUrl(phone, text),
            phone is null ? null : Reminders.SmsUrl(phone, text),
            phone is null ? null : Reminders.ViberUrl(phone),
            _sender.IsConfigured, a.ReminderSentAt, a.ReminderChannel);
    }

    /// <summary>Shëno që kujtesa u dërgua manualisht (whatsapp / viber / sms / telefon).</summary>
    [HttpPost("{id:guid}/reminded"), RequireFeature(Features.Reminders)]
    public async Task<IActionResult> MarkReminded(Guid id, MarkRemindedRequest r)
    {
        var a = await Db.Appointments.FirstOrDefaultAsync(x => x.Id == id);
        if (a is null) return NotFoundMsg("Termini");
        a.ReminderSentAt = DateTime.UtcNow;
        a.ReminderChannel = string.IsNullOrWhiteSpace(r.Channel) ? "manual" : r.Channel.Trim().ToLowerInvariant();
        await Db.SaveChangesAsync();
        return Ok(new { message = "Kujtesa u shënua si e dërguar." });
    }

    /// <summary>Dërgo kujtesën tani përmes ofruesit SMS/WhatsApp të platformës (nëse është konfiguruar).</summary>
    [HttpPost("{id:guid}/send-reminder"), RequireFeature(Features.Reminders)]
    public async Task<IActionResult> SendReminder(Guid id)
    {
        if (!_sender.IsConfigured) return Fail("Dërgimi automatik nuk është konfiguruar në platformë. Përdorni WhatsApp / Viber / SMS.");
        var a = await Db.Appointments.Include(x => x.Patient).Include(x => x.Staff).FirstOrDefaultAsync(x => x.Id == id);
        if (a is null) return NotFoundMsg("Termini");
        var b = await Db.Businesses.AsNoTracking().FirstAsync(x => x.Id == TenantId);
        var phone = Reminders.NormalizePhone(a.Patient?.Phone, b.PhoneCountryCode);
        if (phone is null) return Fail("Pacienti nuk ka numër telefoni të vlefshëm.");
        var service = a.ServiceItemId is { } sid ? await Db.Services.Where(s => s.Id == sid).Select(s => s.Name).FirstOrDefaultAsync() : null;
        var err = await _sender.SendAsync(phone, Reminders.Render(b, a, service));
        if (err is not null) return Fail(err, 502);
        a.ReminderSentAt = DateTime.UtcNow;
        a.ReminderChannel = _sender.Channel;
        await Db.SaveChangesAsync();
        return Ok(new { message = "Kujtesa u dërgua." });
    }

    [HttpGet]
    public async Task<List<AppointmentDto>> List([FromQuery] DateTime? from, [FromQuery] DateTime? to, [FromQuery] Guid? staffId,
        [FromQuery] Guid? patientId, [FromQuery] AppointmentStatus? status)
    {
        var f = from?.ToUniversalTime() ?? DateTime.UtcNow.Date;
        var t = to?.ToUniversalTime() ?? f.AddDays(7);
        var q = Db.Appointments.AsNoTracking().Include(a => a.Patient).Include(a => a.Staff)
            .Where(a => a.StartsAt >= f && a.StartsAt < t);
        if (patientId is not null) q = Db.Appointments.AsNoTracking().Include(a => a.Patient).Include(a => a.Staff).Where(a => a.PatientId == patientId);
        if (staffId is not null) q = q.Where(a => a.StaffId == staffId);
        if (status is not null) q = q.Where(a => a.Status == status);
        var list = await q.OrderBy(a => a.StartsAt).Take(1000).ToListAsync();
        var names = await ServiceNames();
        return list.Select(a => a.ToDto(a.ServiceItemId is { } s ? names.GetValueOrDefault(s) : null)).ToList();
    }

    [HttpPost]
    public async Task<ActionResult<AppointmentDto>> Create(AppointmentUpsert r)
    {
        if (!await Db.Patients.AnyAsync(p => p.Id == r.PatientId)) return NotFoundMsg("Pacienti");
        var a = new Appointment();
        if (await Apply(a, r) is { } err) return Fail(err, 409);
        Db.Appointments.Add(a);
        await Db.SaveChangesAsync();
        return await One(a.Id);
    }

    [HttpPut("{id:guid}")]
    public async Task<ActionResult<AppointmentDto>> Update(Guid id, AppointmentUpsert r)
    {
        var a = await Db.Appointments.FirstOrDefaultAsync(x => x.Id == id);
        if (a is null) return NotFoundMsg("Termini");
        if (await Apply(a, r) is { } err) return Fail(err, 409);
        await Db.SaveChangesAsync();
        return await One(id);
    }

    [HttpPost("{id:guid}/status")]
    public async Task<ActionResult<AppointmentDto>> SetStatus(Guid id, SetStatusRequest r)
    {
        var a = await Db.Appointments.FirstOrDefaultAsync(x => x.Id == id);
        if (a is null) return NotFoundMsg("Termini");
        a.Status = r.Status;
        await Db.SaveChangesAsync();
        return await One(id);
    }

    [HttpDelete("{id:guid}")]
    public async Task<IActionResult> Delete(Guid id)
    {
        var a = await Db.Appointments.FirstOrDefaultAsync(x => x.Id == id);
        if (a is null) return NotFoundMsg("Termini");
        Db.Appointments.Remove(a);
        await Db.SaveChangesAsync();
        return NoContent();
    }

    private async Task<string?> Apply(Appointment a, AppointmentUpsert r)
    {
        var start = r.StartsAt.ToUniversalTime();
        var dur = Math.Clamp(r.DurationMinutes, 5, 600);
        if (r.PatientId != a.PatientId && !await Db.Patients.AnyAsync(p => p.Id == r.PatientId)) return "Pacienti nuk u gjet.";
        if (r.ServiceItemId is { } svc && !await Db.Services.AnyAsync(x => x.Id == svc)) return "Shërbimi nuk u gjet.";
        if (r.StaffId is { } sid)
        {
            if (!await IsOwnStaff(sid)) return "Stafi i zgjedhur nuk ekziston.";
            var end = start.AddMinutes(dur);
            // Merr terminet e stafit rreth këtij orari dhe kontrollo mbivendosjen në memorie
            // (kohëzgjatja maksimale është 600 min, prandaj mjafton një dritare prej 10 orësh).
            var windowStart = start.AddMinutes(-600);
            var nearby = await Db.Appointments.AsNoTracking()
                .Where(x => x.Id != a.Id && x.StaffId == sid
                    && x.Status != AppointmentStatus.Anuluar && x.Status != AppointmentStatus.NukErdhi
                    && x.StartsAt < end && x.StartsAt > windowStart)
                .Select(x => new { x.StartsAt, x.DurationMinutes })
                .ToListAsync();
            var clash = nearby.Any(x => x.StartsAt.AddMinutes(x.DurationMinutes) > start);
            if (clash) return "Ky anëtar i stafit ka një termin tjetër në këtë orar.";
        }
        a.PatientId = r.PatientId; a.StaffId = r.StaffId; a.ServiceItemId = r.ServiceItemId; a.StartsAt = start;
        a.DurationMinutes = dur; a.Status = r.Status; a.Notes = r.Notes;
        return null;
    }

    private async Task<AppointmentDto> One(Guid id)
    {
        var a = await Db.Appointments.AsNoTracking().Include(x => x.Patient).Include(x => x.Staff).FirstAsync(x => x.Id == id);
        var names = await ServiceNames();
        return a.ToDto(a.ServiceItemId is { } s ? names.GetValueOrDefault(s) : null);
    }

    private Task<Dictionary<Guid, string>> ServiceNames() => Db.Services.AsNoTracking().ToDictionaryAsync(s => s.Id, s => s.Name);
}

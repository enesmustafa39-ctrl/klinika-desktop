using System.ComponentModel.DataAnnotations;
using Klinika.Api.Auth;
using Klinika.Api.Domain;

namespace Klinika.Api.Dtos;

// ---------- Auth ----------
/// <param name="RememberMe">"Më mbaj të kyçur": seanca zgjat 30 ditë në vend të 12 orëve.</param>
public record LoginRequest([Required, EmailAddress, MaxLength(254)] string Email, [Required, MaxLength(128)] string Password, bool RememberMe = false);
public record LoginResponse(string Token, DateTime ExpiresAt, UserDto User, BusinessBriefDto? Business);
public record ChangePasswordRequest([Required] string CurrentPassword, [Required, StrongPassword] string NewPassword);

public record UserDto(Guid Id, string FullName, string Email, string? Phone, UserRole Role, string RoleLabel,
    string? Title, bool IsActive, Guid? BusinessId, Guid? PatientId, DateTime? LastLoginAt);

public record BusinessBriefDto(Guid Id, string Name, Specialty Specialty, string SpecialtyLabel, string DoctorLabel, string Currency,
    List<string> Features, string? LogoUrl, string? BackgroundUrl);

// ---------- Super Admin ----------
public record BusinessDto(Guid Id, string Name, Specialty Specialty, string SpecialtyLabel, string? NIPT, string? Address,
    string? City, string? Phone, string? Email, string Currency, bool IsActive, DateTime? AccessUntil, int MaxStaff,
    string? Notes, DateTime CreatedAt, int StaffCount, int PatientCount, List<string> Features, List<FieldDef> CustomFields,
    string? AdminEmail, string? LogoUrl, string? BackgroundUrl);

public record CreateBusinessRequest(
    [Required, MaxLength(200)] string Name,
    [Required] Specialty Specialty,
    string? NIPT, string? Address, string? City, string? Phone, string? Email,
    string? Currency, DateTime? AccessUntil, int? MaxStaff, string? Notes,
    // Llogaria e administratorit të biznesit
    [Required] string AdminFullName,
    [Required, EmailAddress] string AdminEmail,
    [Required, StrongPassword] string AdminPassword,
    bool SeedDefaultServices = true,
    List<string>? Features = null);

/// <summary>Aktivizo/çaktivizo funksionet dhe fushat e personalizuara VETËM për një biznes.</summary>
public record UpdateFeaturesRequest(List<string> Features, List<FieldDef>? CustomFields);

public record UpdateBusinessRequest(
    [Required, MaxLength(200)] string Name, [Required] Specialty Specialty, string? NIPT, string? Address, string? City,
    string? Phone, string? Email, string? Currency, DateTime? AccessUntil, int? MaxStaff, string? Notes);

public record SetAccessRequest(bool IsActive, DateTime? AccessUntil);

public record SpecialtyDto(Specialty Value, string Label, string DoctorLabel, FieldDef[] VisitFields, ServiceTemplate[] Services);

public record PlatformStatsDto(int Businesses, int ActiveBusinesses, int Users, int Patients, Dictionary<string, int> BySpecialty);

// ---------- Staff ----------
public record CreateStaffRequest([Required] string FullName, [Required, EmailAddress] string Email, string? Phone,
    [Required] UserRole Role, string? Title, [Required, StrongPassword] string Password);
public record UpdateStaffRequest([Required] string FullName, string? Phone, [Required] UserRole Role, string? Title, bool IsActive);
public record ResetPasswordRequest([Required, StrongPassword] string NewPassword);

// ---------- Patients ----------
public record PatientDto(Guid Id, string FirstName, string LastName, string FullName, string? PersonalNumber, DateOnly? BirthDate,
    int? Age, Gender? Gender, string? Phone, string? Email, string? Address, string? BloodType, string? Allergies,
    string? ChronicConditions, string? Notes, bool IsArchived, DateTime CreatedAt, decimal Balance, bool HasPortalAccess,
    DateTime? LastVisit);

public record PatientUpsert([Required, MaxLength(100)] string FirstName, [Required, MaxLength(100)] string LastName,
    string? PersonalNumber, DateOnly? BirthDate, Gender? Gender, string? Phone, string? Email, string? Address,
    string? BloodType, string? Allergies, string? ChronicConditions, string? Notes);

public record PortalAccessRequest([Required, EmailAddress] string Email, [Required, StrongPassword] string Password);

// ---------- Visits (Historiku) ----------
public record VisitDto(Guid Id, Guid PatientId, string PatientName, Guid? DoctorId, string? DoctorName, DateTime VisitDate,
    string? Complaint, string? Diagnosis, string? Treatment, string? Prescription, string? Notes,
    Dictionary<string, string?> Fields, DateOnly? NextVisitDate, decimal ChargedAmount);

public record VisitUpsert([Required] Guid PatientId, Guid? DoctorId, DateTime? VisitDate, string? Complaint, string? Diagnosis,
    string? Treatment, string? Prescription, string? Notes, Dictionary<string, string?>? Fields, DateOnly? NextVisitDate,
    List<ChargeLine>? Charges);

public record ChargeLine(Guid? ServiceItemId, string? Description, decimal Quantity, decimal? UnitPrice, decimal Discount);

// ---------- Services ----------
public record ServiceDto(Guid Id, string Name, string? Category, decimal Price, int DurationMinutes, bool IsActive);
public record ServiceUpsert([Required] string Name, string? Category, [Range(0, 1_000_000)] decimal Price,
    [Range(5, 600)] int DurationMinutes, bool IsActive = true);

// ---------- Finance (Kreditë / Borxhet) ----------
public record ChargeDto(Guid Id, Guid PatientId, Guid? VisitId, string Description, decimal Quantity, decimal UnitPrice,
    decimal Discount, decimal Amount, DateTime Date);
public record CreateChargeRequest([Required] Guid PatientId, Guid? VisitId, Guid? ServiceItemId, string? Description,
    decimal Quantity = 1, decimal? UnitPrice = null, decimal Discount = 0, DateTime? Date = null);

public record PaymentDto(Guid Id, Guid PatientId, string? PatientName, decimal Amount, PaymentMethod Method, string MethodLabel,
    DateTime Date, string? Reference, string? Notes);
public record CreatePaymentRequest([Required] Guid PatientId, [Range(0.01, 10_000_000)] decimal Amount,
    PaymentMethod Method = PaymentMethod.Kesh, DateTime? Date = null, string? Reference = null, string? Notes = null);

public record LedgerEntry(DateTime Date, string Type, string Description, decimal Debit, decimal Credit, decimal RunningBalance, Guid Id);
public record StatementDto(Guid PatientId, string PatientName, decimal TotalCharged, decimal TotalPaid, decimal Balance,
    List<LedgerEntry> Entries);

public record DebtorDto(Guid PatientId, string PatientName, string? Phone, decimal TotalCharged, decimal TotalPaid, decimal Balance,
    DateTime? LastPayment);

// ---------- Appointments ----------
public record AppointmentDto(Guid Id, Guid PatientId, string PatientName, string? PatientPhone, Guid? StaffId, string? StaffName,
    Guid? ServiceItemId, string? ServiceName, DateTime StartsAt, int DurationMinutes, AppointmentStatus Status,
    string StatusLabel, string? Notes, bool RequestedByClient, DateTime? ReminderSentAt = null, string? ReminderChannel = null);
public record AppointmentUpsert([Required] Guid PatientId, Guid? StaffId, Guid? ServiceItemId, [Required] DateTime StartsAt,
    int DurationMinutes = 30, AppointmentStatus Status = AppointmentStatus.Planifikuar, string? Notes = null);
public record ClientAppointmentRequest(Guid? ServiceItemId, [Required] DateTime StartsAt, string? Notes);
public record SetStatusRequest(AppointmentStatus Status);

// ---------- Dashboard ----------
public record DashboardDto(int Patients, int NewPatientsThisMonth, int VisitsToday, int VisitsThisMonth, int AppointmentsToday,
    decimal RevenueThisMonth, decimal ChargedThisMonth, decimal TotalOutstanding, int Debtors,
    List<AppointmentDto> UpcomingToday, List<MonthPoint> Revenue6Months);
public record MonthPoint(string Month, decimal Charged, decimal Paid);

public record PagedResult<T>(List<T> Items, int Total, int Page, int PageSize);

// ---------- Imazhet / Rrezet X ----------
public record PatientFileDto(Guid Id, Guid PatientId, Guid? VisitId, string FileName, string ContentType, long SizeBytes,
    FileCategory Category, string CategoryLabel, string? Tooth, string? Notes, DateTime TakenAt, DateTime CreatedAt,
    bool IsImage, string? UploadedBy);
public record UpdateFileRequest(FileCategory Category, string? Tooth, string? Notes, DateTime? TakenAt, Guid? VisitId);

// ---------- Cilësimet e klinikës ----------
public record BusinessSettingsDto(string Name, string? NIPT, string? Address, string? City, string? Phone, string? Email,
    string TimeZone, string PhoneCountryCode, int ReminderHoursBefore, string ReminderTemplate, string DefaultReminderTemplate,
    string? InvoiceFooter, bool AutoRemindersAvailable, string AutoReminderChannel);
public record UpdateSettingsRequest(string? Address, string? City, string? Phone, string? Email, string? TimeZone,
    string? PhoneCountryCode, int ReminderHoursBefore, string? ReminderTemplate, string? InvoiceFooter);

// ---------- Kujtesat ----------
public record ReminderPreviewDto(string Text, string? Phone, string? WhatsAppUrl, string? SmsUrl, string? ViberUrl,
    bool AutoAvailable, DateTime? SentAt, string? Channel);
public record MarkRemindedRequest(string Channel);

// ---------- Odontogrami ----------
public record ToothDto(int Tooth, ToothCondition Condition, string ConditionLabel, string? Surfaces, string? Notes,
    DateTime UpdatedAt, string? UpdatedBy);
public record UpsertToothRequest(ToothCondition Condition, string? Surfaces, string? Notes);

// ---------- Planet e trajtimit ----------
public record PlanItemInput(Guid? ServiceItemId, string? Description, string? Tooth, decimal Quantity, decimal? UnitPrice, decimal Discount);
public record CreatePlanRequest([Required] Guid PatientId, [Required, MaxLength(200)] string Title, string? Notes, Guid? DoctorId,
    List<PlanItemInput> Items, int Installments = 1, DateOnly? FirstDueDate = null, int IntervalMonths = 1, bool Activate = false);
public record UpdatePlanRequest([Required, MaxLength(200)] string Title, string? Notes, Guid? DoctorId, List<PlanItemInput>? Items,
    int? Installments, DateOnly? FirstDueDate, int? IntervalMonths);
public record PlanItemDto(Guid Id, Guid? ServiceItemId, string Description, string? Tooth, decimal Quantity, decimal UnitPrice,
    decimal Discount, decimal Amount, bool Done, DateTime? DoneAt);
public record InstallmentDto(Guid Id, int Number, DateOnly DueDate, decimal Amount, DateTime? PaidAt, bool IsOverdue);
public record PlanDto(Guid Id, Guid PatientId, string PatientName, string Title, PlanStatus Status, string StatusLabel, string? Notes,
    Guid? DoctorId, string? DoctorName, decimal Total, decimal Paid, decimal Remaining, int ItemsDone, int ItemsTotal,
    int OverdueCount, DateOnly? NextDueDate, DateTime CreatedAt, DateTime? ActivatedAt, List<PlanItemDto> Items,
    List<InstallmentDto> Installments);
public record PayInstallmentRequest(PaymentMethod Method = PaymentMethod.Kesh, DateTime? Date = null, string? Reference = null);
public record OverdueInstallmentDto(Guid PlanId, string PlanTitle, Guid PatientId, string PatientName, string? Phone,
    Guid InstallmentId, int Number, DateOnly DueDate, decimal Amount, int DaysLate);

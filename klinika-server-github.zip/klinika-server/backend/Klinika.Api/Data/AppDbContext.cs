using Klinika.Api.Auth;
using Klinika.Api.Domain;
using Microsoft.EntityFrameworkCore;

namespace Klinika.Api.Data;

public class AppDbContext : DbContext
{
    private readonly Guid? _tenantId;

    public AppDbContext(DbContextOptions<AppDbContext> options, ICurrentUser? user = null) : base(options)
    {
        _tenantId = user?.BusinessId;
    }

    public DbSet<Business> Businesses => Set<Business>();
    public DbSet<User> Users => Set<User>();
    public DbSet<Patient> Patients => Set<Patient>();
    public DbSet<Visit> Visits => Set<Visit>();
    public DbSet<ServiceItem> Services => Set<ServiceItem>();
    public DbSet<Charge> Charges => Set<Charge>();
    public DbSet<Payment> Payments => Set<Payment>();
    public DbSet<Appointment> Appointments => Set<Appointment>();
    public DbSet<PatientFile> PatientFiles => Set<PatientFile>();
    public DbSet<ToothRecord> ToothRecords => Set<ToothRecord>();
    public DbSet<TreatmentPlan> TreatmentPlans => Set<TreatmentPlan>();
    public DbSet<TreatmentPlanItem> TreatmentPlanItems => Set<TreatmentPlanItem>();
    public DbSet<PlanInstallment> PlanInstallments => Set<PlanInstallment>();

    protected override void OnModelCreating(ModelBuilder b)
    {
        b.Entity<Business>(e =>
        {
            e.Property(x => x.Name).HasMaxLength(200).IsRequired();
            e.Property(x => x.Specialty).HasConversion<string>().HasMaxLength(40);
            e.Property(x => x.Currency).HasMaxLength(3);
            e.Property(x => x.CustomFieldsJson).HasColumnType("jsonb");
            e.Ignore(x => x.LogoUrl);
            e.Ignore(x => x.BackgroundUrl);
        });

        b.Entity<ToothRecord>(e =>
        {
            e.Property(x => x.Condition).HasConversion<string>().HasMaxLength(20);
            e.HasIndex(x => new { x.PatientId, x.Tooth }).IsUnique();
            e.HasOne(x => x.Patient).WithMany().HasForeignKey(x => x.PatientId).OnDelete(DeleteBehavior.Cascade);
        });

        b.Entity<TreatmentPlan>(e =>
        {
            e.Property(x => x.Status).HasConversion<string>().HasMaxLength(20);
            e.HasIndex(x => new { x.BusinessId, x.PatientId });
            e.HasOne(x => x.Patient).WithMany().HasForeignKey(x => x.PatientId).OnDelete(DeleteBehavior.Cascade);
            e.HasMany(x => x.Items).WithOne().HasForeignKey(x => x.PlanId).OnDelete(DeleteBehavior.Cascade);
            e.HasMany(x => x.Installments).WithOne().HasForeignKey(x => x.PlanId).OnDelete(DeleteBehavior.Cascade);
        });
        b.Entity<TreatmentPlanItem>(e =>
        {
            e.Property(x => x.Quantity).HasPrecision(10, 2);
            e.Property(x => x.UnitPrice).HasPrecision(12, 2);
            e.Property(x => x.Discount).HasPrecision(12, 2);
            e.Property(x => x.Amount).HasPrecision(12, 2);
        });
        b.Entity<PlanInstallment>(e =>
        {
            e.Property(x => x.Amount).HasPrecision(12, 2);
            e.HasIndex(x => new { x.BusinessId, x.DueDate });
        });

        b.Entity<PatientFile>(e =>
        {
            e.Property(x => x.Category).HasConversion<string>().HasMaxLength(20);
            e.HasIndex(x => new { x.BusinessId, x.PatientId });
            e.HasOne(x => x.Patient).WithMany().HasForeignKey(x => x.PatientId).OnDelete(DeleteBehavior.Cascade);
        });

        b.Entity<User>(e =>
        {
            e.HasIndex(x => x.Email).IsUnique();
            e.Property(x => x.Email).HasMaxLength(200).IsRequired();
            e.Property(x => x.Role).HasConversion<string>().HasMaxLength(20);
            e.HasOne(x => x.Business).WithMany(x => x.Users).HasForeignKey(x => x.BusinessId).OnDelete(DeleteBehavior.Cascade);
        });

        b.Entity<Patient>(e =>
        {
            e.HasIndex(x => new { x.BusinessId, x.LastName, x.FirstName });
            e.HasIndex(x => new { x.BusinessId, x.PersonalNumber });
            e.Property(x => x.Gender).HasConversion<string>().HasMaxLength(20);
        });

        b.Entity<Visit>(e =>
        {
            e.Property(x => x.FieldsJson).HasColumnType("jsonb");
            e.HasIndex(x => new { x.BusinessId, x.PatientId, x.VisitDate });
            e.HasOne(x => x.Patient).WithMany(x => x.Visits).HasForeignKey(x => x.PatientId).OnDelete(DeleteBehavior.Cascade);
            e.HasOne(x => x.Doctor).WithMany().HasForeignKey(x => x.DoctorId).OnDelete(DeleteBehavior.SetNull);
        });

        b.Entity<ServiceItem>(e => e.Property(x => x.Price).HasPrecision(12, 2));

        b.Entity<Charge>(e =>
        {
            e.Property(x => x.Amount).HasPrecision(12, 2);
            e.Property(x => x.UnitPrice).HasPrecision(12, 2);
            e.Property(x => x.Discount).HasPrecision(12, 2);
            e.Property(x => x.Quantity).HasPrecision(10, 2);
            e.HasIndex(x => new { x.BusinessId, x.PatientId });
            e.HasOne(x => x.Patient).WithMany(x => x.Charges).HasForeignKey(x => x.PatientId).OnDelete(DeleteBehavior.Cascade);
        });

        b.Entity<Payment>(e =>
        {
            e.Property(x => x.Amount).HasPrecision(12, 2);
            e.Property(x => x.Method).HasConversion<string>().HasMaxLength(20);
            e.HasIndex(x => new { x.BusinessId, x.PatientId });
            e.HasOne(x => x.Patient).WithMany(x => x.Payments).HasForeignKey(x => x.PatientId).OnDelete(DeleteBehavior.Cascade);
        });

        b.Entity<Appointment>(e =>
        {
            e.Property(x => x.Status).HasConversion<string>().HasMaxLength(20);
            e.HasIndex(x => new { x.BusinessId, x.StartsAt });
            e.HasOne(x => x.Patient).WithMany().HasForeignKey(x => x.PatientId).OnDelete(DeleteBehavior.Cascade);
            e.HasOne(x => x.Staff).WithMany().HasForeignKey(x => x.StaffId).OnDelete(DeleteBehavior.SetNull);
        });

        // Izolimi i të dhënave: çdo biznes sheh VETËM të dhënat e veta.
        // Super Admini përdor IgnoreQueryFilters() kur i duhet.
        b.Entity<Patient>().HasQueryFilter(x => x.BusinessId == _tenantId);
        b.Entity<Visit>().HasQueryFilter(x => x.BusinessId == _tenantId);
        b.Entity<ServiceItem>().HasQueryFilter(x => x.BusinessId == _tenantId);
        b.Entity<Charge>().HasQueryFilter(x => x.BusinessId == _tenantId);
        b.Entity<Payment>().HasQueryFilter(x => x.BusinessId == _tenantId);
        b.Entity<Appointment>().HasQueryFilter(x => x.BusinessId == _tenantId);
        b.Entity<PatientFile>().HasQueryFilter(x => x.BusinessId == _tenantId);
        b.Entity<ToothRecord>().HasQueryFilter(x => x.BusinessId == _tenantId);
        b.Entity<TreatmentPlan>().HasQueryFilter(x => x.BusinessId == _tenantId);
        b.Entity<TreatmentPlanItem>().HasQueryFilter(x => x.BusinessId == _tenantId);
        b.Entity<PlanInstallment>().HasQueryFilter(x => x.BusinessId == _tenantId);
    }

    public override Task<int> SaveChangesAsync(CancellationToken ct = default)
    {
        // Vendos automatikisht BusinessId në entitetet e reja dhe ndalon shkrimin në biznes tjetër.
        foreach (var entry in ChangeTracker.Entries<ITenantEntity>())
        {
            if (entry.State == EntityState.Added && entry.Entity.BusinessId == Guid.Empty && _tenantId is { } t)
                entry.Entity.BusinessId = t;

            if (entry.State is EntityState.Added or EntityState.Modified
                && _tenantId is { } tid && entry.Entity.BusinessId != tid)
                throw new AppException("Qasje e ndaluar në të dhënat e një biznesi tjetër.", 403);
        }
        return base.SaveChangesAsync(ct);
    }
}

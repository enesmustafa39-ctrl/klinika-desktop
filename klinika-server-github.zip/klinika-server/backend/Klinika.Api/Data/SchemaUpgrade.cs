using Microsoft.EntityFrameworkCore;

namespace Klinika.Api.Data;

/// <summary>
/// Përditëson automatikisht një databazë ekzistuese me kolonat/tabelat e reja (pa humbur të dhënat).
/// EnsureCreated() krijon vetëm databaza të reja; këto komanda janë të sigurta për t'u ekzekutuar çdo herë.
/// (Kur të kaloni te migrimet EF Core, kjo klasë mund të hiqet.)
/// </summary>
public static class SchemaUpgrade
{
    public static async Task RunAsync(AppDbContext db)
    {
        // v1.4 – versioni i seancave (çaktivizimi / ndryshimi i fjalëkalimit e mbyll seancën menjëherë)
        await db.Database.ExecuteSqlRawAsync("""
            ALTER TABLE "Users" ADD COLUMN IF NOT EXISTS "TokenVersion" integer NOT NULL DEFAULT 0;
            """);

        // v1.1 – funksionet për biznes + fushat e personalizuara
        // Bizneset ekzistuese ruajnë sjelljen e mëparshme (aplikacioni i klientit + rezervimet aktive).
        await db.Database.ExecuteSqlRawAsync("""
            ALTER TABLE "Businesses" ADD COLUMN IF NOT EXISTS "Features" text[] NOT NULL DEFAULT ARRAY['client_portal','online_booking']::text[];
            ALTER TABLE "Businesses" ADD COLUMN IF NOT EXISTS "CustomFieldsJson" jsonb NOT NULL DEFAULT '[]';
            """);

        // v1.3 – cilësimet e klinikës, kujtesat, odontogrami, planet e trajtimit
        await db.Database.ExecuteSqlRawAsync("""
            ALTER TABLE "Businesses" ADD COLUMN IF NOT EXISTS "TimeZone" text NOT NULL DEFAULT 'Europe/Tirane';
            ALTER TABLE "Businesses" ADD COLUMN IF NOT EXISTS "PhoneCountryCode" text NOT NULL DEFAULT '383';
            ALTER TABLE "Businesses" ADD COLUMN IF NOT EXISTS "ReminderHoursBefore" integer NOT NULL DEFAULT 24;
            ALTER TABLE "Businesses" ADD COLUMN IF NOT EXISTS "ReminderTemplate" text NULL;
            ALTER TABLE "Businesses" ADD COLUMN IF NOT EXISTS "InvoiceFooter" text NULL;
            ALTER TABLE "Appointments" ADD COLUMN IF NOT EXISTS "ReminderSentAt" timestamp with time zone NULL;
            ALTER TABLE "Appointments" ADD COLUMN IF NOT EXISTS "ReminderChannel" text NULL;

            CREATE TABLE IF NOT EXISTS "ToothRecords" (
                "Id" uuid NOT NULL PRIMARY KEY,
                "CreatedAt" timestamp with time zone NOT NULL,
                "BusinessId" uuid NOT NULL,
                "PatientId" uuid NOT NULL REFERENCES "Patients"("Id") ON DELETE CASCADE,
                "Tooth" integer NOT NULL,
                "Condition" character varying(20) NOT NULL,
                "Surfaces" text NULL,
                "Notes" text NULL,
                "UpdatedAt" timestamp with time zone NOT NULL,
                "UpdatedById" uuid NULL
            );
            CREATE UNIQUE INDEX IF NOT EXISTS "IX_ToothRecords_PatientId_Tooth" ON "ToothRecords" ("PatientId", "Tooth");

            CREATE TABLE IF NOT EXISTS "TreatmentPlans" (
                "Id" uuid NOT NULL PRIMARY KEY,
                "CreatedAt" timestamp with time zone NOT NULL,
                "BusinessId" uuid NOT NULL,
                "PatientId" uuid NOT NULL REFERENCES "Patients"("Id") ON DELETE CASCADE,
                "Title" text NOT NULL,
                "Status" character varying(20) NOT NULL,
                "Notes" text NULL,
                "DoctorId" uuid NULL,
                "ChargeId" uuid NULL,
                "ActivatedAt" timestamp with time zone NULL,
                "CreatedById" uuid NULL
            );
            CREATE INDEX IF NOT EXISTS "IX_TreatmentPlans_BusinessId_PatientId" ON "TreatmentPlans" ("BusinessId", "PatientId");
            CREATE INDEX IF NOT EXISTS "IX_TreatmentPlans_PatientId" ON "TreatmentPlans" ("PatientId");

            CREATE TABLE IF NOT EXISTS "TreatmentPlanItems" (
                "Id" uuid NOT NULL PRIMARY KEY,
                "CreatedAt" timestamp with time zone NOT NULL,
                "BusinessId" uuid NOT NULL,
                "PlanId" uuid NOT NULL REFERENCES "TreatmentPlans"("Id") ON DELETE CASCADE,
                "ServiceItemId" uuid NULL,
                "Description" text NOT NULL,
                "Tooth" text NULL,
                "Quantity" numeric(10,2) NOT NULL,
                "UnitPrice" numeric(12,2) NOT NULL,
                "Discount" numeric(12,2) NOT NULL,
                "Amount" numeric(12,2) NOT NULL,
                "Done" boolean NOT NULL,
                "DoneAt" timestamp with time zone NULL,
                "SortOrder" integer NOT NULL
            );
            CREATE INDEX IF NOT EXISTS "IX_TreatmentPlanItems_PlanId" ON "TreatmentPlanItems" ("PlanId");

            CREATE TABLE IF NOT EXISTS "PlanInstallments" (
                "Id" uuid NOT NULL PRIMARY KEY,
                "CreatedAt" timestamp with time zone NOT NULL,
                "BusinessId" uuid NOT NULL,
                "PlanId" uuid NOT NULL REFERENCES "TreatmentPlans"("Id") ON DELETE CASCADE,
                "Number" integer NOT NULL,
                "DueDate" date NOT NULL,
                "Amount" numeric(12,2) NOT NULL,
                "PaidAt" timestamp with time zone NULL,
                "PaymentId" uuid NULL
            );
            CREATE INDEX IF NOT EXISTS "IX_PlanInstallments_PlanId" ON "PlanInstallments" ("PlanId");
            CREATE INDEX IF NOT EXISTS "IX_PlanInstallments_BusinessId_DueDate" ON "PlanInstallments" ("BusinessId", "DueDate");
            """);

        // v1.2 – logo dhe sfondi i biznesit
        await db.Database.ExecuteSqlRawAsync("""
            ALTER TABLE "Businesses" ADD COLUMN IF NOT EXISTS "LogoPath" text NULL;
            ALTER TABLE "Businesses" ADD COLUMN IF NOT EXISTS "BackgroundPath" text NULL;
            ALTER TABLE "Businesses" ADD COLUMN IF NOT EXISTS "BrandingUpdatedAt" timestamp with time zone NULL;
            """);

        // v1.1 – Rrezet X & Imazhet
        await db.Database.ExecuteSqlRawAsync("""
            CREATE TABLE IF NOT EXISTS "PatientFiles" (
                "Id" uuid NOT NULL PRIMARY KEY,
                "CreatedAt" timestamp with time zone NOT NULL,
                "BusinessId" uuid NOT NULL,
                "PatientId" uuid NOT NULL REFERENCES "Patients"("Id") ON DELETE CASCADE,
                "VisitId" uuid NULL,
                "FileName" text NOT NULL,
                "ContentType" text NOT NULL,
                "SizeBytes" bigint NOT NULL,
                "Category" character varying(20) NOT NULL,
                "Tooth" text NULL,
                "Notes" text NULL,
                "StoragePath" text NOT NULL,
                "TakenAt" timestamp with time zone NOT NULL,
                "UploadedById" uuid NULL
            );
            CREATE INDEX IF NOT EXISTS "IX_PatientFiles_BusinessId_PatientId" ON "PatientFiles" ("BusinessId", "PatientId");
            CREATE INDEX IF NOT EXISTS "IX_PatientFiles_PatientId" ON "PatientFiles" ("PatientId");
            """);
    }
}

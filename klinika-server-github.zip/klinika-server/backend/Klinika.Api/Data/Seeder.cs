using Klinika.Api.Auth;
using Klinika.Api.Domain;
using Klinika.Api.Dtos;
using Klinika.Api.Services;
using Microsoft.EntityFrameworkCore;

namespace Klinika.Api.Data;

public static class Seeder
{
    public static async Task RunAsync(IServiceProvider sp, IConfiguration cfg, ILogger log)
    {
        using var scope = sp.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
        var pw = scope.ServiceProvider.GetRequiredService<Passwords>();

        await db.Database.EnsureCreatedAsync();
        await SchemaUpgrade.RunAsync(db);

        // 1) Super Admini i platformës
        if (!await db.Users.AnyAsync(u => u.Role == UserRole.SuperAdmin))
        {
            var saEmail = cfg["Seed:SuperAdminEmail"] is { Length: > 0 } e ? e.Trim().ToLowerInvariant() : "superadmin@klinika.al";
            // Pa fjalëkalim në konfigurim → krijohet një i rastësishëm dhe shfaqet VETËM një herë këtu.
            var configured = cfg["Seed:SuperAdminPassword"];
            var password = string.IsNullOrWhiteSpace(configured) ? SecretKeys.RandomPassword() : configured;
            var sa = new User { FullName = "Super Administrator", Email = saEmail, Role = UserRole.SuperAdmin };
            sa.PasswordHash = pw.Hash(sa, password);
            db.Users.Add(sa);
            await db.SaveChangesAsync();
            if (string.IsNullOrWhiteSpace(configured))
                log.LogWarning("Super Admin u krijua: {Email} / fjalëkalimi: {Password}  → Ndryshojeni te Profili pas hyrjes.", saEmail, password);
            else
                log.LogWarning("Super Admin u krijua: {Email}. Ndryshoni fjalëkalimin te Profili dhe hiqeni nga appsettings.", saEmail);
        }

        // 2) Të dhëna demo (opsionale)
        if (!cfg.GetValue("Seed:Demo", false) || await db.Businesses.AnyAsync()) return;

        var prov = scope.ServiceProvider.GetRequiredService<Provisioning>();
        var biz = await prov.CreateBusinessAsync(new CreateBusinessRequest(
            "Klinika Dentare Buzëqeshja", Specialty.Stomatologji, "L12345678A", "Rr. Dëshmorët e Kombit 10", "Tiranë",
            "+355 69 000 0000", "info@buzeqeshja.al", "EUR", null, 10, "Biznes demo",
            "Dr. Arben Hoxha", "admin@demo.al", "Demo1234!", true,
            new List<string> { Features.Imaging, Features.ClientPortal, Features.OnlineBooking,
                Features.Reminders, Features.Odontogram, Features.TreatmentPlans }));

        var doc = new User { BusinessId = biz.Id, FullName = "Dr. Elira Krasniqi", Email = "mjek@demo.al", Role = UserRole.Mjek, Title = "Ortodonte" };
        doc.PasswordHash = pw.Hash(doc, "Demo1234!");
        var rec = new User { BusinessId = biz.Id, FullName = "Sara Berisha", Email = "recepsion@demo.al", Role = UserRole.Recepsion };
        rec.PasswordHash = pw.Hash(rec, "Demo1234!");
        db.Users.AddRange(doc, rec);

        var p1 = new Patient { BusinessId = biz.Id, FirstName = "Blerina", LastName = "Gashi", Phone = "+355 68 111 2222",
            BirthDate = new DateOnly(1990, 4, 12), Gender = Gender.Femer, Allergies = "Penicilinë", Email = "klient@demo.al" };
        var p2 = new Patient { BusinessId = biz.Id, FirstName = "Ilir", LastName = "Shehu", Phone = "+355 69 333 4444",
            BirthDate = new DateOnly(1978, 11, 3), Gender = Gender.Mashkull };
        db.Patients.AddRange(p1, p2);

        var v = new Visit { BusinessId = biz.Id, PatientId = p1.Id, DoctorId = doc.Id, VisitDate = DateTime.UtcNow.AddDays(-10),
            Complaint = "Dhimbje në dhëmbin e sipërm djathtas", Diagnosis = "Karies i thellë 16", Treatment = "Mbushje kompozite",
            FieldsJson = "{\"dhembet\":\"16\",\"siperfaqja\":\"Okluzale\",\"anestezia\":\"Lokale\"}" };
        db.Visits.Add(v);
        db.Charges.Add(new Charge { BusinessId = biz.Id, PatientId = p1.Id, VisitId = v.Id, Description = "Mbushje kompozite",
            UnitPrice = 45, Quantity = 1, Amount = 45, Date = v.VisitDate });
        db.Charges.Add(new Charge { BusinessId = biz.Id, PatientId = p1.Id, Description = "Pastrim guri (Higjienë)",
            UnitPrice = 40, Quantity = 1, Amount = 40, Date = DateTime.UtcNow.AddDays(-3) });
        db.Payments.Add(new Payment { BusinessId = biz.Id, PatientId = p1.Id, Amount = 50, Method = PaymentMethod.Kesh,
            Date = DateTime.UtcNow.AddDays(-10) });
        db.Appointments.Add(new Appointment { BusinessId = biz.Id, PatientId = p2.Id, StaffId = doc.Id,
            StartsAt = DateTime.UtcNow.Date.AddHours(12), DurationMinutes = 30, Notes = "Kontroll" });

        var client = new User { BusinessId = biz.Id, FullName = "Blerina Gashi", Email = "klient@demo.al", Role = UserRole.Klient, PatientId = p1.Id };
        client.PasswordHash = pw.Hash(client, "Demo1234!");
        db.Users.Add(client);

        await db.SaveChangesAsync();
        log.LogInformation("Të dhënat demo u krijuan (admin@demo.al / Demo1234!).");
    }
}

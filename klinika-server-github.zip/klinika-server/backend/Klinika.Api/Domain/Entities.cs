namespace Klinika.Api.Domain;

/// <summary>Çdo entitet që i përket një biznesi (tenant).</summary>
public interface ITenantEntity
{
    Guid BusinessId { get; set; }
}

public abstract class BaseEntity
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}

/// <summary>Biznesi / Klinika e regjistruar nga Super Admini.</summary>
public class Business : BaseEntity
{
    public string Name { get; set; } = "";
    public Specialty Specialty { get; set; }
    public string? NIPT { get; set; }            // Numri fiskal
    public string? Address { get; set; }
    public string? City { get; set; }
    public string? Phone { get; set; }
    public string? Email { get; set; }
    public string Currency { get; set; } = "EUR";
    public bool IsActive { get; set; } = true;   // Qasja: aktiv / pezulluar
    public DateTime? AccessUntil { get; set; }   // Afati i abonimit (opsional)
    public int MaxStaff { get; set; } = 20;
    public string? Notes { get; set; }
    /// <summary>Funksionet shtesë të aktivizuara VETËM për këtë biznes (shih Domain/Features.cs).</summary>
    public List<string> Features { get; set; } = new();
    /// <summary>Fushat e personalizuara të kartelës vetëm për këtë biznes (JSON listë FieldDef).</summary>
    public string CustomFieldsJson { get; set; } = "[]";
    /// <summary>Logo dhe foto e sfondit (ngarkohen nga Super Admini). Rrugë relative në disk.</summary>
    public string? LogoPath { get; set; }
    public string? BackgroundPath { get; set; }
    public DateTime? BrandingUpdatedAt { get; set; }

    // ---- Cilësimet e klinikës (i ndryshon Administratori) ----
    /// <summary>Zona kohore e klinikës (për orët në kujtesa dhe printime).</summary>
    public string TimeZone { get; set; } = "Europe/Tirane";
    /// <summary>Prefiksi i shtetit për numrat e telefonit (p.sh. 383 Kosovë, 355 Shqipëri, 389 Maqedoni).</summary>
    public string PhoneCountryCode { get; set; } = "383";
    /// <summary>Sa orë para terminit dërgohet kujtesa automatike.</summary>
    public int ReminderHoursBefore { get; set; } = 24;
    /// <summary>Teksti i kujtesës. Fusha: {pacienti} {klinika} {data} {ora} {mjeku} {sherbimi} {telefoni}</summary>
    public string? ReminderTemplate { get; set; }
    /// <summary>Teksti në fund të faturës (p.sh. llogaria bankare).</summary>
    public string? InvoiceFooter { get; set; }

    public string? LogoUrl => LogoPath is null ? null : $"/api/branding/{Id}/logo?v={BrandingUpdatedAt?.Ticks ?? 0}";
    public string? BackgroundUrl => BackgroundPath is null ? null : $"/api/branding/{Id}/background?v={BrandingUpdatedAt?.Ticks ?? 0}";

    public List<User> Users { get; set; } = new();

    public bool Has(string feature) => Features.Contains(feature);
}

public class User : BaseEntity
{
    public Guid? BusinessId { get; set; }        // null vetëm për SuperAdmin
    public Business? Business { get; set; }
    public string FullName { get; set; } = "";
    public string Email { get; set; } = "";
    public string? Phone { get; set; }
    public string PasswordHash { get; set; } = "";
    public UserRole Role { get; set; }
    public string? Title { get; set; }           // p.sh. "Dr.", "Specialist ortodont"
    public bool IsActive { get; set; } = true;
    public Guid? PatientId { get; set; }         // vetëm për rolin Klient
    public DateTime? LastLoginAt { get; set; }
    /// <summary>Rritet kur ndryshon fjalëkalimi, roli ose statusi: të gjitha seancat e vjetra bëhen të pavlefshme.</summary>
    public int TokenVersion { get; set; }
}

public class Patient : BaseEntity, ITenantEntity
{
    public Guid BusinessId { get; set; }
    public string FirstName { get; set; } = "";
    public string LastName { get; set; } = "";
    public string? PersonalNumber { get; set; }  // Nr. personal / ID
    public DateOnly? BirthDate { get; set; }
    public Gender? Gender { get; set; }
    public string? Phone { get; set; }
    public string? Email { get; set; }
    public string? Address { get; set; }
    public string? BloodType { get; set; }
    public string? Allergies { get; set; }        // Alergjitë
    public string? ChronicConditions { get; set; }// Sëmundjet kronike
    public string? Notes { get; set; }
    public bool IsArchived { get; set; }

    public List<Visit> Visits { get; set; } = new();
    public List<Charge> Charges { get; set; } = new();
    public List<Payment> Payments { get; set; } = new();
}

/// <summary>Vizita / regjistrim në historikun mjekësor.</summary>
public class Visit : BaseEntity, ITenantEntity
{
    public Guid BusinessId { get; set; }
    public Guid PatientId { get; set; }
    public Patient? Patient { get; set; }
    public Guid? DoctorId { get; set; }
    public User? Doctor { get; set; }
    public DateTime VisitDate { get; set; } = DateTime.UtcNow;
    public string? Complaint { get; set; }        // Ankesa
    public string? Diagnosis { get; set; }        // Diagnoza
    public string? Treatment { get; set; }        // Trajtimi
    public string? Prescription { get; set; }     // Receta
    public string? Notes { get; set; }
    /// <summary>Fushat specifike sipas specialitetit (JSON), p.sh. {"dhembi":"16","siperfaqja":"okluzale"}</summary>
    public string FieldsJson { get; set; } = "{}";
    public DateOnly? NextVisitDate { get; set; }
}

/// <summary>Katalogu i shërbimeve me çmime për çdo biznes.</summary>
public class ServiceItem : BaseEntity, ITenantEntity
{
    public Guid BusinessId { get; set; }
    public string Name { get; set; } = "";
    public string? Category { get; set; }
    public decimal Price { get; set; }
    public int DurationMinutes { get; set; } = 30;
    public bool IsActive { get; set; } = true;
}

/// <summary>Ngarkesë (detyrim) ndaj pacientit.</summary>
public class Charge : BaseEntity, ITenantEntity
{
    public Guid BusinessId { get; set; }
    public Guid PatientId { get; set; }
    public Patient? Patient { get; set; }
    public Guid? VisitId { get; set; }
    public Guid? ServiceItemId { get; set; }
    public string Description { get; set; } = "";
    public decimal Quantity { get; set; } = 1;
    public decimal UnitPrice { get; set; }
    public decimal Discount { get; set; }
    public decimal Amount { get; set; }           // = Quantity*UnitPrice - Discount
    public DateTime Date { get; set; } = DateTime.UtcNow;
    public Guid? CreatedById { get; set; }
}

/// <summary>Pagesë e bërë nga pacienti.</summary>
public class Payment : BaseEntity, ITenantEntity
{
    public Guid BusinessId { get; set; }
    public Guid PatientId { get; set; }
    public Patient? Patient { get; set; }
    public decimal Amount { get; set; }
    public PaymentMethod Method { get; set; } = PaymentMethod.Kesh;
    public DateTime Date { get; set; } = DateTime.UtcNow;
    public string? Reference { get; set; }
    public string? Notes { get; set; }
    public Guid? CreatedById { get; set; }
}

public class Appointment : BaseEntity, ITenantEntity
{
    public Guid BusinessId { get; set; }
    public Guid PatientId { get; set; }
    public Patient? Patient { get; set; }
    public Guid? StaffId { get; set; }
    public User? Staff { get; set; }
    public Guid? ServiceItemId { get; set; }
    public DateTime StartsAt { get; set; }
    public int DurationMinutes { get; set; } = 30;
    public AppointmentStatus Status { get; set; } = AppointmentStatus.Planifikuar;
    public string? Notes { get; set; }
    public bool RequestedByClient { get; set; }
    /// <summary>Kur u dërgua kujtesa dhe nga cili kanal (sms / whatsapp / viber / auto-sms ...).</summary>
    public DateTime? ReminderSentAt { get; set; }
    public string? ReminderChannel { get; set; }
}

/// <summary>Rreze X, OPG, CBCT, foto ose dokument i ngarkuar në kartelën e pacientit.</summary>
public class PatientFile : BaseEntity, ITenantEntity
{
    public Guid BusinessId { get; set; }
    public Guid PatientId { get; set; }
    public Patient? Patient { get; set; }
    public Guid? VisitId { get; set; }
    public string FileName { get; set; } = "";
    public string ContentType { get; set; } = "";
    public long SizeBytes { get; set; }
    public FileCategory Category { get; set; } = FileCategory.RrezeX;
    public string? Tooth { get; set; }            // p.sh. "16" ose "11-21" (stomatologji)
    public string? Notes { get; set; }
    public string StoragePath { get; set; } = ""; // rruga relative në disk
    public DateTime TakenAt { get; set; } = DateTime.UtcNow;
    public Guid? UploadedById { get; set; }
}

/// <summary>Gjendja aktuale e një dhëmbi (odontogrami). Një rresht për çdo dhëmb të ndryshuar.</summary>
public class ToothRecord : BaseEntity, ITenantEntity
{
    public Guid BusinessId { get; set; }
    public Guid PatientId { get; set; }
    public Patient? Patient { get; set; }
    /// <summary>Numri FDI: 11–18, 21–28, 31–38, 41–48 (të rriturit) ose 51–85 (fëmijët).</summary>
    public int Tooth { get; set; }
    public ToothCondition Condition { get; set; }
    /// <summary>Sipërfaqet: M, O, D, B, L (p.sh. "MO").</summary>
    public string? Surfaces { get; set; }
    public string? Notes { get; set; }
    public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
    public Guid? UpdatedById { get; set; }
}

/// <summary>Plani i trajtimit (p.sh. "Implant 3 seanca – 700 €, 3 këste").</summary>
public class TreatmentPlan : BaseEntity, ITenantEntity
{
    public Guid BusinessId { get; set; }
    public Guid PatientId { get; set; }
    public Patient? Patient { get; set; }
    public string Title { get; set; } = "";
    public PlanStatus Status { get; set; } = PlanStatus.Propozuar;
    public string? Notes { get; set; }
    public Guid? DoctorId { get; set; }
    /// <summary>Ngarkesa që u krijua kur plani u aktivizua.</summary>
    public Guid? ChargeId { get; set; }
    public DateTime? ActivatedAt { get; set; }
    public Guid? CreatedById { get; set; }
    public List<TreatmentPlanItem> Items { get; set; } = new();
    public List<PlanInstallment> Installments { get; set; } = new();
}

public class TreatmentPlanItem : BaseEntity, ITenantEntity
{
    public Guid BusinessId { get; set; }
    public Guid PlanId { get; set; }
    public Guid? ServiceItemId { get; set; }
    public string Description { get; set; } = "";
    public string? Tooth { get; set; }
    public decimal Quantity { get; set; } = 1;
    public decimal UnitPrice { get; set; }
    public decimal Discount { get; set; }
    public decimal Amount { get; set; }
    public bool Done { get; set; }
    public DateTime? DoneAt { get; set; }
    public int SortOrder { get; set; }
}

public class PlanInstallment : BaseEntity, ITenantEntity
{
    public Guid BusinessId { get; set; }
    public Guid PlanId { get; set; }
    public int Number { get; set; }
    public DateOnly DueDate { get; set; }
    public decimal Amount { get; set; }
    public DateTime? PaidAt { get; set; }
    public Guid? PaymentId { get; set; }
}

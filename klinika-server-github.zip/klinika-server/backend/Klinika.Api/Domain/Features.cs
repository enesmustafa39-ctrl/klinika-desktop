using System.Text.Json;

namespace Klinika.Api.Domain;

public record FeatureInfo(string Key, string Label, string Description, Specialty[] RecommendedFor);

/// <summary>
/// Modulet / funksionet shtesë që Super Admini i aktivizon VEÇMAS për çdo biznes.
/// P.sh. dy klinika dentare: njëra ka "Rrezet X", tjetra jo.
/// Për të shtuar një funksion të ri: shtoni një rresht këtu dhe kontrolloni me [RequireFeature(Features.XYZ)].
/// </summary>
public static class Features
{
    public const string Imaging = "imaging";
    public const string ClientPortal = "client_portal";
    public const string OnlineBooking = "online_booking";
    public const string Reminders = "reminders";
    public const string Odontogram = "odontogram";
    public const string TreatmentPlans = "treatment_plans";

    public static readonly FeatureInfo[] All =
    {
        new(Imaging, "Rrezet X & Imazhet",
            "Ngarkim dhe shikim i rrezeve X, OPG, CBCT, fotove dhe dokumenteve në kartelën e pacientit (me zmadhim, kontrast, negativ).",
            new[] { Specialty.Stomatologji, Specialty.Ortopedi, Specialty.Kardiologji, Specialty.Dermatologji }),
        new(ClientPortal, "Aplikacioni i klientit",
            "Pacientët hyjnë në aplikacionin mobil dhe shohin historikun, borxhin dhe terminet e tyre.",
            Array.Empty<Specialty>()),
        new(Reminders, "Kujtesa për terminet (SMS / WhatsApp / Viber)",
            "Kujtesë automatike me SMS para terminit (nëse platforma ka ofrues SMS) dhe butona për ta dërguar me një klik në WhatsApp, Viber ose SMS.",
            Array.Empty<Specialty>()),
        new(Odontogram, "Odontogrami",
            "Skema grafike e dhëmbëve: karies, mbushje, kurorë, implant, kanal, heqje – me ngjyra, sipërfaqe dhe shënime.",
            new[] { Specialty.Stomatologji }),
        new(TreatmentPlans, "Planet e trajtimit & këstet",
            "Plane me shumë seanca (p.sh. implant 700 € në 3 këste); ndjekja e progresit, kësteve të paguara dhe atyre me vonesë.",
            new[] { Specialty.Stomatologji, Specialty.Ortopedi, Specialty.Fizioterapi, Specialty.Dermatologji }),
        new(OnlineBooking, "Rezervim termini nga aplikacioni",
            "Pacientët dërgojnë kërkesë për termin nga aplikacioni; stafi e konfirmon.",
            Array.Empty<Specialty>()),
    };

    /// <summary>Funksionet që marrin bizneset e reja nëse nuk zgjidhet asgjë.</summary>
    public static readonly string[] Defaults = { ClientPortal, OnlineBooking };

    public static bool IsKnown(string key) => All.Any(f => f.Key == key);
    public static string Label(string key) => All.FirstOrDefault(f => f.Key == key)?.Label ?? key;
}

/// <summary>Konfigurimi efektiv i një biznesi: fushat e specialitetit + fushat e personalizuara vetëm për të.</summary>
public static class BusinessConfig
{
    private static readonly JsonSerializerOptions Json = new(JsonSerializerDefaults.Web);

    public static List<FieldDef> CustomFields(Business b)
    {
        try { return JsonSerializer.Deserialize<List<FieldDef>>(b.CustomFieldsJson, Json) ?? new(); }
        catch { return new(); }
    }

    public static string SerializeCustomFields(IEnumerable<FieldDef> fields) => JsonSerializer.Serialize(fields, Json);

    public static FieldDef[] VisitFields(Business b) =>
        SpecialtyCatalog.Get(b.Specialty).VisitFields.Concat(CustomFields(b)).ToArray();
}

namespace Klinika.Api.Domain;

public record FieldDef(string Key, string Label, string Type = "text", string[]? Options = null);
public record ServiceTemplate(string Name, string Category, decimal Price, int DurationMinutes = 30);
public record SpecialtyTemplate(Specialty Specialty, string Label, string DoctorLabel, FieldDef[] VisitFields, ServiceTemplate[] Services);

/// <summary>
/// Konfigurimi i çdo specialiteti. Kur Super Admini regjistron një biznes dhe zgjedh p.sh. "Mjek Familjeje",
/// sistemi krijon automatikisht shërbimet fillestare dhe kartela e vizitës shfaq fushat përkatëse.
/// Për të shtuar një specialitet të ri: shtoni vlerën në enum Specialty dhe një rresht këtu.
/// </summary>
public static class SpecialtyCatalog
{
    static readonly FieldDef[] Vitals =
    {
        new("tensioni", "Tensioni (mmHg)"),
        new("pulsi", "Pulsi (rrahje/min)", "number"),
        new("temperatura", "Temperatura (°C)", "number"),
        new("pesha", "Pesha (kg)", "number"),
        new("gjatesia", "Gjatësia (cm)", "number"),
    };

    public static readonly SpecialtyTemplate[] All =
    {
        new(Specialty.Stomatologji, "Stomatologji (Dentist)", "Stomatolog",
            new FieldDef[]
            {
                new("dhembet", "Dhëmbët (nr. FDI, p.sh. 16, 21)"),
                new("siperfaqja", "Sipërfaqja", "select", new[]{"Okluzale","Meziale","Distale","Bukale","Linguale"}),
                new("anestezia", "Anestezia", "select", new[]{"Jo","Lokale","Infiltrative"}),
                new("rrezet_x", "Rrezet X / OPG", "text"),
            },
            new ServiceTemplate[]
            {
                new("Kontroll dhe konsultë", "Konsultë", 15, 20),
                new("Pastrim guri (Higjienë)", "Higjienë", 40, 45),
                new("Mbushje kompozite", "Konservative", 45, 45),
                new("Trajtim kanali (Endodonci)", "Endodonci", 120, 60),
                new("Heqje dhëmbi", "Kirurgji", 35, 30),
                new("Kurorë qeramike", "Protetikë", 250, 60),
                new("Implant", "Implantologji", 700, 90),
                new("Zbardhim", "Estetikë", 150, 60),
                new("Radiografi OPG", "Diagnostikë", 25, 10),
            }),
        new(Specialty.Kardiologji, "Kardiologji", "Kardiolog",
            Vitals.Concat(new FieldDef[]
            {
                new("ekg", "EKG - përfundimi"),
                new("eko", "Ekokardiografia"),
                new("kolesteroli", "Kolesteroli (mg/dL)", "number"),
                new("rreziku", "Rreziku kardiovaskular", "select", new[]{"I ulët","Mesatar","I lartë"}),
            }).ToArray(),
            new ServiceTemplate[]
            {
                new("Konsultë kardiologjike", "Konsultë", 40, 30),
                new("EKG", "Diagnostikë", 20, 15),
                new("Ekokardiografi", "Diagnostikë", 60, 30),
                new("Holter EKG 24h", "Diagnostikë", 80, 20),
                new("Holter tensioni 24h", "Diagnostikë", 70, 20),
                new("Test ngarkese", "Diagnostikë", 90, 45),
            }),
        new(Specialty.Ortopedi, "Ortopedi", "Ortoped",
            new FieldDef[]
            {
                new("zona", "Zona e trupit", "select", new[]{"Gjuri","Kofsha","Shpina","Supi","Bërryli","Dora","Këmba","Qafa"}),
                new("ana", "Ana", "select", new[]{"Majtas","Djathtas","Të dyja"}),
                new("dhimbja", "Dhimbja (0-10)", "number"),
                new("imazheria", "Rrezet X / MRI / CT"),
                new("imobilizimi", "Imobilizim / Gips"),
            },
            new ServiceTemplate[]
            {
                new("Konsultë ortopedike", "Konsultë", 35, 30),
                new("Rrezet X", "Diagnostikë", 20, 15),
                new("Vendosje gipsi", "Procedurë", 50, 30),
                new("Infiltrim në nyje", "Procedurë", 60, 20),
                new("Heqje gipsi", "Procedurë", 20, 15),
                new("Seancë fizioterapie", "Rehabilitim", 25, 45),
            }),
        new(Specialty.MjekFamiljes, "Mjek Familjeje", "Mjek familjeje",
            Vitals.Concat(new FieldDef[]
            {
                new("glicemia", "Glicemia (mg/dL)", "number"),
                new("analizat", "Analizat e rekomanduara"),
                new("referim", "Referim te specialisti"),
            }).ToArray(),
            new ServiceTemplate[]
            {
                new("Vizitë e përgjithshme", "Konsultë", 20, 20),
                new("Kontroll periodik", "Konsultë", 15, 15),
                new("Matje tensioni / glicemie", "Procedurë", 5, 10),
                new("Injeksion / terapi", "Procedurë", 10, 15),
                new("Vërtetim mjekësor", "Dokument", 10, 10),
                new("Vizitë në shtëpi", "Konsultë", 40, 45),
            }),
        new(Specialty.Pediatri, "Pediatri", "Pediatër",
            Vitals.Concat(new FieldDef[]
            {
                new("perimetri_kokes", "Perimetri i kokës (cm)", "number"),
                new("vaksinat", "Vaksinat"),
            }).ToArray(),
            new ServiceTemplate[]
            {
                new("Vizitë pediatrike", "Konsultë", 25, 20),
                new("Kontroll zhvillimi", "Konsultë", 20, 20),
                new("Vaksinim", "Procedurë", 15, 15),
            }),
        new(Specialty.Dermatologji, "Dermatologji", "Dermatolog",
            new FieldDef[]
            {
                new("zona", "Zona e lëkurës"),
                new("lloji_lezionit", "Lloji i lezionit"),
                new("dermoskopia", "Dermoskopia"),
            },
            new ServiceTemplate[]
            {
                new("Konsultë dermatologjike", "Konsultë", 30, 20),
                new("Dermoskopi", "Diagnostikë", 30, 20),
                new("Krioterapi", "Procedurë", 40, 20),
            }),
        new(Specialty.Oftalmologji, "Oftalmologji", "Oftalmolog",
            new FieldDef[]
            {
                new("visus_od", "Visus OD (syri djathtë)"),
                new("visus_os", "Visus OS (syri majtë)"),
                new("presioni_od", "Presioni intraokular OD", "number"),
                new("presioni_os", "Presioni intraokular OS", "number"),
                new("dioptria", "Dioptria / syzet"),
            },
            new ServiceTemplate[]
            {
                new("Kontroll i syve", "Konsultë", 30, 20),
                new("Matje e presionit", "Diagnostikë", 15, 10),
                new("Përshkrim syzesh", "Konsultë", 20, 15),
            }),
        new(Specialty.Gjinekologji, "Gjinekologji", "Gjinekolog",
            new FieldDef[]
            {
                new("cikli", "Data e ciklit të fundit", "date"),
                new("shtatzania", "Java e shtatzënisë", "number"),
                new("eko", "Ekografia"),
                new("pap", "PAP test"),
            },
            new ServiceTemplate[]
            {
                new("Vizitë gjinekologjike", "Konsultë", 35, 30),
                new("Ekografi", "Diagnostikë", 40, 20),
                new("PAP test", "Diagnostikë", 30, 15),
            }),
        new(Specialty.Fizioterapi, "Fizioterapi", "Fizioterapist",
            new FieldDef[]
            {
                new("zona", "Zona e trajtimit"),
                new("seanca_nr", "Seanca nr.", "number"),
                new("dhimbja", "Dhimbja (0-10)", "number"),
            },
            new ServiceTemplate[]
            {
                new("Seancë fizioterapie", "Terapi", 25, 45),
                new("Masazh terapeutik", "Terapi", 30, 45),
                new("Elektroterapi", "Terapi", 15, 20),
            }),
        new(Specialty.Neurologji, "Neurologji", "Neurolog",
            new FieldDef[]
            {
                new("refleksat", "Refleksat"),
                new("eeg", "EEG"),
                new("emg", "EMG"),
            },
            new ServiceTemplate[]
            {
                new("Konsultë neurologjike", "Konsultë", 40, 30),
                new("EEG", "Diagnostikë", 60, 45),
                new("EMG", "Diagnostikë", 70, 45),
            }),
        new(Specialty.Tjeter, "Tjetër", "Mjek",
            Vitals,
            new ServiceTemplate[] { new("Konsultë", "Konsultë", 25, 30) }),
    };

    public static SpecialtyTemplate Get(Specialty s) => All.FirstOrDefault(t => t.Specialty == s) ?? All[^1];
}

namespace Klinika.Api.Domain;

/// <summary>Specialiteti i biznesit. Përcakton shërbimet fillestare dhe fushat e kartelës.</summary>
public enum Specialty
{
    Stomatologji = 1,     // Dentist
    Kardiologji = 2,      // Heart doctor
    Ortopedi = 3,         // Bone doctor
    MjekFamiljes = 4,     // Family doctor
    Pediatri = 5,
    Dermatologji = 6,
    Oftalmologji = 7,
    Gjinekologji = 8,
    Fizioterapi = 9,
    Neurologji = 10,
    Tjeter = 99
}

public enum UserRole
{
    SuperAdmin = 1,   // Pronari i platformës
    Admin = 2,        // Administratori i biznesit (p.sh. pronari i klinikës dentare)
    Mjek = 3,         // Doktor
    Infermier = 4,    // Infermier/e
    Recepsion = 5,    // Recepsionist/e
    Klient = 6        // Pacienti (moduli i klientit)
}

public enum AppointmentStatus
{
    Planifikuar = 1,
    Konfirmuar = 2,
    Perfunduar = 3,
    Anuluar = 4,
    NukErdhi = 5
}

public enum PaymentMethod
{
    Kesh = 1,
    Kartele = 2,
    Transfer = 3,
    Sigurim = 4
}

public enum FileCategory
{
    RrezeX = 1,     // Rreze X periapikale / bitewing
    OPG = 2,        // Panoramike
    CBCT = 3,       // 3D / skaner
    Ekografi = 4,
    Foto = 5,       // Foto klinike / intraorale
    Dokument = 6,   // Analiza, raporte, PDF
    Tjeter = 9
}

/// <summary>Gjendja e një dhëmbi në odontogram.</summary>
public enum ToothCondition
{
    Shendoshe = 0,     // I shëndoshë
    Karies = 1,
    Mbushje = 2,
    Kurore = 3,        // Kurorë
    Ure = 4,           // Element ure
    Implant = 5,
    Kanal = 6,         // Trajtim kanali (endodonci)
    Mungon = 7,        // I hequr / mungon
    PerHeqje = 8,      // Për t'u hequr
    Fraktura = 9,
    Tjeter = 99
}

/// <summary>Statusi i planit të trajtimit.</summary>
public enum PlanStatus
{
    Propozuar = 1,     // I propozuar, ende pa u pranuar nga pacienti
    Aktiv = 2,         // I pranuar – shuma është ngarkuar në llogari
    Perfunduar = 3,
    Anuluar = 4
}

public enum Gender
{
    Mashkull = 1,
    Femer = 2,
    Tjeter = 3
}

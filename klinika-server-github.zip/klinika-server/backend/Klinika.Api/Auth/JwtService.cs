using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Klinika.Api.Domain;
using Microsoft.IdentityModel.Tokens;

namespace Klinika.Api.Auth;

public class JwtOptions
{
    public string Issuer { get; set; } = "klinika";
    public string Audience { get; set; } = "klinika";
    public string Key { get; set; } = "";
    public int ExpiresHours { get; set; } = 12;
    public int RememberMeDays { get; set; } = 30;
}

public class JwtService
{
    private readonly JwtOptions _o;
    public JwtService(JwtOptions o) => _o = o;

    public (string token, DateTime expires) Create(User u, Business? b, bool rememberMe = false)
    {
        var claims = new List<Claim>
        {
            new(ClaimTypes.NameIdentifier, u.Id.ToString()),
            new(ClaimTypes.Name, u.FullName),
            new(ClaimTypes.Email, u.Email),
            new(ClaimTypes.Role, u.Role.ToString()),
            new(AppClaims.TokenVersion, u.TokenVersion.ToString()),
            new(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString("N")),
        };
        if (u.BusinessId is { } bid) claims.Add(new(AppClaims.BusinessId, bid.ToString()));
        if (u.PatientId is { } pid) claims.Add(new(AppClaims.PatientId, pid.ToString()));
        if (b is not null) claims.Add(new(AppClaims.Specialty, b.Specialty.ToString()));

        var expires = rememberMe ? DateTime.UtcNow.AddDays(_o.RememberMeDays) : DateTime.UtcNow.AddHours(_o.ExpiresHours);
        var creds = new SigningCredentials(new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_o.Key)), SecurityAlgorithms.HmacSha256);
        var jwt = new JwtSecurityToken(_o.Issuer, _o.Audience, claims, expires: expires, signingCredentials: creds);
        return (new JwtSecurityTokenHandler().WriteToken(jwt), expires);
    }
}

using System.ComponentModel.DataAnnotations;
using System.Security.Cryptography;
using Microsoft.Extensions.Caching.Memory;

namespace Klinika.Api.Auth;

/// <summary>Gabim me mesazh që i shfaqet përdoruesit (400). Gabimet e tjera kthejnë mesazh të përgjithshëm.</summary>
public class AppException : Exception
{
    public int Status { get; }
    public AppException(string message, int status = 400) : base(message) => Status = status;
}

/// <summary>Fjalëkalim i fortë: të paktën 8 karaktere, me shkronja dhe numra.</summary>
[AttributeUsage(AttributeTargets.Property | AttributeTargets.Parameter | AttributeTargets.Field)]
public sealed class StrongPasswordAttribute : ValidationAttribute
{
    public const int MinLength = 8;
    public const int MaxLength = 128;

    public static string? Check(string? pwd)
    {
        if (string.IsNullOrEmpty(pwd) || pwd.Length < MinLength) return $"Fjalëkalimi duhet të ketë të paktën {MinLength} karaktere.";
        if (pwd.Length > MaxLength) return $"Fjalëkalimi mund të ketë deri në {MaxLength} karaktere.";
        if (!pwd.Any(char.IsLetter) || !pwd.Any(char.IsDigit)) return "Fjalëkalimi duhet të përmbajë shkronja dhe numra.";
        if (Common.Contains(pwd.ToLowerInvariant())) return "Ky fjalëkalim është shumë i thjeshtë. Zgjidhni një tjetër.";
        return null;
    }

    private static readonly HashSet<string> Common = new()
    {
        "password1", "password123", "12345678a", "a12345678", "qwerty123", "admin123", "admin1234", "admin123!",
        "abc12345", "abcd1234", "1q2w3e4r", "passw0rd", "klinika1", "klinika123", "fjalekalimi1",
    };

    protected override ValidationResult? IsValid(object? value, ValidationContext ctx)
    {
        var err = Check(value as string);
        return err is null ? ValidationResult.Success : new ValidationResult(err);
    }
}

/// <summary>
/// Mbrojtje nga provat e shumta të fjalëkalimit: pas 5 dështimesh për një email,
/// llogaria bllokohet përkohësisht për 15 minuta (vetëm për hyrjet, jo për seancat ekzistuese).
/// </summary>
public class LoginGuard
{
    private const int MaxFailures = 5;
    private static readonly TimeSpan Window = TimeSpan.FromMinutes(15);
    private readonly IMemoryCache _cache;
    public LoginGuard(IMemoryCache cache) => _cache = cache;

    private sealed class Entry { public int Failures; public DateTime? LockedUntil; }
    private static string Key(string email) => $"login-fail:{email}";

    public TimeSpan? LockedFor(string email)
    {
        if (_cache.TryGetValue(Key(email), out Entry? e) && e!.LockedUntil is { } until && until > DateTime.UtcNow)
            return until - DateTime.UtcNow;
        return null;
    }

    public void Failed(string email)
    {
        var e = _cache.GetOrCreate(Key(email), c => { c.AbsoluteExpirationRelativeToNow = Window; return new Entry(); })!;
        lock (e)
        {
            e.Failures++;
            if (e.Failures >= MaxFailures)
            {
                e.LockedUntil = DateTime.UtcNow.Add(Window);
                _cache.Set(Key(email), e, Window); // bllokimi zgjat plot 15 minuta nga prova e fundit
            }
        }
    }

    public void Succeeded(string email) => _cache.Remove(Key(email));
}

/// <summary>Çelësat sekretë të serverit.</summary>
public static class SecretKeys
{
    // Vlerat shembull të versioneve të vjetra – trajtohen si çelës që mungon.
    private static readonly string[] Samples = { "NDRYSHO-KETE", "ndrysho-kete-celes" };

    /// <summary>
    /// Kthen çelësin JWT nga konfigurimi (Jwt:Key ose variabli JWT__KEY). Nëse mungon ose është vlerë shembull,
    /// krijon një çelës të rastësishëm 512-bit dhe e ruan në {ContentRoot}/keys/jwt.key (jashtë kodit burimor).
    /// </summary>
    public static string JwtKey(IConfiguration cfg, IWebHostEnvironment env, ILogger? log = null)
    {
        var key = cfg["Jwt:Key"];
        var isSample = !string.IsNullOrWhiteSpace(key) && Samples.Any(s => key.Contains(s, StringComparison.OrdinalIgnoreCase));
        if (!string.IsNullOrWhiteSpace(key) && !isSample)
        {
            if (key.Length < 32) throw new InvalidOperationException("Jwt:Key duhet të ketë të paktën 32 karaktere (rekomandohen 64).");
            return key;
        }

        var dir = cfg["Keys:Path"] is { Length: > 0 } p ? p : Path.Combine(env.ContentRootPath, "keys");
        try { Directory.CreateDirectory(dir); }
        catch (Exception ex) { throw new InvalidOperationException($"Dosja e çelësave '{dir}' nuk mund të krijohet. Vendosni Jwt:Key ose Keys:Path.", ex); }
        var file = Path.Combine(dir, "jwt.key");
        if (File.Exists(file))
        {
            var existing = File.ReadAllText(file).Trim();
            if (existing.Length >= 64) return existing;
        }
        var generated = Convert.ToBase64String(RandomNumberGenerator.GetBytes(64));
        File.WriteAllText(file, generated);
        if (!OperatingSystem.IsWindows())
            File.SetUnixFileMode(file, UnixFileMode.UserRead | UnixFileMode.UserWrite);
        if (log is not null) log.LogWarning("U krijua një çelës i ri JWT te {File}. Ruajeni këtë skedar dhe mos e publikoni.", file);
        else Console.WriteLine($"[Siguria] U krijua një çelës i ri JWT te {file}. Ruajeni këtë skedar dhe mos e publikoni.");
        return generated;
    }

    /// <summary>Fjalëkalim i rastësishëm i lexueshëm (p.sh. për Super Adminin e parë).</summary>
    public static string RandomPassword(int length = 16)
    {
        const string chars = "abcdefghjkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789";
        var pwd = new string(Enumerable.Range(0, length).Select(_ => chars[RandomNumberGenerator.GetInt32(chars.Length)]).ToArray());
        return pwd[..(length - 2)] + RandomNumberGenerator.GetInt32(10) + "x";
    }
}

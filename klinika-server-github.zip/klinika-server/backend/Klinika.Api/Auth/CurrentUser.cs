using System.Security.Claims;
using Klinika.Api.Domain;

namespace Klinika.Api.Auth;

public interface ICurrentUser
{
    Guid? UserId { get; }
    Guid? BusinessId { get; }
    Guid? PatientId { get; }
    UserRole? Role { get; }
    bool IsSuperAdmin { get; }
    int TokenVersion { get; }
}

public class CurrentUser : ICurrentUser
{
    private readonly IHttpContextAccessor _http;
    public CurrentUser(IHttpContextAccessor http) => _http = http;

    private ClaimsPrincipal? P => _http.HttpContext?.User;
    private Guid? G(string type) => Guid.TryParse(P?.FindFirstValue(type), out var g) ? g : null;

    public Guid? UserId => G(ClaimTypes.NameIdentifier);
    public Guid? BusinessId => G(AppClaims.BusinessId);
    public Guid? PatientId => G(AppClaims.PatientId);
    public UserRole? Role => Enum.TryParse<UserRole>(P?.FindFirstValue(ClaimTypes.Role), out var r) ? r : null;
    public bool IsSuperAdmin => Role == UserRole.SuperAdmin;
    public int TokenVersion => int.TryParse(P?.FindFirstValue(AppClaims.TokenVersion), out var v) ? v : -1;
}

public static class AppClaims
{
    public const string BusinessId = "bid";
    public const string PatientId = "pid";
    public const string Specialty = "spec";
    public const string TokenVersion = "tv";
}

/// <summary>Grupet e roleve për [Authorize(Roles = ...)]</summary>
public static class Roles
{
    public const string SuperAdmin = nameof(UserRole.SuperAdmin);
    public const string Admin = nameof(UserRole.Admin);
    public const string Client = nameof(UserRole.Klient);
    /// <summary>Të gjithë stafi i biznesit (përfshirë adminin).</summary>
    public const string Staff = "Admin,Mjek,Infermier,Recepsion";
    /// <summary>Stafi klinik që shkruan historikun mjekësor.</summary>
    public const string Clinical = "Admin,Mjek,Infermier";
    /// <summary>Stafi që menaxhon financat.</summary>
    public const string Finance = "Admin,Recepsion,Mjek";
}

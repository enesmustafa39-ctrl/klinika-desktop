using Klinika.Api.Data;
using Klinika.Api.Domain;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.EntityFrameworkCore;

namespace Klinika.Api.Auth;

/// <summary>
/// Lejon veprimin vetëm nëse biznesi i përdoruesit e ka të aktivizuar funksionin (nga Super Admini).
/// Përdorim: [RequireFeature(Features.Imaging)]
/// </summary>
[AttributeUsage(AttributeTargets.Class | AttributeTargets.Method)]
public class RequireFeatureAttribute : Attribute, IAsyncActionFilter
{
    public string Feature { get; }
    public RequireFeatureAttribute(string feature) => Feature = feature;

    public async Task OnActionExecutionAsync(ActionExecutingContext ctx, ActionExecutionDelegate next)
    {
        var me = ctx.HttpContext.RequestServices.GetRequiredService<ICurrentUser>();
        if (me.BusinessId is { } bid)
        {
            var db = ctx.HttpContext.RequestServices.GetRequiredService<AppDbContext>();
            var enabled = await db.Businesses.AnyAsync(b => b.Id == bid && b.Features.Contains(Feature));
            if (!enabled)
            {
                ctx.Result = new ObjectResult(new
                {
                    message = $"Funksioni \"{Features.Label(Feature)}\" nuk është aktiv për biznesin tuaj. Kontaktoni ofruesin e platformës."
                }) { StatusCode = 403 };
                return;
            }
        }
        await next();
    }
}

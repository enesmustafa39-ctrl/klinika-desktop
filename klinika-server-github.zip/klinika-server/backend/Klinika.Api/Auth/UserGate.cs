using Klinika.Api.Data;
using Klinika.Api.Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;

namespace Klinika.Api.Auth;

/// <summary>
/// Kontroll në çdo kërkesë të kyçur:
///  - përdoruesi ekziston, është aktiv, ka të njëjtin rol dhe seanca nuk është anuluar (TokenVersion);
///  - biznesi është aktiv dhe nuk ka skaduar; klientët kanë qasje vetëm kur aplikacioni i klientit është aktiv.
/// Rezultati ruhet në memorie për pak sekonda që të mos ngarkohet databaza.
/// </summary>
public static class UserGate
{
    private static readonly TimeSpan Ttl = TimeSpan.FromSeconds(30);

    private sealed record UserState(bool IsActive, UserRole Role, int TokenVersion);
    private sealed record BizState(bool Active, bool ClientPortal);

    public static void Forget(IMemoryCache cache, Guid userId) => cache.Remove($"user-state:{userId}");
    public static void ForgetBusiness(IMemoryCache cache, Guid businessId) => cache.Remove($"biz-state:{businessId}");

    public static async Task Middleware(HttpContext ctx, Func<Task> next)
    {
        var me = ctx.RequestServices.GetRequiredService<ICurrentUser>();
        if (ctx.User.Identity?.IsAuthenticated != true || me.UserId is not { } uid)
        {
            await next();
            return;
        }

        var cache = ctx.RequestServices.GetRequiredService<IMemoryCache>();
        var db = ctx.RequestServices.GetRequiredService<AppDbContext>();

        var u = await cache.GetOrCreateAsync($"user-state:{uid}", async e =>
        {
            e.AbsoluteExpirationRelativeToNow = Ttl;
            return await db.Users.AsNoTracking().Where(x => x.Id == uid)
                .Select(x => new UserState(x.IsActive, x.Role, x.TokenVersion)).FirstOrDefaultAsync();
        });
        if (u is null || !u.IsActive || u.Role != me.Role || u.TokenVersion != me.TokenVersion)
        {
            await Deny(ctx, 401, "Seanca juaj ka skaduar. Hyni përsëri.");
            return;
        }

        if (me.BusinessId is { } bid)
        {
            var b = await cache.GetOrCreateAsync($"biz-state:{bid}", async e =>
            {
                e.AbsoluteExpirationRelativeToNow = Ttl;
                var x = await db.Businesses.AsNoTracking().FirstOrDefaultAsync(x => x.Id == bid);
                return x is null ? new BizState(false, false)
                    : new BizState(x.IsActive && (x.AccessUntil is null || x.AccessUntil > DateTime.UtcNow), x.Has(Features.ClientPortal));
            });
            if (!b!.Active)
            {
                await Deny(ctx, 403, "Qasja e biznesit është pezulluar ose ka skaduar.");
                return;
            }
            if (u.Role == UserRole.Klient && !b.ClientPortal)
            {
                await Deny(ctx, 403, "Aplikacioni i klientit nuk është aktiv për këtë klinikë.");
                return;
            }
        }

        await next();
    }

    private static async Task Deny(HttpContext ctx, int status, string message)
    {
        ctx.Response.StatusCode = status;
        await ctx.Response.WriteAsJsonAsync(new { message });
    }
}

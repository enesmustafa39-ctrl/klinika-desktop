using System.Text;
using System.Text.Json.Serialization;
using System.Threading.RateLimiting;
using Klinika.Api.Auth;
using Klinika.Api.Data;
using Klinika.Api.Services;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.HttpOverrides;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Hosting.WindowsServices;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;

// Si shërbim Windows (KLINIKA Server), dosja e punës është ajo e programit, jo System32.
var builder = WebApplication.CreateBuilder(new WebApplicationOptions
{
    Args = args,
    ContentRootPath = WindowsServiceHelpers.IsWindowsService() ? AppContext.BaseDirectory : null,
});
builder.Host.UseWindowsService(o => o.ServiceName = "KlinikaServer");
// Sekretet lokale (fjalëkalimi i databazës, çelësat) mund të vendosen te appsettings.Local.json – nuk publikohet.
builder.Configuration.AddJsonFile("appsettings.Local.json", optional: true, reloadOnChange: false);
var cfg = builder.Configuration;
builder.WebHost.ConfigureKestrel(k => k.AddServerHeader = false); // mos e trego teknologjinë e serverit

// ---------- Database ----------
builder.Services.AddHttpContextAccessor();
builder.Services.AddScoped<ICurrentUser, CurrentUser>();
builder.Services.AddDbContext<AppDbContext>(o => o.UseNpgsql(cfg.GetConnectionString("Default")));

// ---------- Services ----------
builder.Services.AddSingleton<Passwords>();
builder.Services.AddScoped<Provisioning>();
builder.Services.AddScoped<FinanceService>();
builder.Services.AddSingleton<FileStorage>();

// Kujtesat për terminet (SMS / WhatsApp automatik nëse konfigurohet "Messaging")
var messaging = cfg.GetSection("Messaging").Get<MessagingOptions>() ?? new MessagingOptions();
builder.Services.AddSingleton(messaging);
builder.Services.AddHttpClient<TwilioSender>();
builder.Services.AddTransient<IMessageSender>(sp => sp.GetRequiredService<TwilioSender>());
builder.Services.AddHostedService<ReminderWorker>();
builder.Services.Configure<Microsoft.AspNetCore.Http.Features.FormOptions>(o => o.MultipartBodyLengthLimit = 160L * 1024 * 1024);
builder.Services.AddMemoryCache();
builder.Services.AddSingleton<LoginGuard>();

// ---------- Auth (JWT) ----------
var jwt = cfg.GetSection("Jwt").Get<JwtOptions>() ?? new JwtOptions();
// Çelësi merret nga konfigurimi/variabli JWT__KEY; nëse mungon krijohet automatikisht te keys/jwt.key.
jwt.Key = SecretKeys.JwtKey(cfg, builder.Environment);
builder.Services.AddSingleton(jwt);
builder.Services.AddSingleton<JwtService>();
builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme).AddJwtBearer(o =>
{
    o.TokenValidationParameters = new TokenValidationParameters
    {
        ValidIssuer = jwt.Issuer, ValidAudience = jwt.Audience,
        IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwt.Key)),
        ValidateIssuer = true, ValidateAudience = true, ValidateLifetime = true, ValidateIssuerSigningKey = true,
        NameClaimType = System.Security.Claims.ClaimTypes.Name,
        RoleClaimType = System.Security.Claims.ClaimTypes.Role,
        ClockSkew = TimeSpan.FromMinutes(1)
    };
});
builder.Services.AddAuthorization();

// Kufizimi i kërkesave për çdo adresë IP (mbrojtje nga sulmet me shumë kërkesa).
static string ClientIp(HttpContext c) => c.Connection.RemoteIpAddress?.ToString() ?? "unknown";
builder.Services.AddRateLimiter(o =>
{
    o.RejectionStatusCode = 429;
    o.OnRejected = async (c, ct) =>
        await c.HttpContext.Response.WriteAsJsonAsync(new { message = "Shumë kërkesa. Prisni pak dhe provoni përsëri." }, ct);
    o.AddPolicy("login", c => RateLimitPartition.GetFixedWindowLimiter(ClientIp(c),
        _ => new FixedWindowRateLimiterOptions { PermitLimit = 10, Window = TimeSpan.FromMinutes(1), QueueLimit = 0 }));
    o.GlobalLimiter = PartitionedRateLimiter.Create<HttpContext, string>(c => RateLimitPartition.GetFixedWindowLimiter(ClientIp(c),
        _ => new FixedWindowRateLimiterOptions { PermitLimit = cfg.GetValue("RateLimit:PerMinute", 1200), Window = TimeSpan.FromMinutes(1), QueueLimit = 0 }));
});

// Pas një reverse proxy (nginx, Caddy, IIS) merr IP-në reale të klientit. Besohen vetëm proxy-t lokale.
builder.Services.Configure<ForwardedHeadersOptions>(o =>
{
    o.ForwardedHeaders = ForwardedHeaders.XForwardedFor | ForwardedHeaders.XForwardedProto;
    // Proxy:TrustAll = true vetëm kur API-ja NUK arrihet direkt nga interneti (p.sh. në Docker pas nginx).
    if (cfg.GetValue("Proxy:TrustAll", false)) { o.KnownNetworks.Clear(); o.KnownProxies.Clear(); }
});
if (cfg.GetValue("Https:Enforce", false))
    builder.Services.AddHsts(o => { o.MaxAge = TimeSpan.FromDays(365); o.IncludeSubDomains = true; });

// ---------- API ----------
builder.Services.AddControllers().AddJsonOptions(o =>
{
    o.JsonSerializerOptions.Converters.Add(new JsonStringEnumConverter());
});
builder.Services.AddCors(o => o.AddDefaultPolicy(p =>
{
    // Cors:AllowAll = true vetëm për testim lokal. Në prodhim lejohen vetëm adresat te Cors:Origins.
    if (cfg.GetValue("Cors:AllowAll", false)) p.AllowAnyOrigin();
    else p.WithOrigins(cfg.GetSection("Cors:Origins").Get<string[]>() ?? new[] { "http://localhost:5173" });
    p.AllowAnyHeader().AllowAnyMethod();
}));

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo { Title = "Klinika API", Version = "v1", Description = "Platforma për menaxhimin e klinikave" });
    c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
    {
        Name = "Authorization", Type = SecuritySchemeType.Http, Scheme = "bearer", BearerFormat = "JWT", In = ParameterLocation.Header
    });
    c.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        { new OpenApiSecurityScheme { Reference = new OpenApiReference { Type = ReferenceType.SecurityScheme, Id = "Bearer" } }, Array.Empty<string>() }
    });
});

var app = builder.Build();

// ---------- Gabimet: mesazhe në shqip, pa detaje të brendshme ----------
app.UseExceptionHandler(e => e.Run(async ctx =>
{
    var ex = ctx.Features.Get<IExceptionHandlerFeature>()?.Error;
    var (status, msg) = ex switch
    {
        AppException a => (a.Status, a.Message),
        BadHttpRequestException b => (b.StatusCode, b.StatusCode == 413 ? "Kërkesa është shumë e madhe." : "Kërkesë e pavlefshme."),
        DbUpdateException => (409, "Veprimi nuk u krye për shkak të një konflikti në të dhëna."),
        _ => (500, "Ndodhi një gabim i papritur. Provoni përsëri.")
    };
    if (status >= 500) app.Logger.LogError(ex, "Gabim i papritur");
    ctx.Response.StatusCode = status;
    await ctx.Response.WriteAsJsonAsync(new { message = msg });
}));

app.UseForwardedHeaders();
if (cfg.GetValue("Https:Enforce", false))
{
    app.UseHsts();
    app.UseHttpsRedirection();
}

// Header-at e sigurisë për çdo përgjigje
app.Use(async (ctx, next) =>
{
    var h = ctx.Response.Headers;
    h["X-Content-Type-Options"] = "nosniff";
    h["X-Frame-Options"] = "DENY";
    h["Referrer-Policy"] = "no-referrer";
    h["Permissions-Policy"] = "camera=(), microphone=(), geolocation=(), payment=()";
    h["Cross-Origin-Opener-Policy"] = "same-origin";
    if (ctx.Request.Path.StartsWithSegments("/api"))
        h["Content-Security-Policy"] = "default-src 'none'; img-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'none'";
    else if (!ctx.Request.Path.StartsWithSegments("/swagger"))
        // Paneli web (kur shërbehet nga i njëjti server)
        h["Content-Security-Policy"] = "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; " +
            "font-src 'self' https://fonts.gstatic.com; img-src 'self' data: blob:; connect-src 'self'; frame-src 'self' blob:; " +
            "object-src 'self' blob:; base-uri 'self'; form-action 'self'; frame-ancestors 'none'";
    if (ctx.Request.Path.StartsWithSegments("/api") && !ctx.Request.Path.StartsWithSegments("/api/branding"))
        h["Cache-Control"] = "no-store";
    await next();
});

// Swagger (dokumentimi i API-së) – vetëm kur aktivizohet me "Swagger": true. Mos e lini aktiv në internet.
if (cfg.GetValue("Swagger", false))
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

// Paneli web i ndërtuar (wwwroot) – kur ekziston, serveri e shërben vetë në të njëjtën adresë (p.sh. http://192.168.1.10:8080)
var webRoot = Path.Combine(app.Environment.ContentRootPath, "wwwroot");
var serveWeb = File.Exists(Path.Combine(webRoot, "index.html"));
if (serveWeb)
{
    app.UseDefaultFiles();
    app.UseStaticFiles(new StaticFileOptions
    {
        OnPrepareResponse = c =>
        {
            // skedarët me hash në emër (assets/) ruhen gjatë; index.html kontrollohet gjithmonë
            c.Context.Response.Headers.CacheControl = c.Context.Request.Path.StartsWithSegments("/assets")
                ? "public, max-age=31536000, immutable" : "no-cache";
        }
    });
}

app.UseCors();
app.UseRateLimiter();
app.UseAuthentication();

// Në çdo kërkesë: përdoruesi aktiv, seanca e vlefshme, biznesi aktiv (Super Admini mund ta pezullojë në çdo moment).
app.Use(UserGate.Middleware);

app.UseAuthorization();
app.MapControllers();
app.MapGet("/health", () => Results.Ok(new { status = "ok" }));
if (serveWeb)
{
    // Rrugët e panelit (p.sh. /pacientet/…) hapin index.html; adresat e panjohura të API-së mbeten 404.
    app.MapFallback(async ctx =>
    {
        if (ctx.Request.Path.StartsWithSegments("/api")) { ctx.Response.StatusCode = 404; return; }
        ctx.Response.ContentType = "text/html; charset=utf-8";
        ctx.Response.Headers.CacheControl = "no-cache";
        await ctx.Response.SendFileAsync(Path.Combine(webRoot, "index.html"));
    });
}

if (cfg.GetValue("Cors:AllowAll", false))
    app.Logger.LogWarning("Cors:AllowAll është aktiv – përdoreni vetëm për testim lokal.");

await Seeder.RunAsync(app.Services, cfg, app.Logger);
app.Run();

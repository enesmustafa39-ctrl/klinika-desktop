using System.Text.Json;
using Klinika.Api.Domain;
using Klinika.Api.Dtos;

namespace Klinika.Api.Services;

public static class Mapping
{
    public static UserDto ToDto(this User u) => new(u.Id, u.FullName, u.Email, u.Phone, u.Role, Labels.Role(u.Role),
        u.Title, u.IsActive, u.BusinessId, u.PatientId, u.LastLoginAt);

    public static BusinessBriefDto ToBrief(this Business b)
    {
        var t = SpecialtyCatalog.Get(b.Specialty);
        return new(b.Id, b.Name, b.Specialty, t.Label, t.DoctorLabel, b.Currency, b.Features, b.LogoUrl, b.BackgroundUrl);
    }

    public static ServiceDto ToDto(this ServiceItem s) => new(s.Id, s.Name, s.Category, s.Price, s.DurationMinutes, s.IsActive);

    public static ChargeDto ToDto(this Charge c) => new(c.Id, c.PatientId, c.VisitId, c.Description, c.Quantity, c.UnitPrice,
        c.Discount, c.Amount, c.Date);

    public static PaymentDto ToDto(this Payment p, string? patientName = null) => new(p.Id, p.PatientId, patientName, p.Amount,
        p.Method, Labels.Method(p.Method), p.Date, p.Reference, p.Notes);

    public static AppointmentDto ToDto(this Appointment a, string? serviceName = null) => new(a.Id, a.PatientId,
        a.Patient is null ? "" : $"{a.Patient.FirstName} {a.Patient.LastName}", a.Patient?.Phone,
        a.StaffId, a.Staff?.FullName, a.ServiceItemId, serviceName, a.StartsAt, a.DurationMinutes, a.Status,
        Labels.Status(a.Status), a.Notes, a.RequestedByClient, a.ReminderSentAt, a.ReminderChannel);

    public static VisitDto ToDto(this Visit v, decimal charged = 0) => new(v.Id, v.PatientId,
        v.Patient is null ? "" : $"{v.Patient.FirstName} {v.Patient.LastName}", v.DoctorId, v.Doctor?.FullName, v.VisitDate,
        v.Complaint, v.Diagnosis, v.Treatment, v.Prescription, v.Notes, ParseFields(v.FieldsJson), v.NextVisitDate, charged);

    public static Dictionary<string, string?> ParseFields(string json)
    {
        try { return JsonSerializer.Deserialize<Dictionary<string, string?>>(json) ?? new(); }
        catch { return new(); }
    }

    public static int? Age(DateOnly? birth)
    {
        if (birth is null) return null;
        var today = DateOnly.FromDateTime(DateTime.UtcNow);
        var age = today.Year - birth.Value.Year;
        if (birth.Value > today.AddYears(-age)) age--;
        return age;
    }
}

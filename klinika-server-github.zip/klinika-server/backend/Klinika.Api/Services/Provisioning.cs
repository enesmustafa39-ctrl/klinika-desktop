using Klinika.Api.Auth;
using Klinika.Api.Data;
using Klinika.Api.Domain;
using Klinika.Api.Dtos;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

namespace Klinika.Api.Services;

public class Passwords
{
    private readonly PasswordHasher<User> _h = new();
    // Hash fiktiv: kur email-i nuk ekziston, kontrolli zgjat njësoj (nuk zbulohet nëse llogaria ekziston).
    private static readonly User Dummy = new() { Email = "x" };
    private readonly string _dummyHash;
    public Passwords() => _dummyHash = _h.HashPassword(Dummy, Guid.NewGuid().ToString());

    public string Hash(User u, string pwd) => _h.HashPassword(u, pwd);
    public bool Verify(User u, string pwd) => _h.VerifyHashedPassword(u, u.PasswordHash, pwd) != PasswordVerificationResult.Failed;

    /// <summary>Kontrollon fjalëkalimin; nëse hash-i është i vjetër e përditëson me parametrat aktualë.</summary>
    public bool VerifyAndUpgrade(User u, string pwd)
    {
        var r = _h.VerifyHashedPassword(u, u.PasswordHash, pwd);
        if (r == PasswordVerificationResult.SuccessRehashNeeded) u.PasswordHash = _h.HashPassword(u, pwd);
        return r != PasswordVerificationResult.Failed;
    }

    public void VerifyDummy(string pwd) => _h.VerifyHashedPassword(Dummy, _dummyHash, pwd);

    /// <summary>Vendos fjalëkalim të ri dhe mbyll të gjitha seancat e tjera të përdoruesit.</summary>
    public void SetPassword(User u, string pwd)
    {
        u.PasswordHash = _h.HashPassword(u, pwd);
        u.TokenVersion++;
    }
}

/// <summary>Regjistrimi i një biznesi të ri: biznesi + llogaria e adminit + shërbimet sipas specialitetit.</summary>
public class Provisioning
{
    private readonly AppDbContext _db;
    private readonly Passwords _pw;
    public Provisioning(AppDbContext db, Passwords pw) { _db = db; _pw = pw; }

    public async Task<Business> CreateBusinessAsync(CreateBusinessRequest r)
    {
        var email = r.AdminEmail.Trim().ToLowerInvariant();
        if (await _db.Users.AnyAsync(u => u.Email == email))
            throw new AppException("Ky email përdoret tashmë nga një llogari tjetër.");

        var b = new Business
        {
            Name = r.Name.Trim(), Specialty = r.Specialty, NIPT = r.NIPT, Address = r.Address, City = r.City,
            Phone = r.Phone, Email = r.Email, Currency = string.IsNullOrWhiteSpace(r.Currency) ? "EUR" : r.Currency!.ToUpperInvariant(),
            AccessUntil = r.AccessUntil, MaxStaff = r.MaxStaff ?? 20, Notes = r.Notes, IsActive = true,
            Features = (r.Features ?? Features.Defaults.ToList()).Where(Features.IsKnown).Distinct().ToList()
        };
        _db.Businesses.Add(b);

        var admin = new User
        {
            BusinessId = b.Id, FullName = r.AdminFullName.Trim(), Email = email, Role = UserRole.Admin,
            Title = SpecialtyCatalog.Get(r.Specialty).DoctorLabel
        };
        admin.PasswordHash = _pw.Hash(admin, r.AdminPassword);
        _db.Users.Add(admin);

        if (r.SeedDefaultServices)
            foreach (var s in SpecialtyCatalog.Get(r.Specialty).Services)
                _db.Services.Add(new ServiceItem
                {
                    BusinessId = b.Id, Name = s.Name, Category = s.Category, Price = s.Price, DurationMinutes = s.DurationMinutes
                });

        await _db.SaveChangesAsync();
        return b;
    }
}

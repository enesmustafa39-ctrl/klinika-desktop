using Klinika.Api.Data;
using Klinika.Api.Dtos;
using Microsoft.EntityFrameworkCore;

namespace Klinika.Api.Services;

/// <summary>Llogaritja e kartelës financiare (ngarkesa − pagesa = borxhi).</summary>
public class FinanceService
{
    private readonly AppDbContext _db;
    public FinanceService(AppDbContext db) => _db = db;

    public async Task<StatementDto?> StatementAsync(Guid patientId)
    {
        var p = await _db.Patients.AsNoTracking().FirstOrDefaultAsync(x => x.Id == patientId);
        if (p is null) return null;

        var charges = await _db.Charges.AsNoTracking().Where(c => c.PatientId == patientId).ToListAsync();
        var payments = await _db.Payments.AsNoTracking().Where(c => c.PatientId == patientId).ToListAsync();

        var raw = charges.Select(c => (c.Date, Type: "Ngarkesë", Desc: c.Quantity != 1 ? $"{c.Description} × {c.Quantity:0.##}" : c.Description,
                Debit: c.Amount, Credit: 0m, c.Id))
            .Concat(payments.Select(x => (x.Date, Type: "Pagesë", Desc: $"Pagesë ({Labels.Method(x.Method)}){(x.Reference is null ? "" : " - " + x.Reference)}",
                Debit: 0m, Credit: x.Amount, x.Id)))
            .OrderBy(e => e.Date).ToList();

        decimal running = 0;
        var entries = new List<LedgerEntry>();
        foreach (var e in raw)
        {
            running += e.Debit - e.Credit;
            entries.Add(new LedgerEntry(e.Date, e.Type, e.Desc, e.Debit, e.Credit, running, e.Id));
        }
        var tc = charges.Sum(c => c.Amount);
        var tp = payments.Sum(x => x.Amount);
        entries.Reverse(); // më të rejat sipër
        return new StatementDto(p.Id, $"{p.FirstName} {p.LastName}", tc, tp, tc - tp, entries);
    }
}

using Klinika.Api.Domain;
using Klinika.Api.Dtos;

namespace Klinika.Api.Services;

public static class PlanMapper
{
    public static PlanDto ToDto(TreatmentPlan p, string patientName, string? doctorName, DateOnly today)
    {
        var total = p.Items.Sum(i => i.Amount);
        var paid = p.Installments.Where(i => i.PaidAt != null).Sum(i => i.Amount);
        var active = p.Status == PlanStatus.Aktiv;
        var inst = p.Installments.OrderBy(i => i.Number)
            .Select(i => new InstallmentDto(i.Id, i.Number, i.DueDate, i.Amount, i.PaidAt, active && i.PaidAt == null && i.DueDate < today))
            .ToList();
        return new PlanDto(p.Id, p.PatientId, patientName, p.Title, p.Status, Labels.Plan(p.Status), p.Notes, p.DoctorId, doctorName,
            total, paid, total - paid, p.Items.Count(i => i.Done), p.Items.Count, inst.Count(i => i.IsOverdue),
            inst.Where(i => i.PaidAt == null).Select(i => (DateOnly?)i.DueDate).FirstOrDefault(),
            p.CreatedAt, p.ActivatedAt,
            p.Items.OrderBy(i => i.SortOrder).Select(i => new PlanItemDto(i.Id, i.ServiceItemId, i.Description, i.Tooth, i.Quantity,
                i.UnitPrice, i.Discount, i.Amount, i.Done, i.DoneAt)).ToList(),
            inst);
    }

    /// <summary>Ndan shumën në këste të barabarta (kësti i fundit rregullon centët).</summary>
    public static List<PlanInstallment> BuildInstallments(decimal total, int count, DateOnly first, int intervalMonths)
    {
        count = Math.Clamp(count, 1, 60);
        intervalMonths = Math.Clamp(intervalMonths, 0, 12);
        var each = Math.Round(total / count, 2, MidpointRounding.AwayFromZero);
        var list = new List<PlanInstallment>();
        for (var i = 0; i < count; i++)
        {
            var amount = i == count - 1 ? total - each * (count - 1) : each;
            list.Add(new PlanInstallment { Number = i + 1, DueDate = first.AddMonths(i * intervalMonths), Amount = amount });
        }
        return list;
    }
}

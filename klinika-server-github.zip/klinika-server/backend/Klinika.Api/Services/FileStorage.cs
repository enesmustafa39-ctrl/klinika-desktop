using Klinika.Api.Auth;
namespace Klinika.Api.Services;

/// <summary>
/// Ruajtja e skedarëve në disk: {Storage:Path}/{businessId}/{guid}.ext
/// Në Docker dosja është një volum ("uploads"), që të mos humbasë pas rinisjes.
/// </summary>
public class FileStorage
{
    public string Root { get; }

    public FileStorage(IConfiguration cfg, IWebHostEnvironment env)
    {
        Root = Path.GetFullPath(cfg["Storage:Path"] is { Length: > 0 } p ? p : Path.Combine(env.ContentRootPath, "uploads"));
        Directory.CreateDirectory(Root);
        _rootWithSep = Root.EndsWith(Path.DirectorySeparatorChar) ? Root : Root + Path.DirectorySeparatorChar;
    }

    private readonly string _rootWithSep;

    /// <summary>
    /// Kontrollon që përmbajtja e skedarit përputhet me prapashtesën (p.sh. një ".png" është vërtet PNG),
    /// që të mos ngarkohen skedarë të rrezikshëm me emër të rremë.
    /// </summary>
    public static async Task<bool> MatchesSignatureAsync(IFormFile file, string extension)
    {
        var head = new byte[132];
        int read;
        await using (var s = file.OpenReadStream())
        {
            read = 0;
            while (read < head.Length)
            {
                var n = await s.ReadAsync(head.AsMemory(read, head.Length - read));
                if (n == 0) break;
                read += n;
            }
        }
        bool Starts(params byte[] sig) => read >= sig.Length && head.AsSpan(0, sig.Length).SequenceEqual(sig);
        return extension.ToLowerInvariant() switch
        {
            ".png" => Starts(0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A),
            ".jpg" or ".jpeg" => Starts(0xFF, 0xD8, 0xFF),
            ".gif" => Starts(0x47, 0x49, 0x46, 0x38),
            ".webp" => read >= 12 && Starts(0x52, 0x49, 0x46, 0x46) && head[8] == 0x57 && head[9] == 0x45 && head[10] == 0x42 && head[11] == 0x50,
            ".bmp" => Starts(0x42, 0x4D),
            ".pdf" => Starts(0x25, 0x50, 0x44, 0x46),
            // DICOM: 128 bajt hyrje + "DICM"
            ".dcm" => (read >= 132 && head[128] == 0x44 && head[129] == 0x49 && head[130] == 0x43 && head[131] == 0x4D) || Starts(0x08, 0x00),
            _ => false,
        };
    }

    public async Task<string> SaveAsync(Guid businessId, IFormFile file, string extension, CancellationToken ct = default)
    {
        var relative = Path.Combine(businessId.ToString("N"), $"{Guid.NewGuid():N}{extension}");
        var full = FullPath(relative);
        Directory.CreateDirectory(Path.GetDirectoryName(full)!);
        await using var fs = File.Create(full);
        await file.CopyToAsync(fs, ct);
        return relative;
    }

    public string FullPath(string relative)
    {
        var full = Path.GetFullPath(Path.Combine(Root, relative));
        if (!full.StartsWith(_rootWithSep, StringComparison.Ordinal)) throw new AppException("Rrugë e pavlefshme.", 403);
        return full;
    }

    public void Delete(string relative)
    {
        var full = FullPath(relative);
        if (File.Exists(full)) File.Delete(full);
    }
}

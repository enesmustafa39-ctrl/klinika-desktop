using System.Net.Http.Headers;
using System.Text;

namespace Klinika.Api.Services;

/// <summary>
/// Konfigurimi i ofruesit të mesazheve (për kujtesat AUTOMATIKE). Në appsettings.json:
/// "Messaging": { "Provider": "Twilio", "Channel": "sms" | "whatsapp", "Twilio": { "AccountSid": "...", "AuthToken": "...", "From": "+1..." } }
/// Pa ofrues ("None"), kujtesat dërgohen manualisht me një klik (WhatsApp / Viber / SMS nga telefoni).
/// </summary>
public class MessagingOptions
{
    public string Provider { get; set; } = "None";
    public string Channel { get; set; } = "sms";
    public TwilioOptions Twilio { get; set; } = new();
}

public class TwilioOptions
{
    public string AccountSid { get; set; } = "";
    public string AuthToken { get; set; } = "";
    public string From { get; set; } = "";
}

public interface IMessageSender
{
    bool IsConfigured { get; }
    string Channel { get; }
    /// <summary>Dërgon mesazhin. toDigits = numri ndërkombëtar pa "+" (p.sh. 38344123456). Kthen null nëse u dërgua, ose mesazhin e gabimit.</summary>
    Task<string?> SendAsync(string toDigits, string text, CancellationToken ct = default);
}

public class TwilioSender : IMessageSender
{
    private readonly HttpClient _http;
    private readonly MessagingOptions _o;
    private readonly ILogger<TwilioSender> _log;

    public TwilioSender(HttpClient http, MessagingOptions o, ILogger<TwilioSender> log) { _http = http; _o = o; _log = log; }

    public bool IsConfigured => _o.Provider.Equals("Twilio", StringComparison.OrdinalIgnoreCase)
        && !string.IsNullOrWhiteSpace(_o.Twilio.AccountSid) && !string.IsNullOrWhiteSpace(_o.Twilio.AuthToken)
        && !string.IsNullOrWhiteSpace(_o.Twilio.From);

    public string Channel => _o.Channel.Equals("whatsapp", StringComparison.OrdinalIgnoreCase) ? "whatsapp" : "sms";

    public async Task<string?> SendAsync(string toDigits, string text, CancellationToken ct = default)
    {
        if (!IsConfigured) return "Ofruesi i mesazheve nuk është konfiguruar.";
        var wa = Channel == "whatsapp";
        var from = _o.Twilio.From.StartsWith("+") ? _o.Twilio.From : "+" + _o.Twilio.From;
        var form = new FormUrlEncodedContent(new Dictionary<string, string>
        {
            ["To"] = (wa ? "whatsapp:+" : "+") + toDigits,
            ["From"] = (wa ? "whatsapp:" : "") + from,
            ["Body"] = text,
        });
        using var req = new HttpRequestMessage(HttpMethod.Post,
            $"https://api.twilio.com/2010-04-01/Accounts/{_o.Twilio.AccountSid}/Messages.json") { Content = form };
        req.Headers.Authorization = new AuthenticationHeaderValue("Basic",
            Convert.ToBase64String(Encoding.ASCII.GetBytes($"{_o.Twilio.AccountSid}:{_o.Twilio.AuthToken}")));
        try
        {
            using var res = await _http.SendAsync(req, ct);
            if (res.IsSuccessStatusCode) return null;
            var body = await res.Content.ReadAsStringAsync(ct);
            _log.LogWarning("Twilio dështoi ({Status}): {Body}", (int)res.StatusCode, body);
            return $"Dërgimi dështoi ({(int)res.StatusCode}).";
        }
        catch (Exception ex)
        {
            _log.LogWarning(ex, "Twilio: gabim lidhjeje");
            return "Nuk u arrit lidhja me ofruesin e mesazheve.";
        }
    }
}

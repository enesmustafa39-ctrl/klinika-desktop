using Klinika.Api.Data;
using Klinika.Api.Domain;
using Microsoft.EntityFrameworkCore;

namespace Klinika.Api.Services;

/// <summary>
/// Çdo 10 minuta dërgon kujtesat automatike për terminet e afërta (vetëm për klinikat me funksionin "reminders"
/// dhe vetëm nëse platforma ka ofrues SMS/WhatsApp të konfiguruar te "Messaging").
/// </summary>
public class ReminderWorker : BackgroundService
{
    private readonly IServiceProvider _sp;
    private readonly ILogger<ReminderWorker> _log;
    public ReminderWorker(IServiceProvider sp, ILogger<ReminderWorker> log) { _sp = sp; _log = log; }

    protected override async Task ExecuteAsync(CancellationToken stop)
    {
        await Task.Delay(TimeSpan.FromSeconds(30), stop);
        while (!stop.IsCancellationRequested)
        {
            try { await RunOnce(stop); }
            catch (Exception ex) when (ex is not OperationCanceledException) { _log.LogError(ex, "Gabim te kujtesat automatike"); }
            await Task.Delay(TimeSpan.FromMinutes(10), stop);
        }
    }

    private async Task RunOnce(CancellationToken ct)
    {
        using var scope = _sp.CreateScope();
        var sender = scope.ServiceProvider.GetRequiredService<IMessageSender>();
        if (!sender.IsConfigured) return;
        var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();

        var businesses = await db.Businesses.Where(b => b.IsActive && b.Features.Contains(Features.Reminders)).ToListAsync(ct);
        var now = DateTime.UtcNow;
        foreach (var b in businesses)
        {
            var until = now.AddHours(Math.Clamp(b.ReminderHoursBefore, 1, 168));
            var due = await db.Appointments.IgnoreQueryFilters()
                .Include(a => a.Patient).Include(a => a.Staff)
                .Where(a => a.BusinessId == b.Id && a.ReminderSentAt == null && a.StartsAt > now && a.StartsAt <= until
                    && (a.Status == AppointmentStatus.Konfirmuar || (a.Status == AppointmentStatus.Planifikuar && !a.RequestedByClient)))
                .ToListAsync(ct);
            if (due.Count == 0) continue;

            var serviceNames = await db.Services.IgnoreQueryFilters().Where(s => s.BusinessId == b.Id)
                .ToDictionaryAsync(s => s.Id, s => s.Name, ct);
            foreach (var a in due)
            {
                var phone = Reminders.NormalizePhone(a.Patient?.Phone, b.PhoneCountryCode);
                if (phone is null) continue;
                var text = Reminders.Render(b, a, a.ServiceItemId is { } sid ? serviceNames.GetValueOrDefault(sid) : null);
                var err = await sender.SendAsync(phone, text, ct);
                if (err is null)
                {
                    a.ReminderSentAt = DateTime.UtcNow;
                    a.ReminderChannel = "auto-" + sender.Channel;
                }
            }
            await db.SaveChangesAsync(ct);
        }
    }
}

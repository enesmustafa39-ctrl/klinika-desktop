using Klinika.Api.Domain;

namespace Klinika.Api.Services;

/// <summary>Etiketat shqip për vlerat e enum-eve.</summary>
public static class Labels
{
    public static string Role(UserRole r) => r switch
    {
        UserRole.SuperAdmin => "Super Administrator",
        UserRole.Admin => "Administrator",
        UserRole.Mjek => "Mjek",
        UserRole.Infermier => "Infermier/e",
        UserRole.Recepsion => "Recepsionist/e",
        UserRole.Klient => "Klient",
        _ => r.ToString()
    };

    public static string Method(PaymentMethod m) => m switch
    {
        PaymentMethod.Kesh => "Kesh",
        PaymentMethod.Kartele => "Kartelë",
        PaymentMethod.Transfer => "Transfertë bankare",
        PaymentMethod.Sigurim => "Sigurim shëndetësor",
        _ => m.ToString()
    };

    public static string Status(AppointmentStatus s) => s switch
    {
        AppointmentStatus.Planifikuar => "Planifikuar",
        AppointmentStatus.Konfirmuar => "Konfirmuar",
        AppointmentStatus.Perfunduar => "Përfunduar",
        AppointmentStatus.Anuluar => "Anuluar",
        AppointmentStatus.NukErdhi => "Nuk erdhi",
        _ => s.ToString()
    };

    public static string FileCategoryLabel(FileCategory c) => c switch
    {
        FileCategory.RrezeX => "Rreze X",
        FileCategory.OPG => "OPG / Panoramike",
        FileCategory.CBCT => "CBCT / Skaner 3D",
        FileCategory.Ekografi => "Ekografi",
        FileCategory.Foto => "Foto klinike",
        FileCategory.Dokument => "Dokument / Analizë",
        _ => "Tjetër"
    };

    public static string Tooth(ToothCondition c) => c switch
    {
        ToothCondition.Shendoshe => "I shëndoshë",
        ToothCondition.Karies => "Karies",
        ToothCondition.Mbushje => "Mbushje",
        ToothCondition.Kurore => "Kurorë",
        ToothCondition.Ure => "Urë",
        ToothCondition.Implant => "Implant",
        ToothCondition.Kanal => "Trajtim kanali",
        ToothCondition.Mungon => "Mungon / i hequr",
        ToothCondition.PerHeqje => "Për t'u hequr",
        ToothCondition.Fraktura => "Frakturë",
        _ => "Tjetër"
    };

    public static string Plan(PlanStatus s) => s switch
    {
        PlanStatus.Propozuar => "I propozuar",
        PlanStatus.Aktiv => "Aktiv",
        PlanStatus.Perfunduar => "Përfunduar",
        PlanStatus.Anuluar => "Anuluar",
        _ => s.ToString()
    };

    public static readonly string[] Months = { "Jan", "Shk", "Mar", "Pri", "Maj", "Qer", "Korr", "Gush", "Sht", "Tet", "Nën", "Dhj" };
}

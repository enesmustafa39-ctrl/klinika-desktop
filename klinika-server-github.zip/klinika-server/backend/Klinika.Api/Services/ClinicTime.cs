namespace Klinika.Api.Services;

/// <summary>Ora lokale e klinikës (të dhënat ruhen në UTC).</summary>
public static class ClinicTime
{
    public static TimeZoneInfo Zone(string? id)
    {
        foreach (var candidate in new[] { id, "Europe/Tirane", "Central European Standard Time" })
        {
            if (string.IsNullOrWhiteSpace(candidate)) continue;
            try { return TimeZoneInfo.FindSystemTimeZoneById(candidate); } catch { /* provo tjetrin */ }
        }
        return TimeZoneInfo.Utc;
    }

    public static DateTime ToLocal(DateTime utc, string? zone) =>
        TimeZoneInfo.ConvertTimeFromUtc(DateTime.SpecifyKind(utc, DateTimeKind.Utc), Zone(zone));

    public static DateOnly Today(string? zone) => DateOnly.FromDateTime(ToLocal(DateTime.UtcNow, zone));
}

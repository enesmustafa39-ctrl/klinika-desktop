using Klinika.Api.Domain;

namespace Klinika.Api.Services;

/// <summary>Teksti i kujtesës dhe lidhjet për WhatsApp / Viber / SMS.</summary>
public static class Reminders
{
    public const string DefaultTemplate =
        "Përshëndetje {pacienti}! Ju kujtojmë terminin tuaj në {klinika} më {data} në ora {ora}. Për ndryshime: {telefoni}. Faleminderit!";

    public static string Render(Business b, Appointment a, string? serviceName)
    {
        var local = ClinicTime.ToLocal(a.StartsAt, b.TimeZone);
        var template = string.IsNullOrWhiteSpace(b.ReminderTemplate) ? DefaultTemplate : b.ReminderTemplate!;
        return template
            .Replace("{pacienti}", a.Patient is null ? "" : a.Patient.FirstName)
            .Replace("{klinika}", b.Name)
            .Replace("{data}", local.ToString("dd.MM.yyyy"))
            .Replace("{ora}", local.ToString("HH:mm"))
            .Replace("{mjeku}", a.Staff?.FullName ?? "")
            .Replace("{sherbimi}", serviceName ?? "")
            .Replace("{telefoni}", b.Phone ?? "")
            .Trim();
    }

    /// <summary>Numri në formë ndërkombëtare pa "+", p.sh. "044 123 456" + 383 → "38344123456".</summary>
    public static string? NormalizePhone(string? phone, string? countryCode)
    {
        if (string.IsNullOrWhiteSpace(phone)) return null;
        var plus = phone.TrimStart().StartsWith("+");
        var digits = new string(phone.Where(char.IsDigit).ToArray());
        if (digits.Length < 6) return null;
        var cc = new string((countryCode ?? "").Where(char.IsDigit).ToArray());
        if (plus) return digits;
        if (digits.StartsWith("00")) return digits[2..];
        if (digits.StartsWith("0")) return cc + digits[1..];
        if (cc.Length > 0 && !digits.StartsWith(cc) && digits.Length <= 9) return cc + digits;
        return digits;
    }

    public static string WhatsAppUrl(string digits, string text) => $"https://wa.me/{digits}?text={Uri.EscapeDataString(text)}";
    public static string SmsUrl(string digits, string text) => $"sms:+{digits}?body={Uri.EscapeDataString(text)}";
    public static string ViberUrl(string digits) => $"viber://chat?number=%2B{digits}";
}

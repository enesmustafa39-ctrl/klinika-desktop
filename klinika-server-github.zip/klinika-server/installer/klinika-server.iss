﻿; KLINIKA Server – instaluesi për kompjuterin që bën host (serverin e klinikës).
; Instalon API-në + panelin web si shërbim të Windows-it, hap portën në firewall
; dhe e lejon panelin të hapet nga kompjuterët e tjerë në të njëjtin rrjet.
; Ndërtohet automatikisht nga GitHub Actions (.github/workflows/server-setup.yml).

#ifndef AppVersion
  #define AppVersion "1.0.0"
#endif
#define AppName "KLINIKA Server"
#define ServiceName "KlinikaServer"
#define SourceDir "..\out\server"

[Setup]
AppId={{6B1C2E57-3A4D-4F1B-9C55-1E6A0B7D2F31}
AppName={#AppName}
AppVersion={#AppVersion}
AppPublisher=KLINIKA
DefaultDirName={autopf}\KLINIKA Server
DefaultGroupName=KLINIKA Server
DisableProgramGroupPage=yes
PrivilegesRequired=admin
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
OutputDir=Output
OutputBaseFilename=KLINIKA-Server-Setup-{#AppVersion}
SetupIconFile=icon.ico
UninstallDisplayIcon={app}\Klinika.Api.exe
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
CloseApplications=no

[Languages]
Name: "en"; MessagesFile: "compiler:Default.isl"

[Messages]
WelcomeLabel1=Mirë se vini te instalimi i KLINIKA Server
WelcomeLabel2=Ky program e bën këtë kompjuter serverin e klinikës.%n%nPas instalimit, KLINIKA hapet nga çdo kompjuter, laptop ose telefon në të njëjtin rrjet (Wi-Fi / LAN).%n%nKërkohet që PostgreSQL të jetë i instaluar në këtë kompjuter.
FinishedHeadingLabel=KLINIKA Server u instalua
FinishedLabel=Serveri po punon si shërbim i Windows-it dhe niset vetë sa herë ndizet kompjuteri.%n%nNë kompjuterët e tjerë instaloni aplikacionin KLINIKA dhe vendosni adresën e këtij kompjuteri, p.sh. http://192.168.1.10:8080%n%nAdresën e saktë e gjeni te menuja Start → KLINIKA Server → "Adresa për kompjuterët e tjerë".
ClickFinish=Kliko Finish për të përfunduar.

[Files]
Source: "{#SourceDir}\*"; DestDir: "{app}"; Flags: recursesubdirs createallsubdirs ignoreversion; Excludes: "appsettings.Local.json,keys\*,uploads\*"

[Dirs]
Name: "{commonappdata}\KLINIKA\uploads"
Name: "{commonappdata}\KLINIKA\keys"

[INI]
Filename: "{group}\Hap KLINIKA.url"; Section: "InternetShortcut"; Key: "URL"; String: "http://localhost:{code:GetPort}"

[Icons]
Name: "{group}\Adresa për kompjuterët e tjerë"; Filename: "{app}\adresa.cmd"
Name: "{group}\Çinstalo KLINIKA Server"; Filename: "{uninstallexe}"

[Run]
Filename: "http://localhost:{code:GetPort}"; Description: "Hap KLINIKA tani"; Flags: shellexec postinstall nowait skipifsilent
Filename: "{app}\adresa.cmd"; Description: "Shfaq adresën për kompjuterët e tjerë"; Flags: shellexec postinstall nowait skipifsilent

[UninstallRun]
Filename: "{sys}\sc.exe"; Parameters: "stop {#ServiceName}"; Flags: runhidden; RunOnceId: "StopSvc"
Filename: "{sys}\timeout.exe"; Parameters: "/t 3 /nobreak"; Flags: runhidden; RunOnceId: "WaitSvc"
Filename: "{sys}\sc.exe"; Parameters: "delete {#ServiceName}"; Flags: runhidden; RunOnceId: "DelSvc"
Filename: "{sys}\netsh.exe"; Parameters: "advfirewall firewall delete rule name=""KLINIKA Server"""; Flags: runhidden; RunOnceId: "DelFw"

[UninstallDelete]
Type: files; Name: "{group}\Hap KLINIKA.url"
Type: files; Name: "{app}\adresa.cmd"

[Code]
var
  DbPage, SrvPage: TInputQueryWizardPage;

function IsUpgrade(): Boolean;
begin
  Result := FileExists(ExpandConstant('{app}\appsettings.Local.json'));
end;

function GetPort(Param: String): String;
var
  S: AnsiString;
begin
  Result := '8080';
  if (SrvPage <> nil) and (Trim(SrvPage.Values[0]) <> '') and not IsUpgrade() then
    Result := Trim(SrvPage.Values[0])
  else if LoadStringFromFile(ExpandConstant('{app}\server-port.txt'), S) then
    if Trim(String(S)) <> '' then Result := Trim(String(S));
end;

procedure InitializeWizard();
begin
  DbPage := CreateInputQueryPage(wpSelectDir,
    'Databaza PostgreSQL', 'Ku ruhen të dhënat e klinikës?',
    'Vendosni të dhënat e lidhjes me PostgreSQL në këtë kompjuter. Nëse e keni ndjekur udhëzimin e projektit, vlerat e paracaktuara janë të sakta.');
  DbPage.Add('Serveri:', False);
  DbPage.Add('Porta:', False);
  DbPage.Add('Emri i databazës:', False);
  DbPage.Add('Përdoruesi:', False);
  DbPage.Add('Fjalëkalimi i databazës:', True);
  DbPage.Values[0] := 'localhost';
  DbPage.Values[1] := '5432';
  DbPage.Values[2] := 'klinika';
  DbPage.Values[3] := 'klinika';
  DbPage.Values[4] := '';

  SrvPage := CreateInputQueryPage(DbPage.ID,
    'Serveri dhe Super Administratori', 'Porta e serverit dhe llogaria e parë',
    'Porta përmes së cilës hapet KLINIKA nga kompjuterët e tjerë. Email-i dhe fjalëkalimi i Super Administratorit përdoren vetëm nëse databaza është e re (nëse e keni tashmë një Super Admin, ai nuk ndryshohet).');
  SrvPage.Add('Porta e serverit:', False);
  SrvPage.Add('Email-i i Super Administratorit:', False);
  SrvPage.Add('Fjalëkalimi i Super Administratorit (min. 8, shkronja + numra):', True);
  SrvPage.Values[0] := '8080';
end;

function ShouldSkipPage(PageID: Integer): Boolean;
begin
  // Gjatë përditësimit ruhen cilësimet ekzistuese
  Result := ((PageID = DbPage.ID) or (PageID = SrvPage.ID)) and IsUpgrade();
end;

function HasLetterAndDigit(S: String): Boolean;
var
  I: Integer; L, D: Boolean;
begin
  L := False; D := False;
  for I := 1 to Length(S) do
  begin
    if ((S[I] >= 'a') and (S[I] <= 'z')) or ((S[I] >= 'A') and (S[I] <= 'Z')) then L := True;
    if (S[I] >= '0') and (S[I] <= '9') then D := True;
  end;
  Result := L and D;
end;

function NextButtonClick(CurPageID: Integer): Boolean;
var
  P: Integer;
begin
  Result := True;
  if CurPageID = DbPage.ID then
  begin
    if (Trim(DbPage.Values[0]) = '') or (Trim(DbPage.Values[2]) = '') or (Trim(DbPage.Values[3]) = '') or (DbPage.Values[4] = '') then
    begin
      MsgBox('Plotësoni serverin, databazën, përdoruesin dhe fjalëkalimin.', mbError, MB_OK);
      Result := False;
    end
    else if (Pos(';', DbPage.Values[4]) > 0) or (Pos('"', DbPage.Values[4]) > 0) then
    begin
      MsgBox('Fjalëkalimi i databazës nuk mund të përmbajë ; ose ".', mbError, MB_OK);
      Result := False;
    end;
  end
  else if CurPageID = SrvPage.ID then
  begin
    P := StrToIntDef(Trim(SrvPage.Values[0]), 0);
    if (P < 1) or (P > 65535) then
    begin
      MsgBox('Porta duhet të jetë një numër nga 1 deri në 65535 (p.sh. 8080).', mbError, MB_OK);
      Result := False;
    end
    else if (SrvPage.Values[2] <> '') and ((Length(SrvPage.Values[2]) < 8) or not HasLetterAndDigit(SrvPage.Values[2])) then
    begin
      MsgBox('Fjalëkalimi i Super Administratorit duhet të ketë të paktën 8 karaktere, me shkronja dhe numra.', mbError, MB_OK);
      Result := False;
    end
    else if (SrvPage.Values[1] <> '') and (Pos('@', SrvPage.Values[1]) = 0) then
    begin
      MsgBox('Shkruani një email të vlefshëm.', mbError, MB_OK);
      Result := False;
    end;
  end;
end;

function Json(S: String): String;
begin
  StringChangeEx(S, '\', '\\', True);
  StringChangeEx(S, '"', '\"', True);
  Result := S;
end;

function RunCmd(FileName, Params: String): Integer;
var
  Code: Integer;
begin
  if not Exec(FileName, Params, '', SW_HIDE, ewWaitUntilTerminated, Code) then Code := -1;
  Result := Code;
end;

function PrepareToInstall(var NeedsRestart: Boolean): String;
begin
  // Ndalo shërbimin para se të zëvendësohen skedarët (përditësim)
  RunCmd(ExpandConstant('{sys}\sc.exe'), 'stop {#ServiceName}');
  Sleep(3000);
  Result := '';
end;

procedure WriteConfig();
var
  Lines: TArrayOfString;
  Cs, Data, Cfg, Port: String;
begin
  Port := GetPort('');
  Cfg := ExpandConstant('{app}\appsettings.Local.json');
  Data := ExpandConstant('{commonappdata}\KLINIKA');
  Cs := 'Host=' + Trim(DbPage.Values[0]) + ';Port=' + Trim(DbPage.Values[1]) + ';Database=' + Trim(DbPage.Values[2]) +
        ';Username=' + Trim(DbPage.Values[3]) + ';Password=' + DbPage.Values[4];
  SetArrayLength(Lines, 12);
  Lines[0]  := '{';
  Lines[1]  := '  "ConnectionStrings": { "Default": "' + Json(Cs) + '" },';
  Lines[2]  := '  "AllowedHosts": "*",';
  Lines[3]  := '  "Storage": { "Path": "' + Json(Data + '\uploads') + '" },';
  Lines[4]  := '  "Keys": { "Path": "' + Json(Data + '\keys') + '" },';
  Lines[5]  := '  "Seed": { "SuperAdminEmail": "' + Json(Trim(SrvPage.Values[1])) + '", "SuperAdminPassword": "' + Json(SrvPage.Values[2]) + '", "Demo": false },';
  Lines[6]  := '  "Cors": { "AllowAll": false },';
  Lines[7]  := '  "Swagger": false,';
  Lines[8]  := '  "Logging": { "EventLog": { "LogLevel": { "Default": "Warning" } } },';
  Lines[9]  := '  "Https": { "Enforce": false }';
  Lines[10] := '}';
  Lines[11] := '';
  SaveStringsToUTF8File(Cfg, Lines, False);
  SaveStringToFile(ExpandConstant('{app}\server-port.txt'), Port, False);
  // Vetëm administratorët dhe sistemi e lexojnë skedarin me fjalëkalimet
  RunCmd(ExpandConstant('{sys}\icacls.exe'), '"' + Cfg + '" /inheritance:r /grant:r *S-1-5-32-544:F *S-1-5-18:F');
end;

procedure WriteAddressHelper();
var
  Lines: TArrayOfString;
begin
  SetArrayLength(Lines, 9);
  Lines[0] := '@echo off';
  Lines[1] := 'title KLINIKA Server - adresa';
  Lines[2] := 'echo.';
  Lines[3] := 'echo  Ne kompjuteret e tjere hapni KLINIKA me njeren nga keto adresa:';
  Lines[4] := 'echo.';
  Lines[5] := 'powershell -NoProfile -Command "Get-NetIPAddress -AddressFamily IPv4 | Where-Object { $_.IPAddress -notlike ''127.*'' -and $_.IPAddress -notlike ''169.254.*'' } | ForEach-Object { ''     http://'' + $_.IPAddress + '':' + GetPort('') + ''' }"';
  Lines[6] := 'echo.';
  Lines[7] := 'echo  (Kompjuteri tjeter duhet te jete ne te njejtin rrjet Wi-Fi / LAN.)';
  Lines[8] := 'pause';
  SaveStringsToFile(ExpandConstant('{app}\adresa.cmd'), Lines, False);
end;

procedure CurStepChanged(CurStep: TSetupStep);
var
  Sc, Exe, Port, Ps: String;
begin
  if CurStep <> ssPostInstall then Exit;
  if not IsUpgrade() then WriteConfig();
  Port := GetPort('');
  WriteAddressHelper();

  Sc := ExpandConstant('{sys}\sc.exe');
  Exe := ExpandConstant('{app}\Klinika.Api.exe');
  // Shërbimi i Windows-it: niset vetë me kompjuterin dhe rindizet nëse ndalet
  RunCmd(Sc, 'create {#ServiceName} binPath= "\"' + Exe + '\" --urls http://0.0.0.0:' + Port + '" start= auto DisplayName= "KLINIKA Server"');
  RunCmd(Sc, 'config {#ServiceName} binPath= "\"' + Exe + '\" --urls http://0.0.0.0:' + Port + '" start= auto');
  RunCmd(Sc, 'description {#ServiceName} "Serveri i platformes KLINIKA (API + paneli web)"');
  RunCmd(Sc, 'failure {#ServiceName} reset= 86400 actions= restart/5000/restart/10000/restart/30000');

  // Firewall: lejo kompjuterët e tjerë të rrjetit lokal
  RunCmd(ExpandConstant('{sys}\netsh.exe'), 'advfirewall firewall delete rule name="KLINIKA Server"');
  RunCmd(ExpandConstant('{sys}\netsh.exe'), 'advfirewall firewall add rule name="KLINIKA Server" dir=in action=allow protocol=TCP localport=' + Port + ' profile=private,domain');

  RunCmd(Sc, 'start {#ServiceName}');

  // Prit derisa serveri të përgjigjet (deri në 60 sekonda)
  Ps := '-NoProfile -ExecutionPolicy Bypass -Command "for($i=0;$i -lt 60;$i++){try{$r=Invoke-WebRequest -UseBasicParsing -TimeoutSec 2 http://localhost:' + Port + '/health; if($r.StatusCode -eq 200){exit 0}}catch{}; Start-Sleep 1}; exit 1"';
  if RunCmd('powershell.exe', Ps) <> 0 then
    MsgBox('Serveri u instalua, por nuk u nis.' + #13#10#13#10 +
           'Kontrolloni që PostgreSQL të jetë i ndezur dhe që fjalëkalimi i databazës të jetë i saktë.' + #13#10 +
           'Cilësimet ndodhen te: ' + ExpandConstant('{app}\appsettings.Local.json') + #13#10 +
           'Gabimi i saktë shfaqet te Event Viewer → Windows Logs → Application.', mbError, MB_OK);
end;

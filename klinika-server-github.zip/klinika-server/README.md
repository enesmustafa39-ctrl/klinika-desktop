# KLINIKA Server – instaluesi (Setup.exe)

Ky repo ndërton **KLINIKA-Server-Setup.exe**: instaluesin që e bën një kompjuter serverin e klinikës.
Pas instalimit, KLINIKA hapet nga kompjuterët e tjerë në të njëjtin rrjet (Wi-Fi / LAN).

## Ndërtimi
GitHub → **Actions** → **Ndërto KLINIKA Server (Setup.exe)** → **Run workflow** → shkruani versionin → **Run**.
Pas ~10 minutash instaluesi del te **Releases** (`server-v1.0.0`).

## Në kompjuterin server
1. Duhet PostgreSQL (databaza `klinika`, përdoruesi `klinika`).
2. Hapni `KLINIKA-Server-Setup-x.y.z.exe` → plotësoni fjalëkalimin e databazës → Next → Install.
3. Serveri punon si shërbim i Windows-it dhe niset vetë me kompjuterin.
4. Menuja Start → **KLINIKA Server → Adresa për kompjuterët e tjerë** tregon adresën, p.sh. `http://192.168.1.10:8080`.

## Në kompjuterët e tjerë
- Hapni adresën në shfletues, **ose** instaloni aplikacionin KLINIKA për Windows dhe vendosni këtë adresë si server.

Të dhënat (rrezet X, logot, çelësi i seancave) ruhen te `C:\ProgramData\KLINIKA`. Cilësimet te
`C:\Program Files\KLINIKA Server\appsettings.Local.json` (lexohen vetëm nga administratorët).

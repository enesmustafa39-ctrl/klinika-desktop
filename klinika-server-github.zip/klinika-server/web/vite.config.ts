import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    headers: {
      'X-Content-Type-Options': 'nosniff',
      'X-Frame-Options': 'DENY',
      'Referrer-Policy': 'no-referrer',
    },
    // xfwd: API-ja sheh IP-në reale të përdoruesit (për kufizimin e provave të hyrjes)
    proxy: { '/api': { target: 'http://localhost:8080', xfwd: true } },
  },
  build: { sourcemap: false },
});

import { useEffect, useState, type CSSProperties, type FormEvent } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { api, assetUrl, clinicStore, lastLogin, type ClinicBrand } from '../api/client';
import { useAuth } from '../auth';

export default function Login() {
  const { login } = useAuth();
  const nav = useNavigate();
  // Nëse herën e fundit u zgjodh "Më mbaj të kyçur", plotësojmë email-in dhe shfaqim logon e klinikës.
  const last = lastLogin.get();
  // Linku i klinikës (/hyrje/{id}) ose klinika e ruajtur në këtë pajisje → logo dhe sfondi shfaqen PARA hyrjes.
  const { clinicId } = useParams();
  const [clinic, setClinic] = useState<ClinicBrand | null>(() => {
    const c = clinicStore.get();
    return clinicId ? (c?.id === clinicId ? c : null) : c;
  });
  useEffect(() => {
    const id = clinicId ?? clinicStore.get()?.id;
    if (!id) return;
    api.get<ClinicBrand>(`/api/branding/${id}`)
      .then(c => { clinicStore.set(c); setClinic(c); })
      .catch(() => { if (clinicId) setClinic(null); });
  }, [clinicId]);
  const [email, setEmail] = useState(last?.email ?? '');
  const [password, setPassword] = useState('');
  const [remember, setRemember] = useState(!!last);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true); setError(null);
    try {
      const u = await login(email, password, remember);
      nav(u.role === 'SuperAdmin' ? '/sa' : '/', { replace: true });
    } catch (err: any) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  };

  const bg = assetUrl(clinic ? clinic.backgroundUrl : last?.backgroundUrl);
  const logo = assetUrl(clinic ? clinic.logoUrl : last?.logoUrl);
  const name = clinic?.name ?? last?.businessName;

  return (
    <div className={`login-page ${bg ? 'has-bg' : ''}`} style={bg ? ({ '--brand-bg': `url("${bg}")` } as CSSProperties) : undefined}>
      <form className="login-card" onSubmit={submit}>
        {logo ? <img className="brand-logo big" src={logo} alt={name ?? 'Logo'} /> : (
          <div className="wordmark"><img src="/logo.svg" alt="" /><span>KLINIKA</span></div>
        )}
        <h1>{name ? `Mirë se vini në ${name}` : 'Mirë se vini'}</h1>
        <p className="muted">Hyni në panelin e menaxhimit të klinikës</p>
        {error && <div className="alert error">{error}</div>}
        <label className="field full"><span>Email</span>
          <input type="email" autoComplete="username" value={email} onChange={e => setEmail(e.target.value)} required autoFocus={!email} />
        </label>
        <label className="field full"><span>Fjalëkalimi</span>
          <input type="password" autoComplete="current-password" value={password} onChange={e => setPassword(e.target.value)} required autoFocus={!!email} />
        </label>
        <label className="check remember">
          <input type="checkbox" checked={remember} onChange={e => setRemember(e.target.checked)} />
          <span>Më mbaj të kyçur <span className="muted small">(30 ditë në këtë pajisje)</span></span>
        </label>
        <button className="btn primary block" disabled={busy}>{busy ? 'Duke hyrë…' : 'Hyr'}</button>
        <p className="muted small center">Mos e zgjidhni në kompjuterë të përbashkët. Keni harruar fjalëkalimin? Kontaktoni administratorin.</p>
      </form>
    </div>
  );
}

import { useEffect, useState, type ReactNode } from 'react';
import { useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { api, assetUrl } from '../../api/client';
import type { BusinessInfo, Charge, Patient, Statement, TreatmentPlan, Visit } from '../../api/types';
import { useAuth } from '../../auth';
import { ErrorBox, Spinner } from '../../components/ui';
import { fmtDate, fmtDateTime, fmtMoney, genderLabels } from '../../sq';

type Kind = 'fature' | 'recete' | 'kartela' | 'plani';
const titles: Record<Kind, string> = { fature: 'Faturë', recete: 'Recetë mjekësore', kartela: 'Kartela financiare', plani: 'Plan trajtimi' };

interface Data {
  biz: BusinessInfo; patient: Patient; charges?: Charge[]; visit?: Visit; statement?: Statement; plan?: TreatmentPlan;
}

/**
 * Faqe printimi A4 me logon e klinikës. "Printo" → zgjidhni "Ruaj si PDF" për ta ruajtur ose dërguar me email.
 * /printo/fature/:patientId?visit=… ose ?charges=id1,id2   /printo/recete/:visitId   /printo/kartela/:patientId   /printo/plani/:planId
 */
export default function PrintPage() {
  const { kind = 'fature', id = '' } = useParams();
  const [params] = useSearchParams();
  const nav = useNavigate();
  const { user } = useAuth();
  const [data, setData] = useState<Data | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const k = kind as Kind;

  useEffect(() => {
    (async () => {
      const biz = await api.get<BusinessInfo>('/api/business');
      if (k === 'recete') {
        const visit = await api.get<Visit>(`/api/visits/${id}`);
        return { biz, visit, patient: await api.get<Patient>(`/api/patients/${visit.patientId}`) };
      }
      if (k === 'plani') {
        const plan = await api.get<TreatmentPlan>(`/api/plans/${id}`);
        return { biz, plan, patient: await api.get<Patient>(`/api/patients/${plan.patientId}`) };
      }
      const patient = await api.get<Patient>(`/api/patients/${id}`);
      if (k === 'kartela') return { biz, patient, statement: await api.get<Statement>(`/api/finance/statement/${id}`) };
      const visitId = params.get('visit');
      const ids = params.get('charges')?.split(',').filter(Boolean);
      let charges = await api.get<Charge[]>(`/api/finance/charges?patientId=${id}${visitId ? `&visitId=${visitId}` : ''}`);
      if (ids?.length) charges = charges.filter(c => ids.includes(c.id));
      return { biz, patient, charges };
    })().then(setData).catch(e => setErr(e.message));
  }, [k, id, params]);

  useEffect(() => {
    if (data) document.title = `${titles[k]} – ${data.patient.fullName}`;
    return () => { document.title = 'KLINIKA – Paneli i Administrimit'; };
  }, [data, k]);

  if (err) return <div className="page"><ErrorBox error={err} /><button className="btn ghost" onClick={() => nav(-1)}>← Kthehu</button></div>;
  if (!data) return <div className="center-screen"><Spinner /></div>;
  const { biz, patient } = data;
  const cur = biz.business.currency;
  const docNo = (prefix: string, seed: string) => `${prefix}-${new Date().toISOString().slice(0, 10).replace(/-/g, '')}-${seed.replace(/-/g, '').slice(0, 6).toUpperCase()}`;

  let body: ReactNode = null;
  let number = '';
  if (k === 'fature') {
    const list = data.charges ?? [];
    const total = list.reduce((s, c) => s + c.amount, 0);
    const discount = list.reduce((s, c) => s + c.discount, 0);
    number = docNo('F', list[0]?.id ?? patient.id);
    body = (
      <>
        <table className="p-table">
          <thead><tr><th>#</th><th>Data</th><th>Përshkrimi</th><th className="num">Sasia</th><th className="num">Çmimi</th><th className="num">Zbritje</th><th className="num">Totali</th></tr></thead>
          <tbody>
            {list.map((c, i) => (
              <tr key={c.id}><td>{i + 1}</td><td>{fmtDate(c.date)}</td><td>{c.description}</td><td className="num">{c.quantity}</td>
                <td className="num">{fmtMoney(c.unitPrice, cur)}</td><td className="num">{c.discount ? fmtMoney(c.discount, cur) : ''}</td><td className="num">{fmtMoney(c.amount, cur)}</td></tr>
            ))}
            {!list.length && <tr><td colSpan={7} className="center">Nuk ka shërbime.</td></tr>}
          </tbody>
        </table>
        <div className="p-totals">
          {discount > 0 && <div><span>Zbritje gjithsej</span><b>{fmtMoney(discount, cur)}</b></div>}
          <div className="grand"><span>TOTALI PËR PAGESË</span><b>{fmtMoney(total, cur)}</b></div>
          {patient.balance > 0 && <div><span>Borxhi i mbetur i pacientit (gjithsej)</span><b>{fmtMoney(patient.balance, cur)}</b></div>}
          {patient.balance < 0 && <div><span>Kredi e pacientit (paguar paraprakisht)</span><b>{fmtMoney(-patient.balance, cur)}</b></div>}
          {patient.balance === 0 && <div><span>Gjendja e pacientit</span><b>E shlyer – pa borxh</b></div>}
        </div>
        <p className="p-small">Dokument jo-fiskal. Për faturë tatimore kërkoni kuponin fiskal të klinikës.</p>
      </>
    );
  } else if (k === 'recete' && data.visit) {
    const v = data.visit;
    number = docNo('R', v.id);
    body = (
      <>
        {v.diagnosis && <section className="p-sec"><h4>Diagnoza</h4><p>{v.diagnosis}</p></section>}
        <section className="p-sec rx"><h4>Rp/</h4><p className="pre">{v.prescription || '—'}</p></section>
        {v.treatment && <section className="p-sec"><h4>Trajtimi / Udhëzime</h4><p className="pre">{v.treatment}</p></section>}
        {v.nextVisitDate && <section className="p-sec"><h4>Kontrolli i radhës</h4><p>{fmtDate(v.nextVisitDate)}</p></section>}
      </>
    );
  } else if (k === 'kartela' && data.statement) {
    const s = data.statement;
    number = docNo('K', patient.id);
    body = (
      <>
        <table className="p-table">
          <thead><tr><th>Data</th><th>Përshkrimi</th><th className="num">Detyrim</th><th className="num">Pagesë</th><th className="num">Balanca</th></tr></thead>
          <tbody>
            {[...s.entries].reverse().map(e => (
              <tr key={e.id}><td>{fmtDate(e.date)}</td><td>{e.description}</td><td className="num">{e.debit ? fmtMoney(e.debit, cur) : ''}</td>
                <td className="num">{e.credit ? fmtMoney(e.credit, cur) : ''}</td><td className="num">{fmtMoney(e.runningBalance, cur)}</td></tr>
            ))}
          </tbody>
        </table>
        <div className="p-totals">
          <div><span>Gjithsej faturuar</span><b>{fmtMoney(s.totalCharged, cur)}</b></div>
          <div><span>Gjithsej paguar</span><b>{fmtMoney(s.totalPaid, cur)}</b></div>
          <div className="grand"><span>{s.balance >= 0 ? 'BORXHI I MBETUR' : 'KREDI (PARAPAGIM)'}</span><b>{fmtMoney(Math.abs(s.balance), cur)}</b></div>
        </div>
      </>
    );
  } else if (k === 'plani' && data.plan) {
    const p = data.plan;
    number = docNo('P', p.id);
    body = (
      <>
        <h3 className="p-plan-title">{p.title} <span>({p.statusLabel})</span></h3>
        <table className="p-table">
          <thead><tr><th>#</th><th>Shërbimi</th><th>Dhëmbi</th><th className="num">Sasia</th><th className="num">Çmimi</th><th className="num">Totali</th></tr></thead>
          <tbody>
            {p.items.map((i, n) => (
              <tr key={i.id}><td>{n + 1}</td><td>{i.description}{i.done ? ' ✓' : ''}</td><td>{i.tooth ?? ''}</td><td className="num">{i.quantity}</td>
                <td className="num">{fmtMoney(i.unitPrice, cur)}</td><td className="num">{fmtMoney(i.amount, cur)}</td></tr>
            ))}
          </tbody>
        </table>
        <div className="p-totals"><div className="grand"><span>TOTALI I PLANIT</span><b>{fmtMoney(p.total, cur)}</b></div></div>
        <h4>Plani i pagesave</h4>
        <table className="p-table">
          <thead><tr><th>Kësti</th><th>Afati</th><th className="num">Shuma</th><th>Statusi</th></tr></thead>
          <tbody>
            {p.installments.map(i => (
              <tr key={i.id}><td>#{i.number}</td><td>{fmtDate(i.dueDate)}</td><td className="num">{fmtMoney(i.amount, cur)}</td>
                <td>{i.paidAt ? `Paguar ${fmtDate(i.paidAt)}` : 'Pa paguar'}</td></tr>
            ))}
          </tbody>
        </table>
        {p.notes && <p>{p.notes}</p>}
        <p className="p-small">Me nënshkrimin më poshtë, pacienti konfirmon se është informuar për trajtimin, koston dhe planin e pagesave.</p>
      </>
    );
  }

  const doctor = data.visit?.doctorName ?? data.plan?.doctorName;
  return (
    <div className="print-root">
      <div className="print-toolbar">
        <button className="btn ghost" onClick={() => nav(-1)}>← Kthehu</button>
        <span className="muted small">Te dritarja e printimit zgjidhni "Ruaj si PDF" për ta ruajtur ose dërguar me email.</span>
        <button className="btn primary" onClick={() => window.print()}>🖨 Printo / Ruaj PDF</button>
      </div>
      <div className="sheet">
        <header className="p-head">
          <div className="p-brand">
            {biz.business.logoUrl && <img src={assetUrl(biz.business.logoUrl)} alt="" />}
            <div>
              <h1>{biz.business.name}</h1>
              <div>{[biz.address, biz.city].filter(Boolean).join(', ')}</div>
              <div>{[biz.phone && `Tel: ${biz.phone}`, biz.email].filter(Boolean).join(' · ')}</div>
              {biz.nipt && <div>NIPT/NUI: {biz.nipt}</div>}
            </div>
          </div>
          <div className="p-doc">
            <h2>{titles[k]}</h2>
            <div>Nr. <b>{number}</b></div>
            <div>Data: {fmtDate(new Date().toISOString())}</div>
            {data.visit && <div>Vizita: {fmtDateTime(data.visit.visitDate)}</div>}
          </div>
        </header>

        <section className="p-patient">
          <div><span>Pacienti</span><b>{patient.fullName}</b></div>
          {patient.personalNumber && <div><span>Nr. personal</span><b>{patient.personalNumber}</b></div>}
          {patient.birthDate && <div><span>Datëlindja</span><b>{fmtDate(patient.birthDate)}{patient.age != null ? ` (${patient.age} vjeç)` : ''}</b></div>}
          {patient.gender && <div><span>Gjinia</span><b>{genderLabels[patient.gender]}</b></div>}
          {patient.phone && <div><span>Telefoni</span><b>{patient.phone}</b></div>}
          {k === 'recete' && patient.allergies && <div className="warn"><span>Alergji</span><b>{patient.allergies}</b></div>}
        </section>

        {body}

        <footer className="p-foot">
          <div className="p-sign">
            <div><span>{k === 'plani' ? 'Pacienti' : k === 'fature' || k === 'kartela' ? 'Pranoi' : ''}</span>{(k === 'plani' || k === 'fature' || k === 'kartela') && <i />}</div>
            <div><span>{k === 'recete' || k === 'plani' ? (doctor ?? biz.business.doctorLabel) : (user?.fullName ?? '')}</span><i /><small>Nënshkrimi dhe vula</small></div>
          </div>
          {biz.invoiceFooter && <div className="p-footer-text">{biz.invoiceFooter}</div>}
        </footer>
      </div>
    </div>
  );
}

import { Fragment, useState } from 'react';
import { api } from '../../api/client';
import type { User, UserRole } from '../../api/types';
import { useAuth } from '../../auth';
import { Badge, Card, ErrorBox, Field, Modal, Spinner, useAsync } from '../../components/ui';
import { fmtDateTime, roleLabels } from '../../sq';

const STAFF_ROLES: UserRole[] = ['Admin', 'Mjek', 'Infermier', 'Recepsion'];

const roleInfo: Record<string, string> = {
  Admin: 'Qasje e plotë: stafi, shërbimet, financat, historiku.',
  Mjek: 'Historiku mjekësor, vizitat, terminet dhe financat.',
  Infermier: 'Historiku mjekësor dhe terminet (pa financa).',
  Recepsion: 'Pacientët, terminet dhe pagesat (pa historik mjekësor).',
};

export default function Staff() {
  const { user } = useAuth();
  const list = useAsync(() => api.get<User[]>('/api/staff?includeInactive=true'));
  const [edit, setEdit] = useState<{ u?: User } | null>(null);
  const [reset, setReset] = useState<User | null>(null);
  const [msg, setMsg] = useState<string | null>(null);

  return (
    <div className="page">
      <div className="page-head">
        <h1>Stafi</h1>
        <button className="btn primary" onClick={() => setEdit({})}>+ Anëtar i ri</button>
      </div>
      {msg && <div className="alert success">{msg}</div>}
      <Card>
        <ErrorBox error={list.error} />
        {list.loading ? <Spinner /> : (
          <table className="table">
            <thead><tr><th>Emri</th><th>Roli</th><th>Telefoni</th><th>Hyrja e fundit</th><th>Statusi</th><th /></tr></thead>
            <tbody>
              {list.data?.map(u => (
                <tr key={u.id} className={u.isActive ? '' : 'dim'}>
                  <td><b>{u.fullName}</b>{u.title && <span className="muted"> · {u.title}</span>}<div className="muted small">{u.email}</div></td>
                  <td>{u.roleLabel}</td>
                  <td>{u.phone ?? '—'}</td>
                  <td className="small">{fmtDateTime(u.lastLoginAt)}</td>
                  <td>{u.isActive ? <Badge tone="green">Aktiv</Badge> : <Badge tone="red">Joaktiv</Badge>}</td>
                  <td className="row gap">
                    <button className="btn ghost small" onClick={() => setEdit({ u })}>Ndrysho</button>
                    {u.id !== user?.id && <button className="btn ghost small" onClick={() => setReset(u)}>Fjalëkalimi</button>}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </Card>
      <Card title="Rolet dhe lejet">
        <dl className="dl">{STAFF_ROLES.map(r => <Fragment key={r}><dt>{roleLabels[r]}</dt><dd>{roleInfo[r]}</dd></Fragment>)}</dl>
      </Card>
      {edit && <StaffModal u={edit.u} onClose={() => setEdit(null)} onDone={() => { setEdit(null); list.reload(); }} />}
      {reset && <ResetModal u={reset} onClose={() => setReset(null)} onDone={m => { setReset(null); setMsg(m); }} />}
    </div>
  );
}

function StaffModal({ u, onClose, onDone }: { u?: User; onClose: () => void; onDone: () => void }) {
  const [f, setF] = useState({ fullName: u?.fullName ?? '', email: u?.email ?? '', phone: u?.phone ?? '', role: (u?.role ?? 'Mjek') as UserRole, title: u?.title ?? '', password: '', isActive: u?.isActive ?? true });
  const [err, setErr] = useState<string | null>(null);
  const go = async () => {
    try {
      if (u) await api.put(`/api/staff/${u.id}`, { fullName: f.fullName, phone: f.phone || null, role: f.role, title: f.title || null, isActive: f.isActive });
      else await api.post('/api/staff', { fullName: f.fullName, email: f.email, phone: f.phone || null, role: f.role, title: f.title || null, password: f.password });
      onDone();
    } catch (e: any) { setErr(e.message); }
  };
  return (
    <Modal title={u ? 'Ndrysho anëtarin' : 'Anëtar i ri i stafit'} onClose={onClose}>
      <ErrorBox error={err} />
      <div className="form-grid">
        <Field label="Emri i plotë *" full><input value={f.fullName} onChange={e => setF({ ...f, fullName: e.target.value })} /></Field>
        <Field label="Email (hyrja) *"><input type="email" value={f.email} disabled={!!u} onChange={e => setF({ ...f, email: e.target.value })} /></Field>
        <Field label="Telefoni"><input value={f.phone} onChange={e => setF({ ...f, phone: e.target.value })} /></Field>
        <Field label="Roli *">
          <select value={f.role} onChange={e => setF({ ...f, role: e.target.value as UserRole })}>
            {STAFF_ROLES.map(r => <option key={r} value={r}>{roleLabels[r]}</option>)}
          </select>
        </Field>
        <Field label="Titulli / Specializimi"><input value={f.title} onChange={e => setF({ ...f, title: e.target.value })} placeholder="p.sh. Ortodont" /></Field>
        {!u && <Field label="Fjalëkalimi fillestar * (min. 8, shkronja + numra)" full><input value={f.password} onChange={e => setF({ ...f, password: e.target.value })} /></Field>}
        {u && <label className="check"><input type="checkbox" checked={f.isActive} onChange={e => setF({ ...f, isActive: e.target.checked })} /> Aktiv</label>}
        <p className="muted small full">{roleInfo[f.role]}</p>
      </div>
      <div className="modal-actions"><button className="btn ghost" onClick={onClose}>Anulo</button><button className="btn primary" disabled={!f.fullName || (!u && (!f.email || f.password.length < 8))} onClick={go}>Ruaj</button></div>
    </Modal>
  );
}

function ResetModal({ u, onClose, onDone }: { u: User; onClose: () => void; onDone: (m: string) => void }) {
  const [pwd, setPwd] = useState('');
  const [err, setErr] = useState<string | null>(null);
  const go = async () => {
    try { const r = await api.post<{ message: string }>(`/api/staff/${u.id}/reset-password`, { newPassword: pwd }); onDone(`${r.message} (${u.fullName})`); }
    catch (e: any) { setErr(e.message); }
  };
  return (
    <Modal title={`Fjalëkalim i ri – ${u.fullName}`} onClose={onClose}>
      <ErrorBox error={err} />
      <Field label="Fjalëkalimi i ri (min. 8, shkronja + numra)" full><input value={pwd} onChange={e => setPwd(e.target.value)} /></Field>
      <div className="modal-actions"><button className="btn ghost" onClick={onClose}>Anulo</button><button className="btn primary" disabled={pwd.length < 8} onClick={go}>Ruaj</button></div>
    </Modal>
  );
}

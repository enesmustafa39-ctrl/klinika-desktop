import { useState } from 'react';
import { Link } from 'react-router-dom';
import { api, qs } from '../../api/client';
import type { Debtor, OverdueInstallment, Payment, PaymentMethod, ServiceItem } from '../../api/types';
import { useAuth } from '../../auth';
import { Card, Empty, ErrorBox, Field, Modal, Spinner, Stat, useAsync } from '../../components/ui';
import { fmtDate, fmtMoney, methodLabels, todayIso } from '../../sq';

/** Financat: debitorët (kreditë e klientëve) dhe pagesat e arkëtuara. */
export default function Finance() {
  const { business, hasFeature } = useAuth();
  const overdue = useAsync(() => (hasFeature('treatment_plans') ? api.get<OverdueInstallment[]>('/api/plans/overdue') : Promise.resolve([] as OverdueInstallment[])));
  const cur = business?.currency;
  const [tab, setTab] = useState<'borxhet' | 'pagesat' | 'kestet'>('borxhet');
  const first = new Date(); first.setDate(1);
  const [from, setFrom] = useState(first.toISOString().slice(0, 10));
  const [to, setTo] = useState(todayIso());

  const debtors = useAsync(() => api.get<Debtor[]>('/api/finance/debtors'));
  const payments = useAsync(() => api.get<Payment[]>(`/api/finance/payments${qs({
    from: new Date(from + 'T00:00:00').toISOString(), to: new Date(to + 'T23:59:59').toISOString(),
  })}`), [from, to]);

  const totalDebt = debtors.data?.reduce((s, d) => s + d.balance, 0) ?? 0;
  const totalPaid = payments.data?.reduce((s, p) => s + p.amount, 0) ?? 0;
  const byMethod = (payments.data ?? []).reduce<Record<string, number>>((m, p) => ({ ...m, [p.methodLabel]: (m[p.methodLabel] ?? 0) + p.amount }), {});

  const exportCsv = () => {
    const rows = [['Pacienti', 'Telefoni', 'Faturuar', 'Paguar', 'Borxhi', 'Pagesa e fundit'],
      ...(debtors.data ?? []).map(d => [d.patientName, d.phone ?? '', d.totalCharged, d.totalPaid, d.balance, fmtDate(d.lastPayment)])];
    const csv = rows.map(r => r.map(c => `"${String(c).replace(/"/g, '""')}"`).join(';')).join('\n');
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob(['﻿' + csv], { type: 'text/csv;charset=utf-8' }));
    a.download = `borxhet-${todayIso()}.csv`;
    a.click();
  };

  return (
    <div className="page">
      <h1>Financat</h1>
      <div className="stats">
        <Stat label="Borxhe gjithsej" value={fmtMoney(totalDebt, cur)} tone="red" hint={`${debtors.data?.length ?? 0} klientë`} />
        <Stat label="Arkëtuar në periudhë" value={fmtMoney(totalPaid, cur)} tone="green" hint={`${payments.data?.length ?? 0} pagesa`} />
        {Object.entries(byMethod).slice(0, 2).map(([k, v]) => <Stat key={k} label={k} value={fmtMoney(v, cur)} />)}
      </div>
      <div className="tabs">
        <button className={tab === 'borxhet' ? 'on' : ''} onClick={() => setTab('borxhet')}>Klientët me borxh</button>
        <button className={tab === 'pagesat' ? 'on' : ''} onClick={() => setTab('pagesat')}>Pagesat</button>
        {hasFeature('treatment_plans') && <button className={tab === 'kestet' ? 'on' : ''} onClick={() => setTab('kestet')}>Këste me vonesë{overdue.data?.length ? ` (${overdue.data.length})` : ''}</button>}
      </div>

      {tab === 'kestet' && (
        <Card title="Këstet e planeve të trajtimit me vonesë">
          {overdue.loading ? <Spinner /> : !overdue.data?.length ? <Empty>Nuk ka këste me vonesë. 👍</Empty> : (
            <table className="table">
              <thead><tr><th>Pacienti</th><th>Telefoni</th><th>Plani</th><th>Kësti</th><th>Afati</th><th className="num">Vonesë</th><th className="num">Shuma</th></tr></thead>
              <tbody>
                {overdue.data.map(o => (
                  <tr key={o.installmentId}>
                    <td><Link className="link" to={`/pacientet/${o.patientId}`}>{o.patientName}</Link></td>
                    <td>{o.phone ?? '—'}</td><td>{o.planTitle}</td><td>#{o.number}</td><td>{fmtDate(o.dueDate)}</td>
                    <td className="num red">{o.daysLate} ditë</td><td className="num"><b>{fmtMoney(o.amount, cur)}</b></td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </Card>
      )}

      {tab === 'borxhet' && (
        <Card title="Klientët me borxh" actions={<button className="btn ghost" onClick={exportCsv}>Eksporto CSV</button>}>
          <ErrorBox error={debtors.error} />
          {debtors.loading ? <Spinner /> : !debtors.data?.length ? <Empty>Asnjë klient nuk ka borxh. 🎉</Empty> : (
            <table className="table">
              <thead><tr><th>Pacienti</th><th>Telefoni</th><th className="num">Faturuar</th><th className="num">Paguar</th><th className="num">Borxhi</th><th>Pagesa e fundit</th></tr></thead>
              <tbody>
                {debtors.data.map(d => (
                  <tr key={d.patientId}>
                    <td><Link className="link" to={`/pacientet/${d.patientId}`}>{d.patientName}</Link></td>
                    <td>{d.phone ?? '—'}</td>
                    <td className="num">{fmtMoney(d.totalCharged, cur)}</td>
                    <td className="num">{fmtMoney(d.totalPaid, cur)}</td>
                    <td className="num red"><b>{fmtMoney(d.balance, cur)}</b></td>
                    <td>{fmtDate(d.lastPayment)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </Card>
      )}

      {tab === 'pagesat' && (
        <Card title="Pagesat" actions={<>
          <input type="date" value={from} onChange={e => setFrom(e.target.value)} />
          <input type="date" value={to} onChange={e => setTo(e.target.value)} />
        </>}>
          {payments.loading ? <Spinner /> : !payments.data?.length ? <Empty>Nuk ka pagesa në këtë periudhë.</Empty> : (
            <table className="table">
              <thead><tr><th>Data</th><th>Pacienti</th><th>Mënyra</th><th>Referenca</th><th className="num">Shuma</th></tr></thead>
              <tbody>
                {payments.data.map(p => (
                  <tr key={p.id}>
                    <td>{fmtDate(p.date)}</td>
                    <td><Link className="link" to={`/pacientet/${p.patientId}`}>{p.patientName}</Link></td>
                    <td>{p.methodLabel}</td>
                    <td>{p.reference ?? '—'}</td>
                    <td className="num green">{fmtMoney(p.amount, cur)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </Card>
      )}
    </div>
  );
}

export function ChargeModal({ patientId, onClose, onDone }: { patientId: string; onClose: () => void; onDone: () => void }) {
  const { business } = useAuth();
  const services = useAsync(() => api.get<ServiceItem[]>('/api/services'));
  const [f, setF] = useState({ serviceItemId: '', description: '', quantity: '1', unitPrice: '', discount: '0', date: todayIso() });
  const [err, setErr] = useState<string | null>(null);
  const pick = (id: string) => {
    const s = services.data?.find(x => x.id === id);
    setF(v => ({ ...v, serviceItemId: id, description: s?.name ?? v.description, unitPrice: s ? String(s.price) : v.unitPrice }));
  };
  const total = Math.max(0, (+f.quantity || 0) * (+f.unitPrice || 0) - (+f.discount || 0));
  const go = async () => {
    try {
      await api.post('/api/finance/charges', {
        patientId, serviceItemId: f.serviceItemId || null, description: f.description, quantity: +f.quantity || 1,
        unitPrice: +f.unitPrice, discount: +f.discount || 0, date: new Date(f.date + 'T12:00:00').toISOString(),
      });
      onDone();
    } catch (e: any) { setErr(e.message); }
  };
  return (
    <Modal title="Shto ngarkesë (detyrim)" onClose={onClose}>
      <ErrorBox error={err} />
      <div className="form-grid">
        <Field label="Shërbimi" full>
          <select value={f.serviceItemId} onChange={e => pick(e.target.value)}>
            <option value="">— Tjetër (shkruaj përshkrimin) —</option>
            {services.data?.map(s => <option key={s.id} value={s.id}>{s.name} — {fmtMoney(s.price, business?.currency)}</option>)}
          </select>
        </Field>
        <Field label="Përshkrimi" full><input value={f.description} onChange={e => setF({ ...f, description: e.target.value })} /></Field>
        <Field label="Sasia"><input type="number" min={1} step="any" value={f.quantity} onChange={e => setF({ ...f, quantity: e.target.value })} /></Field>
        <Field label="Çmimi"><input type="number" min={0} step="any" value={f.unitPrice} onChange={e => setF({ ...f, unitPrice: e.target.value })} /></Field>
        <Field label="Zbritje"><input type="number" min={0} step="any" value={f.discount} onChange={e => setF({ ...f, discount: e.target.value })} /></Field>
        <Field label="Data"><input type="date" value={f.date} onChange={e => setF({ ...f, date: e.target.value })} /></Field>
      </div>
      <p>Totali: <b>{fmtMoney(total, business?.currency)}</b></p>
      <div className="modal-actions"><button className="btn ghost" onClick={onClose}>Anulo</button><button className="btn primary" disabled={!f.description || f.unitPrice === ''} onClick={go}>Ruaj</button></div>
    </Modal>
  );
}

export function PaymentModal({ patientId, suggested, onClose, onDone }: { patientId: string; suggested?: number; onClose: () => void; onDone: () => void }) {
  const { business } = useAuth();
  const [f, setF] = useState({ amount: suggested && suggested > 0 ? String(suggested) : '', method: 'Kesh' as PaymentMethod, reference: '', notes: '', date: todayIso() });
  const [err, setErr] = useState<string | null>(null);
  const go = async () => {
    try {
      await api.post('/api/finance/payments', {
        patientId, amount: +f.amount, method: f.method, reference: f.reference || null, notes: f.notes || null,
        date: new Date(f.date + 'T12:00:00').toISOString(),
      });
      onDone();
    } catch (e: any) { setErr(e.message); }
  };
  return (
    <Modal title="Regjistro pagesë" onClose={onClose}>
      <ErrorBox error={err} />
      {suggested != null && suggested > 0 && <p className="muted">Borxhi aktual: <b>{fmtMoney(suggested, business?.currency)}</b></p>}
      <div className="form-grid">
        <Field label="Shuma *"><input type="number" min={0.01} step="any" value={f.amount} onChange={e => setF({ ...f, amount: e.target.value })} autoFocus /></Field>
        <Field label="Mënyra e pagesës">
          <select value={f.method} onChange={e => setF({ ...f, method: e.target.value as PaymentMethod })}>
            {Object.entries(methodLabels).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
          </select>
        </Field>
        <Field label="Data"><input type="date" value={f.date} onChange={e => setF({ ...f, date: e.target.value })} /></Field>
        <Field label="Referenca / Nr. fature"><input value={f.reference} onChange={e => setF({ ...f, reference: e.target.value })} /></Field>
        <Field label="Shënime" full><input value={f.notes} onChange={e => setF({ ...f, notes: e.target.value })} /></Field>
      </div>
      <div className="modal-actions"><button className="btn ghost" onClick={onClose}>Anulo</button><button className="btn primary" disabled={!(+f.amount > 0)} onClick={go}>Ruaj pagesën</button></div>
    </Modal>
  );
}

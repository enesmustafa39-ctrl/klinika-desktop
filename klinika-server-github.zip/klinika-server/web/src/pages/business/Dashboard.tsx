import type { CSSProperties } from 'react';
import { Link } from 'react-router-dom';
import { api, assetUrl } from '../../api/client';
import type { Dashboard as D } from '../../api/types';
import { useAuth } from '../../auth';
import { Badge, Card, Empty, ErrorBox, Spinner, Stat, useAsync } from '../../components/ui';
import { fmtLongDate, fmtMoney, fmtTime } from '../../sq';

export default function Dashboard() {
  const { user, business, hasRole } = useAuth();
  const { data, error, loading } = useAsync(() => api.get<D>('/api/dashboard'));
  const cur = business?.currency ?? 'EUR';
  const showMoney = hasRole('Admin', 'Recepsion', 'Mjek');

  if (loading) return <Spinner />;
  if (!data) return <ErrorBox error={error} />;
  const max = Math.max(1, ...data.revenue6Months.flatMap(m => [m.charged, m.paid]));

  return (
    <div className="page">
      {(business?.logoUrl || business?.backgroundUrl) && (
        <div className="brand-hero" style={business.backgroundUrl ? ({ '--brand-bg': `url("${assetUrl(business.backgroundUrl)}")` } as CSSProperties) : undefined}>
          {business.logoUrl && <img src={assetUrl(business.logoUrl)} alt={business.name} />}
          <div><h2>{business.name}</h2><span>{business.specialtyLabel}</span></div>
        </div>
      )}
      <div className="page-head">
        <div><h1>Mirëdita, {user?.fullName.split(' ')[0]}</h1><p className="muted">{fmtLongDate(new Date())}</p></div>
        <div className="row gap">
          <Link className="btn ghost" to="/terminet">+ Termin</Link>
          <Link className="btn primary" to="/pacientet?i-ri=1">+ Pacient i ri</Link>
        </div>
      </div>

      <div className="stats">
        <Stat label="Pacientë aktivë" value={data.patients} hint={`+${data.newPatientsThisMonth} këtë muaj`} />
        <Stat label="Terminet sot" value={data.appointmentsToday} hint={`${data.visitsToday} vizita të regjistruara`} />
        {showMoney && <Stat label="Arkëtuar këtë muaj" value={fmtMoney(data.revenueThisMonth, cur)} hint={`Faturuar ${fmtMoney(data.chargedThisMonth, cur)}`} tone="green" />}
        {showMoney && <Stat label="Borxhe të papaguara" value={fmtMoney(data.totalOutstanding, cur)} hint={`${data.debtors} klientë me borxh`} tone="red" />}
      </div>

      <div className="grid-2">
        <Card title="Terminet e sotme" actions={<Link className="link" to="/terminet">Kalendari →</Link>}>
          {!data.upcomingToday.length ? <Empty>Nuk ka termine për sot.</Empty> : (
            <ul className="timeline">
              {data.upcomingToday.map(a => (
                <li key={a.id}>
                  <time>{fmtTime(a.startsAt)}</time>
                  <div>
                    <Link className="link" to={`/pacientet/${a.patientId}`}><b>{a.patientName}</b></Link>
                    <div className="muted small">{[a.serviceName, a.staffName].filter(Boolean).join(' · ') || a.notes}</div>
                  </div>
                  <Badge tone={a.status === 'Perfunduar' ? 'green' : a.status === 'Konfirmuar' ? 'blue' : 'neutral'}>{a.statusLabel}</Badge>
                </li>
              ))}
            </ul>
          )}
        </Card>
        {showMoney && (
          <Card title="6 muajt e fundit">
            <div className="chart">
              {data.revenue6Months.map(m => (
                <div key={m.month} className="chart-col" title={`Faturuar ${fmtMoney(m.charged, cur)} · Arkëtuar ${fmtMoney(m.paid, cur)}`}>
                  <div className="chart-bars">
                    <i className="c1" style={{ height: `${(m.charged / max) * 100}%` }} />
                    <i className="c2" style={{ height: `${(m.paid / max) * 100}%` }} />
                  </div>
                  <span>{m.month}</span>
                </div>
              ))}
            </div>
            <div className="legend"><span><i className="c1" />Faturuar</span><span><i className="c2" />Arkëtuar</span></div>
          </Card>
        )}
      </div>
    </div>
  );
}

import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '../../api/client';
import type { PaymentMethod, ServiceItem, TreatmentPlan, User } from '../../api/types';
import { useAuth } from '../../auth';
import { Badge, Card, Empty, ErrorBox, Field, Modal, Spinner, useAsync } from '../../components/ui';
import { fmtDate, fmtMoney, methodLabels, todayIso } from '../../sq';

const statusTone = (s: TreatmentPlan['status']) => (s === 'Aktiv' ? 'blue' : s === 'Perfunduar' ? 'green' : s === 'Anuluar' ? 'red' : 'amber');

/** Skeda "Planet e trajtimit" në kartelën e pacientit. */
export default function PlansTab({ patientId, onChange }: { patientId: string; onChange: () => void }) {
  const { business, hasRole } = useAuth();
  const nav = useNavigate();
  const cur = business?.currency;
  const plans = useAsync(() => api.get<TreatmentPlan[]>(`/api/patients/${patientId}/plans`), [patientId]);
  const [create, setCreate] = useState<TreatmentPlan | 'new' | null>(null);
  const [pay, setPay] = useState<{ plan: TreatmentPlan; instId: string } | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const canEdit = hasRole('Admin', 'Mjek');
  const canPay = hasRole('Admin', 'Mjek', 'Recepsion');

  const act = async (path: string, confirmText?: string) => {
    if (confirmText && !confirm(confirmText)) return;
    setErr(null);
    try { await api.post(path); plans.reload(); onChange(); } catch (e: any) { setErr(e.message); }
  };
  const remove = async (p: TreatmentPlan) => {
    if (!confirm(`Të fshihet plani "${p.title}"?`)) return;
    try { await api.del(`/api/plans/${p.id}`); plans.reload(); } catch (e: any) { setErr(e.message); }
  };

  return (
    <Card title="Planet e trajtimit" actions={canEdit && <button className="btn primary" onClick={() => setCreate('new')}>+ Plan i ri</button>}>
      <ErrorBox error={err ?? plans.error} />
      {plans.loading ? <Spinner /> : !plans.data?.length ? <Empty>Nuk ka plane trajtimi.</Empty> : (
        <div className="plans">
          {plans.data.map(p => {
            const pct = p.total > 0 ? Math.round((p.paid / p.total) * 100) : 0;
            return (
              <article key={p.id} className={`plan ${p.status === 'Anuluar' ? 'dim' : ''}`}>
                <header>
                  <div>
                    <h3>{p.title} <Badge tone={statusTone(p.status)}>{p.statusLabel}</Badge>{p.overdueCount > 0 && <> <Badge tone="red">{p.overdueCount} këst me vonesë</Badge></>}</h3>
                    <span className="small muted">{fmtDate(p.createdAt)}{p.doctorName ? ` · ${p.doctorName}` : ''}{p.notes ? ` · ${p.notes}` : ''}</span>
                  </div>
                  <div className="row gap">
                    <button className="btn ghost small" onClick={() => nav(`/printo/plani/${p.id}`)}>🖨 Printo</button>
                    {p.status === 'Propozuar' && canPay && <button className="btn primary small" onClick={() => act(`/api/plans/${p.id}/activate`, `Pacienti e pranoi planin? Shuma ${fmtMoney(p.total, cur)} do të ngarkohet në llogarinë e tij.`)}>✓ Pacienti pranoi – Aktivizo</button>}
                    {p.status === 'Propozuar' && canEdit && <button className="btn ghost small" onClick={() => setCreate(p)}>Ndrysho</button>}
                    {p.status === 'Propozuar' && canEdit && <button className="btn ghost small" onClick={() => remove(p)}>Fshi</button>}
                    {p.status === 'Aktiv' && canEdit && <button className="btn ghost small" onClick={() => act(`/api/plans/${p.id}/complete`, 'Të shënohet plani si i përfunduar?')}>Përfundo</button>}
                    {(p.status === 'Aktiv' || p.status === 'Propozuar') && canEdit && <button className="btn danger ghost small" onClick={() => act(`/api/plans/${p.id}/cancel`, p.status === 'Aktiv' ? 'Të anulohet plani? Pjesa e papaguar do të hiqet nga borxhi i pacientit.' : 'Të anulohet plani?')}>Anulo</button>}
                  </div>
                </header>

                <div className="plan-money">
                  <div><span>Totali</span><b>{fmtMoney(p.total, cur)}</b></div>
                  <div><span>Paguar</span><b className="green">{fmtMoney(p.paid, cur)}</b></div>
                  <div><span>Mbetur</span><b className={p.remaining > 0 ? 'red' : ''}>{fmtMoney(p.remaining, cur)}</b></div>
                  <div><span>Progresi</span><b>{p.itemsDone}/{p.itemsTotal} seanca</b></div>
                </div>
                <div className="progress"><i style={{ width: `${pct}%` }} /></div>

                <div className="plan-grid">
                  <div>
                    <h4>Shërbimet</h4>
                    <ul className="checklist">
                      {p.items.map(i => (
                        <li key={i.id} className={i.done ? 'done' : ''}>
                          <label>
                            <input type="checkbox" checked={i.done} disabled={p.status !== 'Aktiv' || !hasRole('Admin', 'Mjek', 'Infermier')}
                              onChange={() => act(`/api/plans/${p.id}/items/${i.id}/toggle`)} />
                            <span>{i.description}{i.tooth && <span className="muted"> · 🦷 {i.tooth}</span>}{i.quantity !== 1 && <span className="muted"> × {i.quantity}</span>}</span>
                          </label>
                          <span>{fmtMoney(i.amount, cur)}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div>
                    <h4>Këstet</h4>
                    <table className="table compact">
                      <tbody>
                        {p.installments.map(k => (
                          <tr key={k.id} className={k.isOverdue ? 'overdue' : ''}>
                            <td>#{k.number}</td>
                            <td>{fmtDate(k.dueDate)}</td>
                            <td className="num">{fmtMoney(k.amount, cur)}</td>
                            <td>
                              {k.paidAt ? <Badge tone="green">Paguar {fmtDate(k.paidAt)}</Badge>
                                : k.isOverdue ? <Badge tone="red">Me vonesë</Badge> : <Badge>Pa paguar</Badge>}
                            </td>
                            <td>
                              {!k.paidAt && p.status === 'Aktiv' && canPay && <button className="btn primary small" onClick={() => setPay({ plan: p, instId: k.id })}>Paguaj</button>}
                              {k.paidAt && hasRole('Admin') && <button className="icon-btn" title="Anulo pagesën" onClick={() => act(`/api/plans/${p.id}/installments/${k.id}/unpay`, 'Të anulohet pagesa e këtij kësti?')}>↶</button>}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      )}
      {create && <PlanModal patientId={patientId} plan={create === 'new' ? undefined : create} onClose={() => setCreate(null)} onSaved={() => { setCreate(null); plans.reload(); onChange(); }} />}
      {pay && <PayModal plan={pay.plan} instId={pay.instId} onClose={() => setPay(null)} onDone={() => { setPay(null); plans.reload(); onChange(); }} />}
    </Card>
  );
}

interface Line { serviceItemId: string; description: string; tooth: string; quantity: number; unitPrice: number; discount: number }

function PlanModal({ patientId, plan, onClose, onSaved }: { patientId: string; plan?: TreatmentPlan; onClose: () => void; onSaved: () => void }) {
  const { business, user } = useAuth();
  const cur = business?.currency;
  const meta = useAsync(() => Promise.all([api.get<ServiceItem[]>('/api/services'), api.get<User[]>('/api/staff')]));
  const [services, staff] = meta.data ?? [[], []];
  const [title, setTitle] = useState(plan?.title ?? '');
  const [notes, setNotes] = useState(plan?.notes ?? '');
  const [doctorId, setDoctorId] = useState(plan?.doctorId ?? (user?.role === 'Mjek' || user?.role === 'Admin' ? user.id : ''));
  const [lines, setLines] = useState<Line[]>(plan?.items.map(i => ({
    serviceItemId: i.serviceItemId ?? '', description: i.description, tooth: i.tooth ?? '', quantity: i.quantity, unitPrice: i.unitPrice, discount: i.discount,
  })) ?? []);
  const [count, setCount] = useState(plan?.installments.length || 1);
  const [first, setFirst] = useState(plan?.installments[0]?.dueDate ?? todayIso());
  const [interval, setInterval_] = useState(1);
  const [activate, setActivate] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const add = (id: string) => {
    const s = services.find(x => x.id === id);
    if (s) setLines(l => [...l, { serviceItemId: s.id, description: s.name, tooth: '', quantity: 1, unitPrice: s.price, discount: 0 }]);
  };
  const upd = (i: number, patch: Partial<Line>) => setLines(l => l.map((x, j) => (j === i ? { ...x, ...patch } : x)));
  const total = lines.reduce((s, l) => s + Math.max(0, l.quantity * l.unitPrice - l.discount), 0);
  const each = count > 0 ? total / count : total;
  const preview = Array.from({ length: Math.min(count, 12) }, (_, i) => {
    const d = new Date(first + 'T12:00:00'); d.setMonth(d.getMonth() + i * interval);
    return { n: i + 1, date: d, amount: i === count - 1 ? total - Math.round(each * 100) / 100 * (count - 1) : Math.round(each * 100) / 100 };
  });

  const save = async () => {
    if (!title.trim()) return setErr('Shkruani titullin e planit.');
    if (!lines.length) return setErr('Shtoni të paktën një shërbim.');
    setBusy(true); setErr(null);
    const items = lines.map(l => ({ serviceItemId: l.serviceItemId || null, description: l.description, tooth: l.tooth || null, quantity: l.quantity, unitPrice: l.unitPrice, discount: l.discount }));
    try {
      if (plan) await api.put(`/api/plans/${plan.id}`, { title, notes: notes || null, doctorId: doctorId || null, items, installments: count, firstDueDate: first, intervalMonths: interval });
      else await api.post('/api/plans', { patientId, title, notes: notes || null, doctorId: doctorId || null, items, installments: count, firstDueDate: first, intervalMonths: interval, activate });
      onSaved();
    } catch (e: any) { setErr(e.message); } finally { setBusy(false); }
  };

  return (
    <Modal title={plan ? 'Ndrysho planin' : 'Plan i ri trajtimi'} onClose={onClose} wide>
      <div className="form-grid">
        {err && <div className="alert error full">{err}</div>}
        <Field label="Titulli *"><input value={title} onChange={e => setTitle(e.target.value)} placeholder="p.sh. Implant 36 + kurorë" autoFocus /></Field>
        <Field label={business?.doctorLabel ?? 'Mjeku'}>
          <select value={doctorId} onChange={e => setDoctorId(e.target.value)}>
            <option value="">—</option>{staff.filter(s => s.role === 'Mjek' || s.role === 'Admin').map(s => <option key={s.id} value={s.id}>{s.fullName}</option>)}
          </select>
        </Field>
        <fieldset className="full">
          <legend>Shërbimet / seancat</legend>
          <select value="" onChange={e => add(e.target.value)}>
            <option value="">+ Shto shërbim…</option>
            {services.map(s => <option key={s.id} value={s.id}>{s.name} — {fmtMoney(s.price, cur)}</option>)}
          </select>
          {lines.length > 0 && (
            <table className="table compact">
              <thead><tr><th>Shërbimi</th>{business?.specialty === 'Stomatologji' && <th>Dhëmbi</th>}<th>Sasia</th><th>Çmimi</th><th>Zbritje</th><th className="num">Totali</th><th /></tr></thead>
              <tbody>
                {lines.map((l, i) => (
                  <tr key={i}>
                    <td><input value={l.description} onChange={e => upd(i, { description: e.target.value })} /></td>
                    {business?.specialty === 'Stomatologji' && <td><input className="w-xs" value={l.tooth} onChange={e => upd(i, { tooth: e.target.value })} placeholder="36" /></td>}
                    <td><input className="w-xs" type="number" min={1} step="any" value={l.quantity} onChange={e => upd(i, { quantity: +e.target.value })} /></td>
                    <td><input className="w-sm" type="number" min={0} step="any" value={l.unitPrice} onChange={e => upd(i, { unitPrice: +e.target.value })} /></td>
                    <td><input className="w-sm" type="number" min={0} step="any" value={l.discount} onChange={e => upd(i, { discount: +e.target.value })} /></td>
                    <td className="num">{fmtMoney(Math.max(0, l.quantity * l.unitPrice - l.discount), cur)}</td>
                    <td><button className="icon-btn" onClick={() => setLines(x => x.filter((_, j) => j !== i))}>✕</button></td>
                  </tr>
                ))}
                <tr><td colSpan={business?.specialty === 'Stomatologji' ? 5 : 4} className="num"><b>Gjithsej</b></td><td className="num"><b>{fmtMoney(total, cur)}</b></td><td /></tr>
              </tbody>
            </table>
          )}
        </fieldset>
        <Field label="Numri i kësteve">
          <select value={count} onChange={e => setCount(+e.target.value)}>
            {[1, 2, 3, 4, 5, 6, 8, 10, 12, 18, 24].map(n => <option key={n} value={n}>{n === 1 ? '1 (pagesë e plotë)' : `${n} këste`}</option>)}
          </select>
        </Field>
        <Field label="Data e këstit të parë"><input type="date" value={first} onChange={e => setFirst(e.target.value)} /></Field>
        <Field label="Çdo sa muaj">
          <select value={interval} onChange={e => setInterval_(+e.target.value)}>
            <option value={1}>Çdo muaj</option><option value={2}>Çdo 2 muaj</option><option value={3}>Çdo 3 muaj</option><option value={0}>Të gjitha në të njëjtën ditë</option>
          </select>
        </Field>
        <Field label="Shënime"><input value={notes} onChange={e => setNotes(e.target.value)} /></Field>
        {count > 1 && total > 0 && (
          <div className="full installments-preview">
            {preview.map(p => <span key={p.n}>#{p.n} · {fmtDate(p.date.toISOString())} · <b>{fmtMoney(p.amount, cur)}</b></span>)}
            {count > 12 && <span>…</span>}
          </div>
        )}
        {!plan && (
          <label className="check full"><input type="checkbox" checked={activate} onChange={e => setActivate(e.target.checked)} />
            Pacienti e ka pranuar planin – aktivizoje menjëherë (totali ngarkohet në llogari)</label>
        )}
        <div className="modal-actions full">
          <button className="btn ghost" onClick={onClose}>Anulo</button>
          <button className="btn primary" disabled={busy} onClick={save}>{busy ? 'Duke ruajtur…' : 'Ruaj planin'}</button>
        </div>
      </div>
    </Modal>
  );
}

function PayModal({ plan, instId, onClose, onDone }: { plan: TreatmentPlan; instId: string; onClose: () => void; onDone: () => void }) {
  const { business } = useAuth();
  const k = plan.installments.find(i => i.id === instId)!;
  const [method, setMethod] = useState<PaymentMethod>('Kesh');
  const [date, setDate] = useState(todayIso());
  const [reference, setReference] = useState('');
  const [err, setErr] = useState<string | null>(null);
  const go = async () => {
    try {
      await api.post(`/api/plans/${plan.id}/installments/${instId}/pay`, { method, date: new Date(date + 'T12:00:00').toISOString(), reference: reference || null });
      onDone();
    } catch (e: any) { setErr(e.message); }
  };
  return (
    <Modal title={`Pagesa e këstit #${k.number} – ${plan.title}`} onClose={onClose}>
      <ErrorBox error={err} />
      <p>Shuma: <b>{fmtMoney(k.amount, business?.currency)}</b> · Afati: {fmtDate(k.dueDate)}</p>
      <div className="form-grid">
        <Field label="Mënyra e pagesës">
          <select value={method} onChange={e => setMethod(e.target.value as PaymentMethod)}>
            {Object.entries(methodLabels).map(([v, l]) => <option key={v} value={v}>{l}</option>)}
          </select>
        </Field>
        <Field label="Data"><input type="date" value={date} onChange={e => setDate(e.target.value)} /></Field>
        <Field label="Referenca (opsionale)" full><input value={reference} onChange={e => setReference(e.target.value)} /></Field>
      </div>
      <div className="modal-actions"><button className="btn ghost" onClick={onClose}>Anulo</button><button className="btn primary" onClick={go}>Regjistro pagesën</button></div>
    </Modal>
  );
}

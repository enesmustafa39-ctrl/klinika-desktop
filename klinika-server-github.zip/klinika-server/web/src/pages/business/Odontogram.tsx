import { useState } from 'react';
import { api } from '../../api/client';
import type { PatientFile, ToothCondition, ToothRecord } from '../../api/types';
import { useAuth } from '../../auth';
import { Card, ErrorBox, Field, Modal, Spinner, useAsync } from '../../components/ui';
import { fmtDateTime } from '../../sq';

export const conditions: { key: ToothCondition; label: string; color: string; symbol: string; surfaces: boolean }[] = [
  { key: 'Shendoshe', label: 'I shëndoshë', color: '#e5e7eb', symbol: '', surfaces: false },
  { key: 'Karies', label: 'Karies', color: '#dc2626', symbol: 'K', surfaces: true },
  { key: 'Mbushje', label: 'Mbushje', color: '#2563eb', symbol: 'M', surfaces: true },
  { key: 'Kanal', label: 'Trajtim kanali', color: '#9333ea', symbol: 'TK', surfaces: false },
  { key: 'Kurore', label: 'Kurorë', color: '#d97706', symbol: 'KR', surfaces: false },
  { key: 'Ure', label: 'Urë', color: '#ca8a04', symbol: 'U', surfaces: false },
  { key: 'Implant', label: 'Implant', color: '#0d9488', symbol: 'IM', surfaces: false },
  { key: 'Fraktura', label: 'Frakturë', color: '#ea580c', symbol: 'F', surfaces: true },
  { key: 'PerHeqje', label: "Për t'u hequr", color: '#be123c', symbol: '✕', surfaces: false },
  { key: 'Mungon', label: 'Mungon / i hequr', color: '#6b7280', symbol: '—', surfaces: false },
  { key: 'Tjeter', label: 'Tjetër', color: '#64748b', symbol: '?', surfaces: false },
];
const cond = (k: ToothCondition) => conditions.find(c => c.key === k) ?? conditions[0];

const ADULT_UP = [18, 17, 16, 15, 14, 13, 12, 11, 21, 22, 23, 24, 25, 26, 27, 28];
const ADULT_DOWN = [48, 47, 46, 45, 44, 43, 42, 41, 31, 32, 33, 34, 35, 36, 37, 38];
const CHILD_UP = [55, 54, 53, 52, 51, 61, 62, 63, 64, 65];
const CHILD_DOWN = [85, 84, 83, 82, 81, 71, 72, 73, 74, 75];

/**
 * Pozicioni i sipërfaqeve në figurë (pamje nga mjeku):
 * lart = bukale (sipër) / linguale (poshtë); mesiale = drejt vijës së mesit.
 */
function surfacePositions(tooth: number) {
  const q = Math.floor(tooth / 10);
  const upper = q === 1 || q === 2 || q === 5 || q === 6;
  const rightSide = q === 1 || q === 4 || q === 5 || q === 8; // ana e djathtë e pacientit = majtas në ekran
  return {
    top: upper ? 'B' : 'L', bottom: upper ? 'L' : 'B',
    left: rightSide ? 'D' : 'M', right: rightSide ? 'M' : 'D',
  } as Record<'top' | 'bottom' | 'left' | 'right', string>;
}

function ToothSvg({ tooth, rec }: { tooth: number; rec?: ToothRecord }) {
  const c = rec ? cond(rec.condition) : conditions[0];
  const pos = surfacePositions(tooth);
  const s = rec?.surfaces ?? '';
  const whole = rec && !c.surfaces && rec.condition !== 'Shendoshe';
  const fill = (letter: string) => (c.surfaces && s.includes(letter) ? c.color : whole ? c.color : '#fff');
  const op = whole ? 0.85 : 1;
  return (
    <svg viewBox="0 0 40 40" className="tooth-svg" aria-hidden>
      <polygon points="0,0 40,0 28,12 12,12" fill={fill(pos.top)} opacity={op} stroke="#94a3b8" />
      <polygon points="0,40 40,40 28,28 12,28" fill={fill(pos.bottom)} opacity={op} stroke="#94a3b8" />
      <polygon points="0,0 12,12 12,28 0,40" fill={fill(pos.left)} opacity={op} stroke="#94a3b8" />
      <polygon points="40,0 28,12 28,28 40,40" fill={fill(pos.right)} opacity={op} stroke="#94a3b8" />
      <rect x="12" y="12" width="16" height="16" fill={fill('O')} opacity={op} stroke="#94a3b8" />
      {rec?.condition === 'Mungon' && <line x1="2" y1="20" x2="38" y2="20" stroke="#111" strokeWidth="3" />}
      {rec?.condition === 'PerHeqje' && <><line x1="4" y1="4" x2="36" y2="36" stroke="#be123c" strokeWidth="3" /><line x1="36" y1="4" x2="4" y2="36" stroke="#be123c" strokeWidth="3" /></>}
      {rec?.condition === 'Kurore' && <circle cx="20" cy="20" r="17" fill="none" stroke="#92400e" strokeWidth="3" />}
      {rec?.condition === 'Implant' && <><line x1="20" y1="6" x2="20" y2="34" stroke="#134e4a" strokeWidth="3" /><line x1="13" y1="14" x2="27" y2="14" stroke="#134e4a" strokeWidth="2" /><line x1="13" y1="22" x2="27" y2="22" stroke="#134e4a" strokeWidth="2" /></>}
      {rec?.condition === 'Kanal' && <line x1="20" y1="4" x2="20" y2="36" stroke="#581c87" strokeWidth="3" />}
    </svg>
  );
}

/** Skeda "Odontogrami" në kartelën e pacientit. */
export default function Odontogram({ patientId }: { patientId: string }) {
  const { hasFeature } = useAuth();
  const [children, setChildren] = useState(false);
  const [edit, setEdit] = useState<number | null>(null);
  const teeth = useAsync(() => api.get<ToothRecord[]>(`/api/patients/${patientId}/teeth`), [patientId]);
  const files = useAsync(() => (hasFeature('imaging') ? api.get<PatientFile[]>(`/api/patients/${patientId}/files`) : Promise.resolve([] as PatientFile[])), [patientId]);
  const map = new Map((teeth.data ?? []).map(t => [t.tooth, t]));
  const xrays = (n: number) => (files.data ?? []).filter(f => (f.tooth ?? '').split(/[^0-9]+/).includes(String(n))).length;

  const counts = conditions.filter(c => c.key !== 'Shendoshe').map(c => ({ ...c, n: (teeth.data ?? []).filter(t => t.condition === c.key).length }));

  const row = (list: number[], upper: boolean) => (
    <div className={`teeth-row ${upper ? 'up' : 'down'}`}>
      {list.map((n, i) => {
        const rec = map.get(n);
        const x = xrays(n);
        return (
          <button key={n} className={`tooth ${rec ? 'has' : ''} ${i === list.length / 2 ? 'mid' : ''}`} onClick={() => setEdit(n)}
            title={rec ? `${n}: ${rec.conditionLabel}${rec.surfaces ? ` (${rec.surfaces})` : ''}${rec.notes ? ` – ${rec.notes}` : ''}` : `${n}: i shëndoshë`}>
            {upper && <span className="tooth-no">{n}</span>}
            <ToothSvg tooth={n} rec={rec} />
            {!upper && <span className="tooth-no">{n}</span>}
            {x > 0 && <span className="tooth-x" title={`${x} imazh(e)`}>📷{x}</span>}
          </button>
        );
      })}
    </div>
  );

  return (
    <Card title="Odontogrami" actions={<label className="check small"><input type="checkbox" checked={children} onChange={e => setChildren(e.target.checked)} /> Dhëmbët e qumështit</label>}>
      <ErrorBox error={teeth.error} />
      {teeth.loading ? <Spinner /> : (
        <>
          <div className="odonto">
            <div className="odonto-side"><span>Djathtas</span><span>Majtas</span></div>
            {row(ADULT_UP, true)}
            {children && row(CHILD_UP, true)}
            <div className="odonto-divider" />
            {children && row(CHILD_DOWN, false)}
            {row(ADULT_DOWN, false)}
          </div>
          <div className="odonto-legend">
            {counts.map(c => (
              <span key={c.key} className={c.n ? '' : 'dim'}><i style={{ background: c.color }} />{c.label}{c.n ? ` (${c.n})` : ''}</span>
            ))}
          </div>
          {(teeth.data?.length ?? 0) > 0 && (
            <table className="table compact" style={{ marginTop: 12 }}>
              <thead><tr><th>Dhëmbi</th><th>Gjendja</th><th>Sipërfaqet</th><th>Shënime</th><th>Ndryshuar</th></tr></thead>
              <tbody>
                {teeth.data!.map(t => (
                  <tr key={t.tooth} onClick={() => setEdit(t.tooth)} style={{ cursor: 'pointer' }}>
                    <td><b>{t.tooth}</b></td>
                    <td><span className="dot-c" style={{ background: cond(t.condition).color }} /> {t.conditionLabel}</td>
                    <td>{t.surfaces ?? '—'}</td><td className="small">{t.notes ?? ''}</td>
                    <td className="small muted">{fmtDateTime(t.updatedAt)}{t.updatedBy ? ` · ${t.updatedBy}` : ''}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
          <p className="small muted">Klikoni një dhëmb për të shënuar gjendjen. Numërimi FDI; pamja si nga mjeku (ana e djathtë e pacientit majtas).</p>
        </>
      )}
      {edit !== null && (
        <ToothModal patientId={patientId} tooth={edit} rec={map.get(edit)} onClose={() => setEdit(null)}
          onSaved={() => { setEdit(null); teeth.reload(); }} />
      )}
    </Card>
  );
}

function ToothModal({ patientId, tooth, rec, onClose, onSaved }:
  { patientId: string; tooth: number; rec?: ToothRecord; onClose: () => void; onSaved: () => void }) {
  const [condition, setCondition] = useState<ToothCondition>(rec?.condition ?? 'Karies');
  const [surfaces, setSurfaces] = useState(rec?.surfaces ?? '');
  const [notes, setNotes] = useState(rec?.notes ?? '');
  const [err, setErr] = useState<string | null>(null);
  const c = cond(condition);
  const pos = surfacePositions(tooth);
  const toggle = (l: string) => setSurfaces(s => (s.includes(l) ? s.replace(l, '') : s + l));

  const save = async (reset = false) => {
    try {
      await api.put(`/api/patients/${patientId}/teeth/${tooth}`, reset
        ? { condition: 'Shendoshe', surfaces: null, notes: null }
        : { condition, surfaces: c.surfaces ? surfaces : null, notes: notes || null });
      onSaved();
    } catch (e: any) { setErr(e.message); }
  };

  const surfaceName: Record<string, string> = { M: 'Meziale', O: 'Okluzale', D: 'Distale', B: 'Bukale', L: 'Linguale/Palatinale' };
  return (
    <Modal title={`Dhëmbi ${tooth}`} onClose={onClose}>
      <ErrorBox error={err} />
      <div className="cond-grid">
        {conditions.filter(x => x.key !== 'Shendoshe').map(x => (
          <button key={x.key} className={`cond ${condition === x.key ? 'on' : ''}`} onClick={() => setCondition(x.key)}>
            <i style={{ background: x.color }} />{x.label}
          </button>
        ))}
      </div>
      {c.surfaces && (
        <div className="surface-pick">
          <span className="small muted">Sipërfaqet:</span>
          <div className="surface-cross">
            <span />{(['top'] as const).map(k => <button key={k} className={surfaces.includes(pos[k]) ? 'on' : ''} onClick={() => toggle(pos[k])}>{pos[k]}</button>)}<span />
            <button className={surfaces.includes(pos.left) ? 'on' : ''} onClick={() => toggle(pos.left)}>{pos.left}</button>
            <button className={surfaces.includes('O') ? 'on' : ''} onClick={() => toggle('O')}>O</button>
            <button className={surfaces.includes(pos.right) ? 'on' : ''} onClick={() => toggle(pos.right)}>{pos.right}</button>
            <span /><button className={surfaces.includes(pos.bottom) ? 'on' : ''} onClick={() => toggle(pos.bottom)}>{pos.bottom}</button><span />
          </div>
          <span className="small muted">{surfaces.split('').map(l => surfaceName[l]).filter(Boolean).join(', ') || 'Asnjë e zgjedhur'}</span>
        </div>
      )}
      <Field label="Shënime" full><textarea rows={2} value={notes} onChange={e => setNotes(e.target.value)} placeholder="p.sh. karies i thellë, planifikuar mbushje" /></Field>
      {rec && <p className="small muted">Ndryshuar më {fmtDateTime(rec.updatedAt)}{rec.updatedBy ? ` nga ${rec.updatedBy}` : ''}</p>}
      <div className="modal-actions">
        {rec && <button className="btn ghost" onClick={() => save(true)}>Rikthe: i shëndoshë</button>}
        <span className="spacer" />
        <button className="btn ghost" onClick={onClose}>Anulo</button>
        <button className="btn primary" onClick={() => save()}>Ruaj</button>
      </div>
    </Modal>
  );
}

import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api, qs } from '../../api/client';
import type { Appointment, AppointmentStatus, Paged, Patient, ServiceItem, User } from '../../api/types';
import { useAuth } from '../../auth';
import { Badge, Card, Empty, ErrorBox, Field, Modal, Spinner, useAsync } from '../../components/ui';
import { fmtLongDate, fmtTime, statusLabels, toLocalInput } from '../../sq';
import CalendarView from './Calendar';
import ReminderModal from '../../components/ReminderModal';

const tone = (s: AppointmentStatus) =>
  s === 'Perfunduar' ? 'green' : s === 'Konfirmuar' ? 'blue' : s === 'Anuluar' || s === 'NukErdhi' ? 'red' : 'neutral';

export default function Appointments() {
  const { business, hasFeature } = useAuth();
  const [view, setView] = useState<'kalendar' | 'liste'>(() => { try { return (localStorage.getItem('klinika.apptView') as 'liste') || 'kalendar'; } catch { return 'kalendar'; } });
  const switchView = (v: 'kalendar' | 'liste') => { setView(v); try { localStorage.setItem('klinika.apptView', v); } catch { /* */ } };
  const [remind, setRemind] = useState<Appointment | null>(null);
  const [day, setDay] = useState(() => { const d = new Date(); d.setHours(0, 0, 0, 0); return d; });
  const [staffId, setStaffId] = useState('');
  const [modal, setModal] = useState<{ appt?: Appointment } | null>(null);
  const staff = useAsync(() => api.get<User[]>('/api/staff'));
  const end = new Date(day); end.setDate(end.getDate() + 1);
  const list = useAsync(() => api.get<Appointment[]>(`/api/appointments${qs({ from: day.toISOString(), to: end.toISOString(), staffId })}`), [day.getTime(), staffId]);
  const requests = useAsync(() => api.get<Appointment[]>(`/api/appointments${qs({
    from: new Date().toISOString(), to: new Date(Date.now() + 90 * 864e5).toISOString(), status: 'Planifikuar',
  })}`));
  const pending = requests.data?.filter(a => a.requestedByClient) ?? [];

  const shift = (n: number) => setDay(d => { const x = new Date(d); x.setDate(x.getDate() + n); return x; });
  const [actionErr, setActionErr] = useState<string | null>(null);
  const setStatus = async (a: Appointment, s: AppointmentStatus) => {
    setActionErr(null);
    try {
      await api.post(`/api/appointments/${a.id}/status`, { status: s });
    } catch (e: any) {
      setActionErr(`${a.patientName}: ${e.message}`);
    }
    list.reload(); requests.reload();
  };

  return (
    <div className="page">
      <div className="page-head">
        <h1>Terminet</h1>
        <button className="btn primary" onClick={() => setModal({})}>+ Termin i ri</button>
      </div>

      {actionErr && <div className="alert error">{actionErr}</div>}
      {pending.length > 0 && (
        <Card title={`Kërkesa nga aplikacioni (${pending.length})`} className="highlight">
          <table className="table">
            <tbody>
              {pending.map(a => (
                <tr key={a.id}>
                  <td><Link className="link" to={`/pacientet/${a.patientId}`}>{a.patientName}</Link><div className="muted small">{a.notes}</div></td>
                  <td>{new Date(a.startsAt).toLocaleDateString('sq-AL')} {fmtTime(a.startsAt)}</td>
                  <td>{a.serviceName ?? '—'}</td>
                  <td className="row gap">
                    <button className="btn primary small" onClick={() => setStatus(a, 'Konfirmuar')}>✓ Prano</button>
                    <button className="btn ghost small" onClick={() => setModal({ appt: a })}>Ndrysho orarin / stafin</button>
                    <button className="btn ghost small" onClick={() => setStatus(a, 'Anuluar')}>Refuzo</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      )}

      <div className="tabs">
        <button className={view === 'kalendar' ? 'on' : ''} onClick={() => switchView('kalendar')}>📅 Kalendari</button>
        <button className={view === 'liste' ? 'on' : ''} onClick={() => switchView('liste')}>☰ Lista</button>
      </div>
      {view === 'kalendar' && <Card><CalendarView onChanged={() => requests.reload()} /></Card>}
      {view === 'liste' && (
      <Card title={fmtLongDate(day)} actions={<>
        <select value={staffId} onChange={e => setStaffId(e.target.value)}>
          <option value="">I gjithë stafi</option>
          {staff.data?.map(s => <option key={s.id} value={s.id}>{s.fullName}</option>)}
        </select>
        <button className="btn ghost small" onClick={() => shift(-1)}>‹</button>
        <button className="btn ghost small" onClick={() => { const d = new Date(); d.setHours(0, 0, 0, 0); setDay(d); }}>Sot</button>
        <button className="btn ghost small" onClick={() => shift(1)}>›</button>
      </>}>
        <ErrorBox error={list.error} />
        {list.loading ? <Spinner /> : !list.data?.length ? <Empty>Nuk ka termine në këtë ditë.</Empty> : (
          <table className="table">
            <thead><tr><th>Ora</th><th>Pacienti</th><th>Shërbimi</th><th>{business?.doctorLabel ?? 'Stafi'}</th><th>Statusi</th><th /></tr></thead>
            <tbody>
              {list.data.map(a => (
                <tr key={a.id}>
                  <td><b>{fmtTime(a.startsAt)}</b><div className="muted small">{a.durationMinutes} min</div></td>
                  <td><Link className="link" to={`/pacientet/${a.patientId}`}>{a.patientName}</Link><div className="muted small">{a.patientPhone}</div></td>
                  <td>{a.serviceName ?? '—'}{a.notes && <div className="muted small">{a.notes}</div>}</td>
                  <td>{a.staffName ?? '—'}</td>
                  <td>
                    <select className={`status ${tone(a.status)}`} value={a.status} onChange={e => setStatus(a, e.target.value as AppointmentStatus)}>
                      {Object.entries(statusLabels).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
                    </select>
                  </td>
                  <td className="row gap">
                    {hasFeature('reminders') && <button className="btn ghost small" title={a.reminderSentAt ? 'Kujtesa u dërgua' : 'Dërgo kujtesë'} onClick={() => setRemind(a)}>{a.reminderSentAt ? '🔔✓' : '🔔'}</button>}
                    <button className="btn ghost small" onClick={() => setModal({ appt: a })}>Ndrysho</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </Card>
      )}
      {remind && <ReminderModal appt={remind} onClose={() => setRemind(null)} onSent={() => list.reload()} />}
      {modal && <AppointmentModal appt={modal.appt} defaultDate={day} onClose={() => setModal(null)} onSaved={() => { setModal(null); list.reload(); requests.reload(); }} />}
    </div>
  );
}

export function AppointmentModal({ appt, patient, defaultDate, defaultStart, defaultStaffId, onClose, onSaved }:
  { appt?: Appointment; patient?: Patient; defaultDate?: Date; defaultStart?: Date; defaultStaffId?: string; onClose: () => void; onSaved: () => void }) {
  const staff = useAsync(() => api.get<User[]>('/api/staff'));
  const services = useAsync(() => api.get<ServiceItem[]>('/api/services'));
  const start = appt ? new Date(appt.startsAt) : defaultStart ? new Date(defaultStart) : (() => { const d = new Date(defaultDate ?? new Date()); d.setHours(Math.max(8, new Date().getHours() + 1), 0, 0, 0); return d; })();

  const [patientId, setPatientId] = useState(appt?.patientId ?? patient?.id ?? '');
  const [patientName, setPatientName] = useState(appt?.patientName ?? patient?.fullName ?? '');
  const [search, setSearch] = useState('');
  const [results, setResults] = useState<Patient[]>([]);
  const [f, setF] = useState({
    staffId: appt?.staffId ?? defaultStaffId ?? '', serviceItemId: appt?.serviceItemId ?? '', startsAt: toLocalInput(start),
    durationMinutes: String(appt?.durationMinutes ?? 30), notes: appt?.notes ?? '',
    status: (appt?.status === 'Planifikuar' && appt.requestedByClient ? 'Konfirmuar' : appt?.status ?? 'Planifikuar') as AppointmentStatus,
  });
  const [err, setErr] = useState<string | null>(null);

  const [searched, setSearched] = useState(false);
  const [creating, setCreating] = useState(false);
  useEffect(() => {
    setSearched(false);
    if (search.trim().length < 2) { setResults([]); return; }
    const t = setTimeout(() => api.get<Paged<Patient>>(`/api/patients${qs({ q: search.trim(), pageSize: 8 })}`)
      .then(r => { setResults(r.items); setSearched(true); }), 250);
    return () => clearTimeout(t);
  }, [search]);

  const pick = (p: Patient) => { setPatientId(p.id); setPatientName(p.fullName); setResults([]); setSearch(''); };

  /** Krijo shpejt pacientin nga emri i shkruar (p.sh. "Enes Mustafa"), pa dalë nga dritarja e terminit. */
  const quickCreate = async () => {
    const parts = search.trim().split(/\s+/);
    const firstName = parts[0];
    const lastName = parts.slice(1).join(' ') || '-';
    setCreating(true); setErr(null);
    try { pick(await api.post<Patient>('/api/patients', { firstName, lastName })); }
    catch (e: any) { setErr(e.message); }
    finally { setCreating(false); }
  };

  const pickService = (id: string) => {
    const s = services.data?.find(x => x.id === id);
    setF(v => ({ ...v, serviceItemId: id, durationMinutes: s ? String(s.durationMinutes) : v.durationMinutes }));
  };

  const go = async () => {
    const body = {
      patientId, staffId: f.staffId || null, serviceItemId: f.serviceItemId || null, startsAt: new Date(f.startsAt).toISOString(),
      durationMinutes: +f.durationMinutes || 30, status: f.status, notes: f.notes || null,
    };
    try {
      if (appt) await api.put(`/api/appointments/${appt.id}`, body); else await api.post('/api/appointments', body);
      onSaved();
    } catch (e: any) { setErr(e.message); }
  };
  const remove = async () => {
    if (!appt || !confirm('Të fshihet termini?')) return;
    await api.del(`/api/appointments/${appt.id}`); onSaved();
  };

  return (
    <Modal title={appt ? 'Ndrysho terminin' : 'Termin i ri'} onClose={onClose}>
      <ErrorBox error={err} />
      <div className="form-grid">
        <Field label="Pacienti *" full>
          {patientId ? (
            <div className="row gap picked">✓ <Link className="link" to={`/pacientet/${patientId}`} title="Hap kartelën e pacientit"><b>{patientName}</b></Link>{!appt && !patient && <button type="button" className="btn ghost small" onClick={() => { setPatientId(''); setPatientName(''); }}>Ndrysho</button>}</div>
          ) : (
            <div className="autocomplete">
              <input placeholder="Shkruaj emrin ose telefonin…" value={search} onChange={e => setSearch(e.target.value)} autoFocus
                autoComplete="off" name="kerko-pacient" spellCheck={false}
                onKeyDown={e => { if (e.key === 'Enter' && results.length > 0) { e.preventDefault(); pick(results[0]); } }} />
              {results.length > 0 && (
                <div className="pick-list">
                  {results.map(p => (
                    <button type="button" key={p.id} className="pick-item" onMouseDown={e => { e.preventDefault(); pick(p); }}>
                      <span><b>{p.fullName}</b>{(p.phone || p.age != null) && <span className="muted small"> · {[p.age != null ? `${p.age} vjeç` : null, p.phone].filter(Boolean).join(' · ')}</span>}</span>
                      <span className="pick-btn">Zgjidh ✓</span>
                    </button>
                  ))}
                </div>
              )}
              {search.trim().length >= 2 && (
                <div className="small muted" style={{ marginTop: 6 }}>
                  {results.length > 0 ? '👆 Klikoni "Zgjidh ✓" te pacienti (ose shtypni Enter për të parin).' : searched && (
                    <span className="row gap">Nuk u gjet asnjë pacient me "{search.trim()}".
                      <button type="button" className="btn primary small" disabled={creating} onClick={quickCreate}>
                        {creating ? 'Duke krijuar…' : `+ Krijo pacientin "${search.trim()}"`}
                      </button>
                    </span>
                  )}
                </div>
              )}
            </div>
          )}
        </Field>
        <Field label="Shërbimi">
          <select value={f.serviceItemId} onChange={e => pickService(e.target.value)}>
            <option value="">—</option>{services.data?.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
          </select>
        </Field>
        <Field label="Stafi">
          <select value={f.staffId} onChange={e => setF({ ...f, staffId: e.target.value })}>
            <option value="">—</option>{staff.data?.map(s => <option key={s.id} value={s.id}>{s.fullName}</option>)}
          </select>
        </Field>
        <Field label="Data dhe ora *"><input type="datetime-local" value={f.startsAt} onChange={e => setF({ ...f, startsAt: e.target.value })} /></Field>
        <Field label="Kohëzgjatja (min)"><input type="number" min={5} step={5} value={f.durationMinutes} onChange={e => setF({ ...f, durationMinutes: e.target.value })} /></Field>
        <Field label="Statusi">
          <select value={f.status} onChange={e => setF({ ...f, status: e.target.value as AppointmentStatus })}>
            {Object.entries(statusLabels).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
          </select>
        </Field>
        <Field label="Shënime" full><input value={f.notes} onChange={e => setF({ ...f, notes: e.target.value })} /></Field>
      </div>
      <div className="modal-actions">
        {appt && <button className="btn danger ghost" onClick={remove}>Fshi</button>}
        <span className="spacer" />
        <button className="btn ghost" onClick={onClose}>Anulo</button>
        <button className="btn primary" disabled={!patientId} onClick={go} title={!patientId ? 'Zgjidhni pacientin nga lista' : undefined}>Ruaj</button>
      </div>
      {!patientId && <p className="small" style={{ color: 'var(--amber)' }}>⚠ Për të ruajtur, zgjidhni pacientin nga lista (ose krijojeni me butonin "+ Krijo pacientin").</p>}
      {appt?.requestedByClient && <p className="muted small"><Badge tone="blue">App</Badge> Kërkuar nga klienti përmes aplikacionit.</p>}
    </Modal>
  );
}

import { useState } from 'react';
import { api } from '../../api/client';
import type { ServiceItem } from '../../api/types';
import { useAuth } from '../../auth';
import { Badge, Card, Empty, ErrorBox, Field, Modal, Spinner, useAsync } from '../../components/ui';
import { fmtMoney } from '../../sq';

export default function Services() {
  const { business, hasRole } = useAuth();
  const isAdmin = hasRole('Admin');
  const list = useAsync(() => api.get<ServiceItem[]>(`/api/services?includeInactive=${isAdmin}`));
  const [edit, setEdit] = useState<{ s?: ServiceItem } | null>(null);
  const [msg, setMsg] = useState<string | null>(null);

  const importDefaults = async () => {
    const r = await api.post<{ message: string }>('/api/services/import-defaults');
    setMsg(r.message); list.reload();
  };

  const groups = (list.data ?? []).reduce<Record<string, ServiceItem[]>>((g, s) => {
    const k = s.category || 'Të tjera'; (g[k] ??= []).push(s); return g;
  }, {});

  return (
    <div className="page">
      <div className="page-head">
        <h1>Shërbimet dhe çmimet</h1>
        {isAdmin && <div className="row gap">
          <button className="btn ghost" onClick={importDefaults}>Shto shërbimet standarde ({business?.specialtyLabel})</button>
          <button className="btn primary" onClick={() => setEdit({})}>+ Shërbim</button>
        </div>}
      </div>
      {msg && <div className="alert success">{msg}</div>}
      <ErrorBox error={list.error} />
      {list.loading ? <Spinner /> : !list.data?.length ? <Empty>Nuk ka shërbime.</Empty> : Object.entries(groups).map(([cat, items]) => (
        <Card key={cat} title={cat}>
          <table className="table">
            <thead><tr><th>Shërbimi</th><th className="num">Kohëzgjatja</th><th className="num">Çmimi</th><th /></tr></thead>
            <tbody>
              {items.map(s => (
                <tr key={s.id} className={s.isActive ? '' : 'dim'}>
                  <td>{s.name} {!s.isActive && <Badge tone="red">Joaktiv</Badge>}</td>
                  <td className="num">{s.durationMinutes} min</td>
                  <td className="num"><b>{fmtMoney(s.price, business?.currency)}</b></td>
                  <td>{isAdmin && <button className="btn ghost small" onClick={() => setEdit({ s })}>Ndrysho</button>}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      ))}
      {edit && <ServiceModal s={edit.s} onClose={() => setEdit(null)} onDone={() => { setEdit(null); list.reload(); }} />}
    </div>
  );
}

function ServiceModal({ s, onClose, onDone }: { s?: ServiceItem; onClose: () => void; onDone: () => void }) {
  const [f, setF] = useState({ name: s?.name ?? '', category: s?.category ?? '', price: String(s?.price ?? ''), durationMinutes: String(s?.durationMinutes ?? 30), isActive: s?.isActive ?? true });
  const [err, setErr] = useState<string | null>(null);
  const go = async () => {
    const body = { ...f, category: f.category || null, price: +f.price, durationMinutes: +f.durationMinutes };
    try { if (s) await api.put(`/api/services/${s.id}`, body); else await api.post('/api/services', body); onDone(); }
    catch (e: any) { setErr(e.message); }
  };
  return (
    <Modal title={s ? 'Ndrysho shërbimin' : 'Shërbim i ri'} onClose={onClose}>
      <ErrorBox error={err} />
      <div className="form-grid">
        <Field label="Emri *" full><input value={f.name} onChange={e => setF({ ...f, name: e.target.value })} /></Field>
        <Field label="Kategoria"><input value={f.category} onChange={e => setF({ ...f, category: e.target.value })} placeholder="p.sh. Konsultë" /></Field>
        <Field label="Çmimi *"><input type="number" min={0} step="any" value={f.price} onChange={e => setF({ ...f, price: e.target.value })} /></Field>
        <Field label="Kohëzgjatja (min)"><input type="number" min={5} step={5} value={f.durationMinutes} onChange={e => setF({ ...f, durationMinutes: e.target.value })} /></Field>
        <label className="check"><input type="checkbox" checked={f.isActive} onChange={e => setF({ ...f, isActive: e.target.checked })} /> Aktiv</label>
      </div>
      <div className="modal-actions"><button className="btn ghost" onClick={onClose}>Anulo</button><button className="btn primary" disabled={!f.name || f.price === ''} onClick={go}>Ruaj</button></div>
    </Modal>
  );
}

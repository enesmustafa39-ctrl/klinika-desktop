import { useState, type FormEvent } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { api, qs } from '../../api/client';
import type { Paged, Patient, PatientInput } from '../../api/types';
import { useAuth } from '../../auth';
import { Badge, Card, Empty, ErrorBox, Field, Modal, Spinner, clean, useAsync, useForm } from '../../components/ui';
import { fmtDate, fmtMoney, genderLabels } from '../../sq';

export default function Patients() {
  const nav = useNavigate();
  const { business } = useAuth();
  const [params, setParams] = useSearchParams();
  const [q, setQ] = useState('');
  const [debtorsOnly, setDebtorsOnly] = useState(false);
  const [archived, setArchived] = useState(false);
  const [page, setPage] = useState(1);
  const creating = params.get('i-ri') === '1';

  const list = useAsync(() => api.get<Paged<Patient>>(`/api/patients${qs({ q, debtorsOnly, archived, page, pageSize: 25 })}`),
    [q, debtorsOnly, archived, page]);
  const pages = list.data ? Math.max(1, Math.ceil(list.data.total / list.data.pageSize)) : 1;

  return (
    <div className="page">
      <div className="page-head">
        <h1>Pacientët</h1>
        <button className="btn primary" onClick={() => setParams({ 'i-ri': '1' })}>+ Pacient i ri</button>
      </div>
      <Card>
        <div className="toolbar">
          <input className="search" placeholder="Kërko me emër, telefon ose nr. personal…" value={q} onChange={e => { setQ(e.target.value); setPage(1); }} />
          <label className="check"><input type="checkbox" checked={debtorsOnly} onChange={e => { setDebtorsOnly(e.target.checked); setPage(1); }} /> Vetëm me borxh</label>
          <label className="check"><input type="checkbox" checked={archived} onChange={e => { setArchived(e.target.checked); setPage(1); }} /> Të arkivuar</label>
        </div>
        <ErrorBox error={list.error} />
        {list.loading ? <Spinner /> : !list.data?.items.length ? <Empty>Nuk u gjet asnjë pacient.</Empty> : (
          <>
            <table className="table hover">
              <thead><tr><th>Pacienti</th><th>Mosha</th><th>Telefoni</th><th>Vizita e fundit</th><th className="num">Balanca</th><th /></tr></thead>
              <tbody>
                {list.data.items.map(p => (
                  <tr key={p.id} onClick={() => nav(`/pacientet/${p.id}`)}>
                    <td><b>{p.fullName}</b>{p.personalNumber && <div className="muted small">{p.personalNumber}</div>}</td>
                    <td>{p.age ?? '—'}{p.gender && <span className="muted"> · {genderLabels[p.gender]}</span>}</td>
                    <td>{p.phone ?? '—'}</td>
                    <td>{fmtDate(p.lastVisit)}</td>
                    <td className={`num ${p.balance > 0 ? 'red' : p.balance < 0 ? 'green' : ''}`}>{fmtMoney(p.balance, business?.currency)}</td>
                    <td>{p.allergies && <Badge tone="amber">Alergji</Badge>} {p.hasPortalAccess && <Badge tone="blue">App</Badge>}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            <div className="pager">
              <span className="muted">{list.data.total} pacientë</span>
              <button className="btn ghost small" disabled={page <= 1} onClick={() => setPage(p => p - 1)}>‹ Para</button>
              <span>{page} / {pages}</span>
              <button className="btn ghost small" disabled={page >= pages} onClick={() => setPage(p => p + 1)}>Pas ›</button>
            </div>
          </>
        )}
      </Card>
      {creating && <PatientModal onClose={() => setParams({})} onSaved={p => nav(`/pacientet/${p.id}`)} />}
    </div>
  );
}

const emptyPatient: Record<keyof PatientInput, string> = {
  firstName: '', lastName: '', personalNumber: '', birthDate: '', gender: '', phone: '', email: '', address: '',
  bloodType: '', allergies: '', chronicConditions: '', notes: '',
};

export function PatientModal({ patient, onClose, onSaved }: { patient?: Patient; onClose: () => void; onSaved: (p: Patient) => void }) {
  const init = patient ? Object.fromEntries(Object.keys(emptyPatient).map(k => [k, (patient as any)[k] ?? ''])) as typeof emptyPatient : emptyPatient;
  const { values, bind } = useForm(init);
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true); setErr(null);
    try {
      const body = clean(values);
      const p = patient ? await api.put<Patient>(`/api/patients/${patient.id}`, body) : await api.post<Patient>('/api/patients', body);
      onSaved(p);
    } catch (e: any) { setErr(e.message); } finally { setBusy(false); }
  };

  return (
    <Modal title={patient ? 'Ndrysho pacientin' : 'Pacient i ri'} onClose={onClose} wide>
      <form className="form-grid" onSubmit={submit}>
        {err && <div className="alert error full">{err}</div>}
        <Field label="Emri *"><input {...bind('firstName')} required autoFocus /></Field>
        <Field label="Mbiemri *"><input {...bind('lastName')} required /></Field>
        <Field label="Nr. personal"><input {...bind('personalNumber')} /></Field>
        <Field label="Datëlindja"><input type="date" {...bind('birthDate')} /></Field>
        <Field label="Gjinia">
          <select {...bind('gender')}><option value="">—</option>{Object.entries(genderLabels).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select>
        </Field>
        <Field label="Grupi i gjakut">
          <select {...bind('bloodType')}><option value="">—</option>{['0+', '0-', 'A+', 'A-', 'B+', 'B-', 'AB+', 'AB-'].map(b => <option key={b}>{b}</option>)}</select>
        </Field>
        <Field label="Telefoni"><input {...bind('phone')} /></Field>
        <Field label="Email"><input type="email" {...bind('email')} /></Field>
        <Field label="Adresa" full><input {...bind('address')} /></Field>
        <Field label="Alergjitë"><textarea rows={2} {...bind('allergies')} /></Field>
        <Field label="Sëmundjet kronike"><textarea rows={2} {...bind('chronicConditions')} /></Field>
        <Field label="Shënime" full><textarea rows={2} {...bind('notes')} /></Field>
        <div className="modal-actions full"><button type="button" className="btn ghost" onClick={onClose}>Anulo</button><button className="btn primary" disabled={busy}>Ruaj</button></div>
      </form>
    </Modal>
  );
}

import { useState, type FormEvent } from 'react';
import { api } from '../../api/client';
import type { FieldDef, ServiceItem, User, Visit } from '../../api/types';
import { useAuth } from '../../auth';
import { Field, Modal, clean, useAsync } from '../../components/ui';
import { fmtMoney, toLocalInput } from '../../sq';

interface Line { serviceItemId: string; description: string; quantity: number; unitPrice: number; discount: number }

/** Formulari i vizitës: fushat e përgjithshme + fushat specifike të specialitetit + shërbimet e kryera (ngarkesat). */
export default function VisitForm({ patientId, visit, onClose, onSaved }:
  { patientId: string; visit?: Visit; onClose: () => void; onSaved: () => void }) {
  const { user, business } = useAuth();
  const meta = useAsync(() => Promise.all([
    api.get<{ visitFields: FieldDef[] }>('/api/business'),
    api.get<ServiceItem[]>('/api/services'),
    api.get<User[]>('/api/staff'),
  ]));
  const [fieldsDef, services, staff] = meta.data ?? [{ visitFields: [] }, [], []];

  const [v, setV] = useState({
    visitDate: toLocalInput(visit ? new Date(visit.visitDate) : new Date()),
    doctorId: visit?.doctorId ?? (user?.role === 'Mjek' || user?.role === 'Admin' ? user.id : ''),
    complaint: visit?.complaint ?? '', diagnosis: visit?.diagnosis ?? '', treatment: visit?.treatment ?? '',
    prescription: visit?.prescription ?? '', notes: visit?.notes ?? '', nextVisitDate: visit?.nextVisitDate ?? '',
  });
  const [fields, setFields] = useState<Record<string, string | null>>(visit?.fields ?? {});
  const [lines, setLines] = useState<Line[]>([]);
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const bind = (k: keyof typeof v) => ({ value: v[k], onChange: (e: { target: { value: string } }) => setV(s => ({ ...s, [k]: e.target.value })) });

  const addLine = (sid: string) => {
    const s = services.find(x => x.id === sid);
    if (!s) return;
    setLines(l => [...l, { serviceItemId: s.id, description: s.name, quantity: 1, unitPrice: s.price, discount: 0 }]);
  };
  const upd = (i: number, patch: Partial<Line>) => setLines(l => l.map((x, j) => (j === i ? { ...x, ...patch } : x)));
  const total = lines.reduce((s, l) => s + Math.max(0, l.quantity * l.unitPrice - l.discount), 0);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true); setErr(null);
    const body = {
      ...clean(v), patientId, visitDate: new Date(v.visitDate).toISOString(), fields,
      charges: visit ? undefined : lines.map(l => ({ ...l, serviceItemId: l.serviceItemId || null })),
    };
    try {
      if (visit) await api.put(`/api/visits/${visit.id}`, body); else await api.post('/api/visits', body);
      onSaved();
    } catch (e: any) { setErr(e.message); } finally { setBusy(false); }
  };

  return (
    <Modal title={visit ? 'Ndrysho vizitën' : 'Vizitë e re'} onClose={onClose} wide>
      <form className="form-grid" onSubmit={submit}>
        {err && <div className="alert error full">{err}</div>}
        <Field label="Data dhe ora"><input type="datetime-local" {...bind('visitDate')} required /></Field>
        <Field label={business?.doctorLabel ?? 'Mjeku'}>
          <select {...bind('doctorId')}><option value="">—</option>{staff.filter(s => s.role === 'Mjek' || s.role === 'Admin').map(s => <option key={s.id} value={s.id}>{s.fullName}</option>)}</select>
        </Field>
        <Field label="Ankesa" full><textarea rows={2} {...bind('complaint')} /></Field>

        {fieldsDef.visitFields.length > 0 && (
          <fieldset className="full spec-fields">
            <legend>{business?.specialtyLabel}</legend>
            <div className="form-grid">
              {fieldsDef.visitFields.map(f => (
                <Field key={f.key} label={f.label}>
                  {f.type === 'select'
                    ? <select value={fields[f.key] ?? ''} onChange={e => setFields(s => ({ ...s, [f.key]: e.target.value }))}><option value="">—</option>{f.options?.map(o => <option key={o}>{o}</option>)}</select>
                    : <input type={f.type === 'number' ? 'number' : f.type === 'date' ? 'date' : 'text'} step="any" value={fields[f.key] ?? ''} onChange={e => setFields(s => ({ ...s, [f.key]: e.target.value }))} />}
                </Field>
              ))}
            </div>
          </fieldset>
        )}

        <Field label="Diagnoza" full><textarea rows={2} {...bind('diagnosis')} /></Field>
        <Field label="Trajtimi"><textarea rows={3} {...bind('treatment')} /></Field>
        <Field label="Receta / Terapia"><textarea rows={3} {...bind('prescription')} /></Field>
        <Field label="Shënime të brendshme (nuk i sheh klienti)"><textarea rows={2} {...bind('notes')} /></Field>
        <Field label="Vizita e radhës"><input type="date" {...bind('nextVisitDate')} /></Field>

        {!visit && (
          <fieldset className="full">
            <legend>Shërbimet e kryera (shtohen në llogarinë e pacientit)</legend>
            <select value="" onChange={e => addLine(e.target.value)}>
              <option value="">+ Shto shërbim…</option>
              {services.map(s => <option key={s.id} value={s.id}>{s.name} — {fmtMoney(s.price, business?.currency)}</option>)}
            </select>
            {lines.length > 0 && (
              <table className="table compact">
                <thead><tr><th>Shërbimi</th><th>Sasia</th><th>Çmimi</th><th>Zbritje</th><th className="num">Totali</th><th /></tr></thead>
                <tbody>
                  {lines.map((l, i) => (
                    <tr key={i}>
                      <td><input value={l.description} onChange={e => upd(i, { description: e.target.value })} /></td>
                      <td><input type="number" min={1} step="any" value={l.quantity} onChange={e => upd(i, { quantity: +e.target.value })} className="w-sm" /></td>
                      <td><input type="number" min={0} step="any" value={l.unitPrice} onChange={e => upd(i, { unitPrice: +e.target.value })} className="w-sm" /></td>
                      <td><input type="number" min={0} step="any" value={l.discount} onChange={e => upd(i, { discount: +e.target.value })} className="w-sm" /></td>
                      <td className="num">{fmtMoney(Math.max(0, l.quantity * l.unitPrice - l.discount), business?.currency)}</td>
                      <td><button type="button" className="icon-btn" onClick={() => setLines(x => x.filter((_, j) => j !== i))}>✕</button></td>
                    </tr>
                  ))}
                  <tr><td colSpan={4} className="num"><b>Gjithsej</b></td><td className="num"><b>{fmtMoney(total, business?.currency)}</b></td><td /></tr>
                </tbody>
              </table>
            )}
          </fieldset>
        )}

        <div className="modal-actions full"><button type="button" className="btn ghost" onClick={onClose}>Anulo</button><button className="btn primary" disabled={busy}>{busy ? 'Duke ruajtur…' : 'Ruaj vizitën'}</button></div>
      </form>
    </Modal>
  );
}

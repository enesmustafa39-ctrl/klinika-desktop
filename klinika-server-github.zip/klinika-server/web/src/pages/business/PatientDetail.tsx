import { Fragment, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { api } from '../../api/client';
import type { Appointment, FieldDef, Patient, Statement, Visit } from '../../api/types';
import { useAuth } from '../../auth';
import { Badge, Card, Empty, ErrorBox, Field, Modal, Spinner, useAsync } from '../../components/ui';
import { fmtDate, fmtDateTime, fmtMoney, genderLabels } from '../../sq';
import { PatientModal } from './Patients';
import VisitForm from './VisitForm';
import { ChargeModal, PaymentModal } from './Finance';
import { AppointmentModal } from './Appointments';
import ImagingTab from './Imaging';
import Odontogram from './Odontogram';
import PlansTab from './Plans';

type Tab = 'historiku' | 'odontogrami' | 'imazhet' | 'planet' | 'financat' | 'terminet' | 'te-dhenat';

export default function PatientDetail() {
  const { id = '' } = useParams();
  const { hasRole, hasFeature, business } = useAuth();
  const clinical = hasRole('Admin', 'Mjek', 'Infermier');
  const finance = hasRole('Admin', 'Recepsion', 'Mjek');
  const imaging = clinical && hasFeature('imaging');
  const odonto = clinical && hasFeature('odontogram');
  const plansOn = hasFeature('treatment_plans');
  const [tab, setTab] = useState<Tab>(clinical ? 'historiku' : 'financat');
  const [edit, setEdit] = useState(false);
  const [portal, setPortal] = useState(false);
  const p = useAsync(() => api.get<Patient>(`/api/patients/${id}`), [id]);

  if (p.loading && !p.data) return <Spinner />;
  if (!p.data) return <ErrorBox error={p.error} />;
  const pt = p.data;
  const cur = business?.currency;

  const archive = async () => {
    await api.post(`/api/patients/${id}/archive?archived=${!pt.isArchived}`);
    p.reload();
  };

  return (
    <div className="page">
      <div className="page-head">
        <div>
          <Link to="/pacientet" className="link small">← Pacientët</Link>
          <h1>{pt.fullName} {pt.isArchived && <Badge tone="red">Arkivuar</Badge>}</h1>
          <div className="muted">
            {[pt.age != null && `${pt.age} vjeç`, pt.gender && genderLabels[pt.gender], pt.phone, pt.personalNumber].filter(Boolean).join(' · ')}
          </div>
        </div>
        <div className="row gap">
          {finance && <div className={`balance-pill ${pt.balance > 0 ? 'red' : 'green'}`}>{pt.balance > 0 ? 'Borxh' : 'Balanca'}: <b>{fmtMoney(pt.balance, cur)}</b></div>}
          <button className="btn ghost" onClick={() => setEdit(true)}>Ndrysho</button>
        </div>
      </div>

      {(pt.allergies || pt.chronicConditions) && (
        <div className="alert warn">
          {pt.allergies && <div><b>Alergji:</b> {pt.allergies}</div>}
          {pt.chronicConditions && <div><b>Sëmundje kronike:</b> {pt.chronicConditions}</div>}
        </div>
      )}

      <div className="tabs">
        {clinical && <button className={tab === 'historiku' ? 'on' : ''} onClick={() => setTab('historiku')}>Historiku mjekësor</button>}
        {odonto && <button className={tab === 'odontogrami' ? 'on' : ''} onClick={() => setTab('odontogrami')}>🦷 Odontogrami</button>}
        {imaging && <button className={tab === 'imazhet' ? 'on' : ''} onClick={() => setTab('imazhet')}>{business?.specialty === 'Stomatologji' ? 'Rrezet X (Rëntgen)' : 'Imazhet'}</button>}
        {plansOn && <button className={tab === 'planet' ? 'on' : ''} onClick={() => setTab('planet')}>Planet e trajtimit</button>}
        {finance && <button className={tab === 'financat' ? 'on' : ''} onClick={() => setTab('financat')}>Financat</button>}
        <button className={tab === 'terminet' ? 'on' : ''} onClick={() => setTab('terminet')}>Terminet</button>
        <button className={tab === 'te-dhenat' ? 'on' : ''} onClick={() => setTab('te-dhenat')}>Të dhënat</button>
      </div>

      {tab === 'historiku' && <HistoryTab patientId={id} />}
      {tab === 'imazhet' && imaging && <ImagingTab patientId={id} />}
      {tab === 'odontogrami' && odonto && <Odontogram patientId={id} />}
      {tab === 'planet' && plansOn && <PlansTab patientId={id} onChange={p.reload} />}
      {tab === 'financat' && <FinanceTab patientId={id} onChange={p.reload} />}
      {tab === 'terminet' && <AppointmentsTab patient={pt} />}
      {tab === 'te-dhenat' && (
        <div className="grid-2">
          <Card title="Të dhënat personale">
            <dl className="dl">
              <dt>Datëlindja</dt><dd>{fmtDate(pt.birthDate)}</dd>
              <dt>Grupi i gjakut</dt><dd>{pt.bloodType ?? '—'}</dd>
              <dt>Telefoni</dt><dd>{pt.phone ?? '—'}</dd>
              <dt>Email</dt><dd>{pt.email ?? '—'}</dd>
              <dt>Adresa</dt><dd>{pt.address ?? '—'}</dd>
              <dt>Regjistruar</dt><dd>{fmtDate(pt.createdAt)}</dd>
              <dt>Shënime</dt><dd>{pt.notes ?? '—'}</dd>
            </dl>
          </Card>
          <Card title="Aplikacioni mobil i klientit">
            {!hasFeature('client_portal') ? <p className="muted">Aplikacioni i klientit nuk është i aktivizuar për klinikën tuaj. Kontaktoni ofruesin e platformës.</p> : <p>{pt.hasPortalAccess
              ? <><Badge tone="green">Aktiv</Badge> Pacienti mund të shohë historikun, borxhin dhe terminet nga telefoni.</>
              : 'Pacienti nuk ka ende qasje në aplikacionin mobil.'}</p>}
            {hasRole('Admin', 'Recepsion') && hasFeature('client_portal') && (
              <div className="row gap">
                <button className="btn primary" onClick={() => setPortal(true)}>{pt.hasPortalAccess ? 'Ndrysho fjalëkalimin' : 'Jep qasje në aplikacion'}</button>
                {pt.hasPortalAccess && <button className="btn ghost" onClick={async () => { await api.del(`/api/patients/${id}/portal-access`); p.reload(); }}>Hiq qasjen</button>}
              </div>
            )}
            <hr />
            <button className="btn ghost" onClick={archive}>{pt.isArchived ? 'Rikthe nga arkivi' : 'Arkivo pacientin'}</button>
          </Card>
        </div>
      )}

      {edit && <PatientModal patient={pt} onClose={() => setEdit(false)} onSaved={() => { setEdit(false); p.reload(); }} />}
      {portal && <PortalModal patient={pt} onClose={() => setPortal(false)} onDone={() => { setPortal(false); p.reload(); }} />}
    </div>
  );
}

function HistoryTab({ patientId }: { patientId: string }) {
  const { business, hasRole } = useAuth();
  const nav = useNavigate();
  const visits = useAsync(() => api.get<Visit[]>(`/api/visits?patientId=${patientId}`), [patientId]);
  const meta = useAsync(() => api.get<{ visitFields: FieldDef[] }>('/api/business'));
  const [form, setForm] = useState<{ visit?: Visit } | null>(null);
  const labels = Object.fromEntries((meta.data?.visitFields ?? []).map(f => [f.key, f.label]));

  const del = async (v: Visit) => {
    if (!confirm('Të fshihet kjo vizitë? Ngarkesat financiare mbeten.')) return;
    await api.del(`/api/visits/${v.id}`); visits.reload();
  };

  return (
    <Card title="Historiku i vizitave" actions={<button className="btn primary" onClick={() => setForm({})}>+ Vizitë e re</button>}>
      <ErrorBox error={visits.error} />
      {visits.loading ? <Spinner /> : !visits.data?.length ? <Empty>Nuk ka vizita të regjistruara.</Empty> : (
        <div className="visits">
          {visits.data.map(v => (
            <article key={v.id} className="visit">
              <header>
                <div><b>{fmtDateTime(v.visitDate)}</b><span className="muted"> · {v.doctorName ?? '—'}</span></div>
                <div className="row gap">
                  {v.chargedAmount > 0 && <Badge>{fmtMoney(v.chargedAmount, business?.currency)}</Badge>}
                  {v.prescription && <button className="btn ghost small" onClick={() => nav(`/printo/recete/${v.id}`)}>🖨 Recetë</button>}
                  {v.chargedAmount > 0 && hasRole('Admin', 'Mjek') && <button className="btn ghost small" onClick={() => nav(`/printo/fature/${patientId}?visit=${v.id}`)}>🖨 Faturë</button>}
                  <button className="btn ghost small" onClick={() => setForm({ visit: v })}>Ndrysho</button>
                  {hasRole('Admin', 'Mjek') && <button className="btn ghost small" onClick={() => del(v)}>Fshi</button>}
                </div>
              </header>
              <dl className="dl compact">
                {v.complaint && <><dt>Ankesa</dt><dd>{v.complaint}</dd></>}
                {Object.entries(v.fields).filter(([, val]) => val).map(([k, val]) => <Fragment key={k}><dt>{labels[k] ?? k}</dt><dd>{val}</dd></Fragment>)}
                {v.diagnosis && <><dt>Diagnoza</dt><dd><b>{v.diagnosis}</b></dd></>}
                {v.treatment && <><dt>Trajtimi</dt><dd>{v.treatment}</dd></>}
                {v.prescription && <><dt>Receta</dt><dd>{v.prescription}</dd></>}
                {v.notes && <><dt>Shënime</dt><dd className="muted">{v.notes}</dd></>}
                {v.nextVisitDate && <><dt>Vizita e radhës</dt><dd>{fmtDate(v.nextVisitDate)}</dd></>}
              </dl>
            </article>
          ))}
        </div>
      )}
      {form && <VisitForm patientId={patientId} visit={form.visit} onClose={() => setForm(null)} onSaved={() => { setForm(null); visits.reload(); }} />}
    </Card>
  );
}

function FinanceTab({ patientId, onChange }: { patientId: string; onChange: () => void }) {
  const { business, hasRole } = useAuth();
  const nav = useNavigate();
  const [sel, setSel] = useState<string[]>([]);
  const toggleSel = (cid: string) => setSel(s => (s.includes(cid) ? s.filter(x => x !== cid) : [...s, cid]));
  const st = useAsync(() => api.get<Statement>(`/api/finance/statement/${patientId}`), [patientId]);
  const [modal, setModal] = useState<'charge' | 'payment' | null>(null);
  const cur = business?.currency;
  const done = () => { setModal(null); st.reload(); onChange(); };

  const remove = async (type: string, entryId: string) => {
    if (!confirm('Të fshihet ky rresht?')) return;
    await api.del(`/api/finance/${type === 'Pagesë' ? 'payments' : 'charges'}/${entryId}`);
    done();
  };

  return (
    <>
      {st.data && (
        <div className="stats">
          <div className="stat"><div className="stat-label">Gjithsej faturuar</div><div className="stat-value">{fmtMoney(st.data.totalCharged, cur)}</div></div>
          <div className="stat"><div className="stat-label">Gjithsej paguar</div><div className="stat-value green">{fmtMoney(st.data.totalPaid, cur)}</div></div>
          <div className="stat"><div className="stat-label">{st.data.balance >= 0 ? 'Borxhi i mbetur' : 'Kredi (parapagim)'}</div><div className={`stat-value ${st.data.balance > 0 ? 'red' : 'green'}`}>{fmtMoney(Math.abs(st.data.balance), cur)}</div></div>
        </div>
      )}
      <Card title="Kartela financiare" actions={<>
        <button className="btn ghost" onClick={() => nav(`/printo/kartela/${patientId}`)}>🖨 Kartela</button>
        <button className="btn ghost" onClick={() => nav(`/printo/fature/${patientId}${sel.length ? `?charges=${sel.join(',')}` : ''}`)}>
          🖨 Faturë {sel.length ? `(${sel.length} të zgjedhura)` : '(të gjitha)'}
        </button>
        <button className="btn ghost" onClick={() => setModal('charge')}>+ Ngarkesë</button>
        <button className="btn primary" onClick={() => setModal('payment')}>+ Pagesë</button>
      </>}>
        <ErrorBox error={st.error} />
        {st.loading ? <Spinner /> : !st.data?.entries.length ? <Empty>Nuk ka lëvizje financiare.</Empty> : (
          <table className="table">
            <thead><tr><th title="Zgjidh për faturë">🖨</th><th>Data</th><th>Lloji</th><th>Përshkrimi</th><th className="num">Detyrim</th><th className="num">Pagesë</th><th className="num">Balanca</th><th /></tr></thead>
            <tbody>
              {st.data.entries.map(e => (
                <tr key={e.id}>
                  <td>{e.type !== 'Pagesë' && <input type="checkbox" checked={sel.includes(e.id)} onChange={() => toggleSel(e.id)} title="Përfshi në faturë" />}</td>
                  <td>{fmtDate(e.date)}</td>
                  <td><Badge tone={e.type === 'Pagesë' ? 'green' : 'neutral'}>{e.type}</Badge></td>
                  <td>{e.description}</td>
                  <td className="num">{e.debit ? fmtMoney(e.debit, cur) : ''}</td>
                  <td className="num green">{e.credit ? fmtMoney(e.credit, cur) : ''}</td>
                  <td className={`num ${e.runningBalance > 0 ? 'red' : ''}`}>{fmtMoney(e.runningBalance, cur)}</td>
                  <td>{hasRole('Admin') && <button className="icon-btn" title="Fshi" onClick={() => remove(e.type, e.id)}>✕</button>}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </Card>
      {modal === 'charge' && <ChargeModal patientId={patientId} onClose={() => setModal(null)} onDone={done} />}
      {modal === 'payment' && <PaymentModal patientId={patientId} suggested={st.data?.balance} onClose={() => setModal(null)} onDone={done} />}
    </>
  );
}

function AppointmentsTab({ patient }: { patient: Patient }) {
  const list = useAsync(() => api.get<Appointment[]>(`/api/appointments?patientId=${patient.id}`), [patient.id]);
  const [open, setOpen] = useState(false);
  return (
    <Card title="Terminet" actions={<button className="btn primary" onClick={() => setOpen(true)}>+ Termin</button>}>
      {list.loading ? <Spinner /> : !list.data?.length ? <Empty>Nuk ka termine.</Empty> : (
        <table className="table">
          <thead><tr><th>Data</th><th>Shërbimi</th><th>Stafi</th><th>Statusi</th></tr></thead>
          <tbody>
            {[...list.data].reverse().map(a => (
              <tr key={a.id}><td>{fmtDateTime(a.startsAt)}</td><td>{a.serviceName ?? '—'}</td><td>{a.staffName ?? '—'}</td><td><Badge>{a.statusLabel}</Badge></td></tr>
            ))}
          </tbody>
        </table>
      )}
      {open && <AppointmentModal patient={patient} onClose={() => setOpen(false)} onSaved={() => { setOpen(false); list.reload(); }} />}
    </Card>
  );
}

function PortalModal({ patient, onClose, onDone }: { patient: Patient; onClose: () => void; onDone: () => void }) {
  const [email, setEmail] = useState(patient.email ?? '');
  const [pwd, setPwd] = useState('');
  const [err, setErr] = useState<string | null>(null);
  const go = async () => {
    try { await api.post(`/api/patients/${patient.id}/portal-access`, { email, password: pwd }); onDone(); }
    catch (e: any) { setErr(e.message); }
  };
  return (
    <Modal title="Qasja në aplikacionin mobil" onClose={onClose}>
      <ErrorBox error={err} />
      <p className="muted">Jepini pacientit këto të dhëna për të hyrë në aplikacionin mobil.</p>
      <div className="form-grid">
        <Field label="Email" full><input type="email" value={email} onChange={e => setEmail(e.target.value)} /></Field>
        <Field label="Fjalëkalimi (min. 8, shkronja + numra)" full><input value={pwd} onChange={e => setPwd(e.target.value)} /></Field>
      </div>
      <div className="modal-actions"><button className="btn ghost" onClick={onClose}>Anulo</button><button className="btn primary" disabled={!email || pwd.length < 8} onClick={go}>Ruaj</button></div>
    </Modal>
  );
}

import { useEffect, useRef, useState, type CSSProperties, type FormEvent } from 'react';
import { api } from '../../api/client';
import type { FileCategory, PatientFile, Visit } from '../../api/types';
import { useAuth } from '../../auth';
import { Badge, Card, Empty, ErrorBox, Field, Modal, Spinner, useAsync } from '../../components/ui';
import { fmtDate, fmtDateTime, todayIso } from '../../sq';

export const categoryLabels: Record<FileCategory, string> = {
  RrezeX: 'Rreze X', OPG: 'OPG / Panoramike', CBCT: 'CBCT / Skaner 3D', Ekografi: 'Ekografi',
  Foto: 'Foto klinike', Dokument: 'Dokument / Analizë', Tjeter: 'Tjetër',
};

// ---------- Ngarkimi i imazheve me token (cache në memorie) ----------
const urlCache = new Map<string, string>();
async function fileUrl(id: string): Promise<string> {
  const hit = urlCache.get(id);
  if (hit) return hit;
  const url = URL.createObjectURL(await api.blob(`/api/files/${id}/content`));
  urlCache.set(id, url);
  return url;
}

function AuthedImage({ id, alt, className, style, draggable }:
  { id: string; alt: string; className?: string; style?: CSSProperties; draggable?: boolean }) {
  const [src, setSrc] = useState<string | null>(urlCache.get(id) ?? null);
  const [err, setErr] = useState(false);
  useEffect(() => {
    let alive = true;
    if (!src) fileUrl(id).then(u => alive && setSrc(u)).catch(() => alive && setErr(true));
    return () => { alive = false; };
  }, [id, src]);
  if (err) return <div className={`thumb-fallback ${className ?? ''}`}>⚠</div>;
  if (!src) return <div className={`thumb-fallback ${className ?? ''}`}><span className="dot" /></div>;
  return <img src={src} alt={alt} className={className} style={style} draggable={draggable} />;
}

const fmtSize = (b: number) => (b > 1024 * 1024 ? `${(b / 1024 / 1024).toFixed(1)} MB` : `${Math.max(1, Math.round(b / 1024))} KB`);

/** Skeda "Rrezet X & Imazhet" në kartelën e pacientit. */
export default function ImagingTab({ patientId }: { patientId: string }) {
  const { business, hasRole } = useAuth();
  const isDental = business?.specialty === 'Stomatologji';
  const [cat, setCat] = useState<FileCategory | ''>('');
  const [toothFilter, setToothFilter] = useState('');
  const [uploadOpen, setUploadOpen] = useState(false);
  const [viewIndex, setViewIndex] = useState<number | null>(null);
  const [edit, setEdit] = useState<PatientFile | null>(null);
  const files = useAsync(() => api.get<PatientFile[]>(`/api/patients/${patientId}/files`), [patientId]);

  const shown = (files.data ?? []).filter(f => (!cat || f.category === cat) && (!toothFilter || (f.tooth ?? '').includes(toothFilter.trim())));
  const images = shown.filter(f => f.isImage);

  const open = async (f: PatientFile) => {
    if (f.isImage) { setViewIndex(images.findIndex(x => x.id === f.id)); return; }
    const url = await fileUrl(f.id);
    if (f.contentType === 'application/pdf') window.open(url, '_blank');
    else download(f);
  };
  const download = async (f: PatientFile) => {
    const a = document.createElement('a');
    a.href = await fileUrl(f.id);
    a.download = f.fileName;
    a.click();
  };
  const remove = async (f: PatientFile) => {
    if (!confirm(`Të fshihet "${f.fileName}" përgjithmonë?`)) return;
    await api.del(`/api/files/${f.id}`);
    files.reload();
  };

  return (
    <Card title="Rrezet X & Imazhet" actions={<button className="btn primary" onClick={() => setUploadOpen(true)}>⬆ Ngarko</button>}>
      <div className="toolbar">
        <div className="chips">
          <button className={`chip ${cat === '' ? 'on' : ''}`} onClick={() => setCat('')}>Të gjitha ({files.data?.length ?? 0})</button>
          {(Object.keys(categoryLabels) as FileCategory[]).map(k => {
            const n = files.data?.filter(f => f.category === k).length ?? 0;
            return n > 0 && <button key={k} className={`chip ${cat === k ? 'on' : ''}`} onClick={() => setCat(k)}>{categoryLabels[k]} ({n})</button>;
          })}
        </div>
        {isDental && <input className="w-sm" placeholder="Dhëmbi…" value={toothFilter} onChange={e => setToothFilter(e.target.value)} />}
      </div>
      <ErrorBox error={files.error} />
      {files.loading ? <Spinner /> : !shown.length ? (
        <Empty>
          Nuk ka imazhe.<br />
          <button className="btn ghost small" style={{ marginTop: 10 }} onClick={() => setUploadOpen(true)}>Ngarko rrezen e parë</button>
        </Empty>
      ) : (
        <div className="gallery">
          {shown.map(f => (
            <figure key={f.id} className="tile">
              <button className="tile-img" onClick={() => open(f)} title="Hap">
                {f.isImage ? <AuthedImage id={f.id} alt={f.fileName} /> : <div className="tile-doc">{f.contentType === 'application/pdf' ? 'PDF' : 'DICOM'}</div>}
              </button>
              <figcaption>
                <div className="row gap"><Badge tone="blue">{f.categoryLabel}</Badge>{f.tooth && <Badge>🦷 {f.tooth}</Badge>}</div>
                <div className="small">{fmtDate(f.takenAt)} · {fmtSize(f.sizeBytes)}</div>
                {f.notes && <div className="small muted clamp">{f.notes}</div>}
                <div className="row gap tile-actions">
                  <button className="icon-btn" title="Ndrysho" onClick={() => setEdit(f)}>✎</button>
                  <button className="icon-btn" title="Shkarko" onClick={() => download(f)}>⬇</button>
                  {hasRole('Admin', 'Mjek') && <button className="icon-btn" title="Fshi" onClick={() => remove(f)}>✕</button>}
                </div>
              </figcaption>
            </figure>
          ))}
        </div>
      )}

      {uploadOpen && <UploadModal patientId={patientId} isDental={isDental} onClose={() => setUploadOpen(false)} onDone={() => { setUploadOpen(false); files.reload(); }} />}
      {edit && <EditModal f={edit} isDental={isDental} onClose={() => setEdit(null)} onDone={() => { setEdit(null); files.reload(); }} />}
      {viewIndex !== null && images[viewIndex] && (
        <Viewer files={images} index={viewIndex} onIndex={setViewIndex} onClose={() => setViewIndex(null)} onDownload={download} />
      )}
    </Card>
  );
}

// ---------- Ngarkimi ----------
function UploadModal({ patientId, isDental, onClose, onDone }: { patientId: string; isDental: boolean; onClose: () => void; onDone: () => void }) {
  const [files, setFiles] = useState<File[]>([]);
  const [category, setCategory] = useState<FileCategory>(isDental ? 'RrezeX' : 'Foto');
  const [tooth, setTooth] = useState('');
  const [notes, setNotes] = useState('');
  const [takenAt, setTakenAt] = useState(todayIso());
  const [visitId, setVisitId] = useState('');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [drag, setDrag] = useState(false);
  const visits = useAsync(() => api.get<Visit[]>(`/api/visits?patientId=${patientId}&take=20`).catch(() => [] as Visit[]), [patientId]);
  const previews = useRef(new Map<File, string>());

  useEffect(() => () => previews.current.forEach(u => URL.revokeObjectURL(u)), []);
  const preview = (f: File) => {
    if (!f.type.startsWith('image/')) return null;
    if (!previews.current.has(f)) previews.current.set(f, URL.createObjectURL(f));
    return previews.current.get(f)!;
  };
  const add = (list: FileList | null) => list && setFiles(prev => [...prev, ...Array.from(list)].slice(0, 20));

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!files.length) return setErr('Zgjidhni të paktën një skedar.');
    setBusy(true); setErr(null);
    const form = new FormData();
    files.forEach(f => form.append('files', f));
    form.append('category', category);
    if (tooth) form.append('tooth', tooth);
    if (notes) form.append('notes', notes);
    if (visitId) form.append('visitId', visitId);
    form.append('takenAt', new Date(takenAt + 'T12:00:00').toISOString());
    try { await api.upload(`/api/patients/${patientId}/files`, form); onDone(); }
    catch (e: any) { setErr(e.message); }
    finally { setBusy(false); }
  };

  return (
    <Modal title="Ngarko rreze X / imazhe" onClose={onClose} wide>
      <form className="form-grid" onSubmit={submit}>
        {err && <div className="alert error full">{err}</div>}
        <label className={`dropzone full ${drag ? 'drag' : ''}`}
          onDragOver={e => { e.preventDefault(); setDrag(true); }} onDragLeave={() => setDrag(false)}
          onDrop={e => { e.preventDefault(); setDrag(false); add(e.dataTransfer.files); }}>
          <input type="file" multiple accept="image/*,.pdf,.dcm" onChange={e => add(e.target.files)} hidden />
          <b>Tërhiqni skedarët këtu</b> ose klikoni për t'i zgjedhur
          <span className="small muted">JPG, PNG, WEBP, PDF, DICOM · deri 30 MB secili · max 20 njëherësh</span>
        </label>
        {files.length > 0 && (
          <div className="full upload-list">
            {files.map((f, i) => (
              <div key={i} className="upload-item">
                {preview(f) ? <img src={preview(f)!} alt="" /> : <div className="tile-doc small">{f.name.split('.').pop()?.toUpperCase()}</div>}
                <span className="small clamp">{f.name}</span>
                <button type="button" className="icon-btn" onClick={() => setFiles(x => x.filter((_, j) => j !== i))}>✕</button>
              </div>
            ))}
          </div>
        )}
        <Field label="Lloji">
          <select value={category} onChange={e => setCategory(e.target.value as FileCategory)}>
            {Object.entries(categoryLabels).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
          </select>
        </Field>
        <Field label="Data e realizimit"><input type="date" value={takenAt} onChange={e => setTakenAt(e.target.value)} /></Field>
        {isDental && <Field label="Dhëmbi / dhëmbët (FDI)"><input value={tooth} onChange={e => setTooth(e.target.value)} placeholder="p.sh. 16 ose 11-21" /></Field>}
        <Field label="Lidhe me vizitën (opsionale)">
          <select value={visitId} onChange={e => setVisitId(e.target.value)}>
            <option value="">—</option>
            {visits.data?.map(v => <option key={v.id} value={v.id}>{fmtDateTime(v.visitDate)} · {v.diagnosis ?? v.complaint ?? 'Vizitë'}</option>)}
          </select>
        </Field>
        <Field label="Shënime / përshkrimi" full><textarea rows={2} value={notes} onChange={e => setNotes(e.target.value)} placeholder="p.sh. Karies distal, kontroll pas mbushjes…" /></Field>
        <div className="modal-actions full">
          <button type="button" className="btn ghost" onClick={onClose}>Anulo</button>
          <button className="btn primary" disabled={busy || !files.length}>{busy ? 'Duke ngarkuar…' : `Ngarko ${files.length || ''}`}</button>
        </div>
      </form>
    </Modal>
  );
}

function EditModal({ f, isDental, onClose, onDone }: { f: PatientFile; isDental: boolean; onClose: () => void; onDone: () => void }) {
  const [category, setCategory] = useState<FileCategory>(f.category);
  const [tooth, setTooth] = useState(f.tooth ?? '');
  const [notes, setNotes] = useState(f.notes ?? '');
  const [takenAt, setTakenAt] = useState(f.takenAt.slice(0, 10));
  const [err, setErr] = useState<string | null>(null);
  const save = async () => {
    try {
      await api.put(`/api/files/${f.id}`, { category, tooth: tooth || null, notes: notes || null, visitId: f.visitId ?? null,
        takenAt: new Date(takenAt + 'T12:00:00').toISOString() });
      onDone();
    } catch (e: any) { setErr(e.message); }
  };
  return (
    <Modal title={f.fileName} onClose={onClose}>
      <ErrorBox error={err} />
      <div className="form-grid">
        <Field label="Lloji">
          <select value={category} onChange={e => setCategory(e.target.value as FileCategory)}>
            {Object.entries(categoryLabels).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
          </select>
        </Field>
        <Field label="Data"><input type="date" value={takenAt} onChange={e => setTakenAt(e.target.value)} /></Field>
        {isDental && <Field label="Dhëmbi (FDI)"><input value={tooth} onChange={e => setTooth(e.target.value)} /></Field>}
        <Field label="Shënime" full><textarea rows={3} value={notes} onChange={e => setNotes(e.target.value)} /></Field>
      </div>
      <p className="small muted">Ngarkuar nga {f.uploadedBy ?? '—'} më {fmtDateTime(f.createdAt)}</p>
      <div className="modal-actions"><button className="btn ghost" onClick={onClose}>Anulo</button><button className="btn primary" onClick={save}>Ruaj</button></div>
    </Modal>
  );
}

// ---------- Shikuesi i rrezeve X ----------
function Viewer({ files, index, onIndex, onClose, onDownload }:
  { files: PatientFile[]; index: number; onIndex: (i: number) => void; onClose: () => void; onDownload: (f: PatientFile) => void }) {
  const f = files[index];
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [rot, setRot] = useState(0);
  const [bright, setBright] = useState(100);
  const [contrast, setContrast] = useState(100);
  const [invert, setInvert] = useState(false);
  const dragRef = useRef<{ x: number; y: number; px: number; py: number } | null>(null);

  const reset = () => { setZoom(1); setPan({ x: 0, y: 0 }); setRot(0); setBright(100); setContrast(100); setInvert(false); };
  const go = (d: number) => { const n = index + d; if (n >= 0 && n < files.length) { onIndex(n); setZoom(1); setPan({ x: 0, y: 0 }); setRot(0); } };

  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
      else if (e.key === 'ArrowRight') go(1);
      else if (e.key === 'ArrowLeft') go(-1);
      else if (e.key === '+' || e.key === '=') setZoom(z => Math.min(8, z * 1.25));
      else if (e.key === '-') setZoom(z => Math.max(0.2, z / 1.25));
      else if (e.key.toLowerCase() === 'i') setInvert(v => !v);
      else if (e.key.toLowerCase() === 'r') setRot(r => r + 90);
      else if (e.key === '0') reset();
    };
    window.addEventListener('keydown', h);
    return () => window.removeEventListener('keydown', h);
  });

  return (
    <div className="viewer" role="dialog" aria-label="Shikuesi i imazheve">
      <header className="viewer-bar">
        <div className="viewer-title">
          <b>{f.categoryLabel}{f.tooth ? ` · Dhëmbi ${f.tooth}` : ''}</b>
          <span>{fmtDate(f.takenAt)} · {f.fileName} · {index + 1}/{files.length}</span>
        </div>
        <div className="viewer-tools">
          <button onClick={() => setZoom(z => Math.max(0.2, z / 1.25))} title="Zvogëlo (−)">−</button>
          <span className="zoom">{Math.round(zoom * 100)}%</span>
          <button onClick={() => setZoom(z => Math.min(8, z * 1.25))} title="Zmadho (+)">+</button>
          <button onClick={() => setRot(r => r + 90)} title="Rrotullo (R)">⟳</button>
          <button className={invert ? 'on' : ''} onClick={() => setInvert(v => !v)} title="Negativ (I)">◐</button>
          <label title="Ndriçimi">☀<input type="range" min={30} max={250} value={bright} onChange={e => setBright(+e.target.value)} /></label>
          <label title="Kontrasti">◑<input type="range" min={30} max={300} value={contrast} onChange={e => setContrast(+e.target.value)} /></label>
          <button onClick={reset} title="Rikthe (0)">Rikthe</button>
          <button onClick={() => onDownload(f)} title="Shkarko">⬇</button>
          <button onClick={onClose} title="Mbyll (Esc)">✕</button>
        </div>
      </header>
      <div className="viewer-stage"
        onWheel={e => setZoom(z => Math.min(8, Math.max(0.2, z * (e.deltaY < 0 ? 1.12 : 1 / 1.12))))}
        onMouseDown={e => { dragRef.current = { x: e.clientX, y: e.clientY, px: pan.x, py: pan.y }; }}
        onMouseMove={e => { const d = dragRef.current; if (d) setPan({ x: d.px + e.clientX - d.x, y: d.py + e.clientY - d.y }); }}
        onMouseUp={() => { dragRef.current = null; }} onMouseLeave={() => { dragRef.current = null; }}
        onDoubleClick={() => setZoom(z => (z === 1 ? 2.5 : 1))}>
        <AuthedImage id={f.id} alt={f.fileName} draggable={false} className="viewer-img" style={{
          transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom}) rotate(${rot}deg)`,
          filter: `brightness(${bright}%) contrast(${contrast}%) ${invert ? 'invert(1)' : ''}`,
        }} />
        {index > 0 && <button className="viewer-nav left" onClick={e => { e.stopPropagation(); go(-1); }}>‹</button>}
        {index < files.length - 1 && <button className="viewer-nav right" onClick={e => { e.stopPropagation(); go(1); }}>›</button>}
      </div>
      {f.notes && <footer className="viewer-notes">{f.notes}</footer>}
      <div className="viewer-strip">
        {files.map((x, i) => (
          <button key={x.id} className={i === index ? 'on' : ''} onClick={() => { onIndex(i); setZoom(1); setPan({ x: 0, y: 0 }); }}>
            <AuthedImage id={x.id} alt="" />
          </button>
        ))}
      </div>
    </div>
  );
}

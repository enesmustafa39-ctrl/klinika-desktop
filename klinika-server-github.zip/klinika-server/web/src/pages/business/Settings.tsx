import { useEffect, useState } from 'react';
import { api } from '../../api/client';
import type { BusinessSettings } from '../../api/types';
import { useAuth } from '../../auth';
import { Badge, Card, ErrorBox, Field, Spinner } from '../../components/ui';

const zones = [
  ['Europe/Tirane', 'Shqipëri / Kosovë (CET)'], ['Europe/Skopje', 'Maqedoni e Veriut (CET)'], ['Europe/Belgrade', 'Serbi / Mal i Zi (CET)'],
  ['Europe/Berlin', 'Gjermani (CET)'], ['Europe/Zurich', 'Zvicër (CET)'], ['Europe/London', 'Mbretëri e Bashkuar'], ['Europe/Athens', 'Greqi (EET)'],
];
const placeholders = ['{pacienti}', '{klinika}', '{data}', '{ora}', '{mjeku}', '{sherbimi}', '{telefoni}'];

/** Cilësimet e klinikës (vetëm Administratori). */
export default function Settings() {
  const { hasFeature } = useAuth();
  const [s, setS] = useState<BusinessSettings | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [ok, setOk] = useState(false);
  const [busy, setBusy] = useState(false);

  useEffect(() => { api.get<BusinessSettings>('/api/business/settings').then(setS).catch(e => setErr(e.message)); }, []);
  if (!s) return err ? <ErrorBox error={err} /> : <Spinner />;

  const set = <K extends keyof BusinessSettings>(k: K, v: BusinessSettings[K]) => { setOk(false); setS({ ...s, [k]: v }); };
  const save = async () => {
    setBusy(true); setErr(null);
    try {
      const r = await api.put<BusinessSettings>('/api/business/settings', {
        address: s.address || null, city: s.city || null, phone: s.phone || null, email: s.email || null,
        timeZone: s.timeZone, phoneCountryCode: s.phoneCountryCode, reminderHoursBefore: s.reminderHoursBefore,
        reminderTemplate: s.reminderTemplate, invoiceFooter: s.invoiceFooter || null,
      });
      setS(r); setOk(true);
    } catch (e: any) { setErr(e.message); } finally { setBusy(false); }
  };

  const preview = s.reminderTemplate
    .replace('{pacienti}', 'Blerina').replace('{klinika}', s.name).replace('{data}', '15.10.2026').replace('{ora}', '10:30')
    .replace('{mjeku}', 'Dr. Elira').replace('{sherbimi}', 'Kontroll').replace('{telefoni}', s.phone ?? '');

  return (
    <div className="page narrow">
      <div className="page-head">
        <h1>Cilësimet e klinikës</h1>
        <button className="btn primary" disabled={busy} onClick={save}>{busy ? 'Duke ruajtur…' : 'Ruaj'}</button>
      </div>
      <ErrorBox error={err} />
      {ok && <div className="alert success">Cilësimet u ruajtën.</div>}

      <Card title="Kontaktet (shfaqen në fatura, receta dhe kujtesa)">
        <div className="form-grid">
          <Field label="Emri"><input value={s.name} disabled /></Field>
          <Field label="NIPT"><input value={s.nipt ?? ''} disabled /></Field>
          <Field label="Adresa"><input value={s.address ?? ''} onChange={e => set('address', e.target.value)} /></Field>
          <Field label="Qyteti"><input value={s.city ?? ''} onChange={e => set('city', e.target.value)} /></Field>
          <Field label="Telefoni"><input value={s.phone ?? ''} onChange={e => set('phone', e.target.value)} /></Field>
          <Field label="Email"><input type="email" value={s.email ?? ''} onChange={e => set('email', e.target.value)} /></Field>
          <Field label="Zona kohore">
            <select value={s.timeZone} onChange={e => set('timeZone', e.target.value)}>
              {zones.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
            </select>
          </Field>
          <Field label="Prefiksi i shtetit për telefonat">
            <select value={s.phoneCountryCode} onChange={e => set('phoneCountryCode', e.target.value)}>
              <option value="383">+383 Kosovë</option><option value="355">+355 Shqipëri</option><option value="389">+389 Maqedoni e V.</option>
              <option value="382">+382 Mal i Zi</option><option value="41">+41 Zvicër</option><option value="49">+49 Gjermani</option>
            </select>
          </Field>
          <p className="small muted full">Emrin dhe NIPT-in i ndryshon ofruesi i platformës.</p>
        </div>
      </Card>

      <Card title={<>Kujtesat për terminet {!hasFeature('reminders') && <Badge tone="amber">Jo aktiv për klinikën</Badge>}</>}>
        {!hasFeature('reminders') && <p className="muted small">Funksioni i kujtesave nuk është aktivizuar. Kontaktoni ofruesin e platformës.</p>}
        <div className="form-grid">
          <Field label="Dërgo kujtesën automatike sa orë para terminit">
            <select value={s.reminderHoursBefore} onChange={e => set('reminderHoursBefore', +e.target.value)}>
              {[2, 3, 6, 12, 24, 48, 72].map(h => <option key={h} value={h}>{h} orë para</option>)}
            </select>
          </Field>
          <div className="field">
            <span>Dërgimi automatik</span>
            {s.autoRemindersAvailable
              ? <Badge tone="green">Aktiv – {s.autoReminderChannel === 'whatsapp' ? 'WhatsApp' : 'SMS'}</Badge>
              : <span className="small muted">Platforma nuk ka ofrues SMS. Kujtesat dërgohen me një klik (WhatsApp / Viber / SMS) nga Terminet.</span>}
          </div>
          <Field label="Teksti i kujtesës" full>
            <textarea rows={3} value={s.reminderTemplate} onChange={e => set('reminderTemplate', e.target.value)} />
          </Field>
          <div className="full small">
            <span className="muted">Fushat: </span>
            {placeholders.map(p => <button key={p} type="button" className="chip" onClick={() => set('reminderTemplate', `${s.reminderTemplate} ${p}`)}>{p}</button>)}
            <button type="button" className="btn ghost small" style={{ marginLeft: 8 }} onClick={() => set('reminderTemplate', s.defaultReminderTemplate)}>Teksti standard</button>
          </div>
          <div className="full reminder-preview"><span className="small muted">Shembull:</span><div>{preview}</div></div>
        </div>
      </Card>

      <Card title="Fatura">
        <Field label="Teksti në fund të faturës (p.sh. llogaria bankare, orari)" full>
          <textarea rows={3} value={s.invoiceFooter ?? ''} onChange={e => set('invoiceFooter', e.target.value)}
            placeholder="Llogaria: ProCredit Bank 1110-0000-0000-0000 · Orari: E hënë–E shtunë 08:00–20:00" />
        </Field>
      </Card>
    </div>
  );
}

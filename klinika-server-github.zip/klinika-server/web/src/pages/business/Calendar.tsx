import { useMemo, useRef, useState, type CSSProperties, type DragEvent, type MouseEvent } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { api, qs } from '../../api/client';
import type { Appointment, AppointmentStatus, User } from '../../api/types';
import { useAuth } from '../../auth';
import ReminderModal, { reminderChannelLabel } from '../../components/ReminderModal';
import { Badge, ErrorBox, Modal, Spinner, useAsync } from '../../components/ui';
import { fmtDateTime, fmtLongDate, fmtTime, statusLabels } from '../../sq';
import { AppointmentModal } from './Appointments';

const START_H = 7;
const END_H = 21;
const PPM = 1.2;               // pixel për minutë → 72px për orë
const SNAP = 15;               // minuta
const DAY_NAMES = ['Hën', 'Mar', 'Mër', 'Enj', 'Pre', 'Sht', 'Die'];

type View = 'dite' | 'jave';
interface Column { key: string; title: string; sub?: string; date: Date; staffId?: string | null }

const startOfDay = (d: Date) => { const x = new Date(d); x.setHours(0, 0, 0, 0); return x; };
const startOfWeek = (d: Date) => { const x = startOfDay(d); const wd = (x.getDay() + 6) % 7; x.setDate(x.getDate() - wd); return x; };
const addDays = (d: Date, n: number) => { const x = new Date(d); x.setDate(x.getDate() + n); return x; };
const sameDay = (a: Date, b: Date) => a.toDateString() === b.toDateString();
const minutesOf = (d: Date) => d.getHours() * 60 + d.getMinutes();

/** Vendos terminet që mbivendosen në "korsi" pranë njëri-tjetrit. */
function layout(items: Appointment[]) {
  const sorted = [...items].sort((a, b) => +new Date(a.startsAt) - +new Date(b.startsAt));
  const out: { a: Appointment; lane: number; lanes: number }[] = [];
  let group: { a: Appointment; lane: number; end: number }[] = [];
  let groupEnd = -1;
  const flush = () => { const n = Math.max(1, ...group.map(g => g.lane + 1)); group.forEach(g => out.push({ a: g.a, lane: g.lane, lanes: n })); group = []; };
  for (const a of sorted) {
    const s = +new Date(a.startsAt), e = s + a.durationMinutes * 60000;
    if (s >= groupEnd) { flush(); groupEnd = -1; }
    const used = new Set(group.filter(g => g.end > s).map(g => g.lane));
    let lane = 0; while (used.has(lane)) lane++;
    group.push({ a, lane, end: e });
    groupEnd = Math.max(groupEnd, e);
  }
  flush();
  return out;
}

/** Kalendari vizual: ditë (kolona për çdo mjek) ose javë; terminet zhvendosen duke i tërhequr. */
export default function CalendarView({ onChanged }: { onChanged?: () => void }) {
  const { business, hasFeature } = useAuth();
  const [view, setView] = useState<View>('dite');
  const [date, setDate] = useState(() => startOfDay(new Date()));
  const [staffFilter, setStaffFilter] = useState('');
  const [hideCancelled, setHideCancelled] = useState(true);
  const [err, setErr] = useState<string | null>(null);
  const [selected, setSelected] = useState<Appointment | null>(null);
  const [edit, setEdit] = useState<{ appt?: Appointment; start?: Date; staffId?: string } | null>(null);
  const [remind, setRemind] = useState<Appointment | null>(null);
  const drag = useRef<{ id: string; offsetY: number } | null>(null);
  const nav = useNavigate();

  const staff = useAsync(() => api.get<User[]>('/api/staff'));
  const rangeStart = view === 'dite' ? date : startOfWeek(date);
  const rangeEnd = addDays(rangeStart, view === 'dite' ? 1 : 7);
  const appts = useAsync(() => api.get<Appointment[]>(`/api/appointments${qs({
    from: rangeStart.toISOString(), to: rangeEnd.toISOString(), staffId: view === 'jave' ? staffFilter : '',
  })}`), [rangeStart.getTime(), view, staffFilter]);

  const clinicalStaff = (staff.data ?? []).filter(s => s.role !== 'Recepsion');
  const columns: Column[] = useMemo(() => {
    if (view === 'jave') return Array.from({ length: 7 }, (_, i) => {
      const d = addDays(rangeStart, i);
      return { key: d.toDateString(), title: `${DAY_NAMES[i]} ${d.getDate()}.${d.getMonth() + 1}`, date: d };
    });
    const cols: Column[] = clinicalStaff.map(s => ({ key: s.id, title: s.fullName, sub: s.title ?? s.roleLabel, date, staffId: s.id }));
    cols.push({ key: 'none', title: 'Pa caktuar', sub: 'Pa mjek', date, staffId: null });
    return cols;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [view, rangeStart.getTime(), staff.data]);

  const visible = (appts.data ?? []).filter(a => !hideCancelled || (a.status !== 'Anuluar' && a.status !== 'NukErdhi'));
  const inColumn = (c: Column) => visible.filter(a => view === 'jave'
    ? sameDay(new Date(a.startsAt), c.date)
    : c.staffId === null ? !a.staffId || !clinicalStaff.some(s => s.id === a.staffId) : a.staffId === c.staffId);

  const yToDate = (c: Column, y: number) => {
    const mins = Math.max(0, Math.min((END_H - START_H) * 60 - SNAP, Math.round(y / PPM / SNAP) * SNAP));
    const d = startOfDay(c.date);
    d.setMinutes(START_H * 60 + mins);
    return d;
  };

  const move = async (a: Appointment, start: Date, staffId: string | null | undefined) => {
    setErr(null);
    try {
      await api.put(`/api/appointments/${a.id}`, {
        patientId: a.patientId, staffId: staffId === undefined ? a.staffId ?? null : staffId, serviceItemId: a.serviceItemId ?? null,
        startsAt: start.toISOString(), durationMinutes: a.durationMinutes, status: a.status, notes: a.notes ?? null,
      });
    } catch (e: any) { setErr(`${a.patientName}: ${e.message}`); }
    appts.reload(); onChanged?.();
  };

  const onDrop = (e: DragEvent<HTMLDivElement>, c: Column) => {
    e.preventDefault();
    const d = drag.current; drag.current = null;
    const a = appts.data?.find(x => x.id === d?.id);
    if (!a || !d) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const start = yToDate(c, e.clientY - rect.top - d.offsetY);
    if (+start === +new Date(a.startsAt) && (view === 'jave' || (c.staffId ?? null) === (a.staffId ?? null))) return;
    move(a, start, view === 'dite' ? c.staffId : undefined);
  };

  const onEmptyClick = (e: MouseEvent<HTMLDivElement>, c: Column) => {
    if (e.target !== e.currentTarget) return;
    const rect = e.currentTarget.getBoundingClientRect();
    setEdit({ start: yToDate(c, e.clientY - rect.top), staffId: c.staffId ?? (view === 'jave' ? staffFilter || undefined : undefined) });
  };

  const setStatus = async (a: Appointment, s: AppointmentStatus) => {
    try { await api.post(`/api/appointments/${a.id}/status`, { status: s }); setSelected(null); appts.reload(); onChanged?.(); }
    catch (e: any) { setErr(e.message); }
  };

  const shift = (n: number) => setDate(d => addDays(d, view === 'dite' ? n : n * 7));
  const hours = Array.from({ length: END_H - START_H }, (_, i) => START_H + i);
  const now = new Date();
  const nowTop = (minutesOf(now) - START_H * 60) * PPM;

  return (
    <div className="cal-wrap">
      <div className="cal-toolbar">
        <div className="seg">
          <button className={view === 'dite' ? 'on' : ''} onClick={() => setView('dite')}>Ditë</button>
          <button className={view === 'jave' ? 'on' : ''} onClick={() => setView('jave')}>Javë</button>
        </div>
        <button className="btn ghost small" onClick={() => shift(-1)}>‹</button>
        <button className="btn ghost small" onClick={() => setDate(startOfDay(new Date()))}>Sot</button>
        <button className="btn ghost small" onClick={() => shift(1)}>›</button>
        <input type="date" className="w-date" value={`${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`}
          onChange={e => e.target.value && setDate(startOfDay(new Date(e.target.value + 'T00:00:00')))} />
        <b className="cal-title">{view === 'dite' ? fmtLongDate(date) : `${rangeStart.getDate()}.${rangeStart.getMonth() + 1} – ${addDays(rangeStart, 6).getDate()}.${addDays(rangeStart, 6).getMonth() + 1}.${addDays(rangeStart, 6).getFullYear()}`}</b>
        <span className="spacer" />
        {view === 'jave' && (
          <select value={staffFilter} onChange={e => setStaffFilter(e.target.value)}>
            <option value="">I gjithë stafi</option>
            {clinicalStaff.map(s => <option key={s.id} value={s.id}>{s.fullName}</option>)}
          </select>
        )}
        <label className="check small"><input type="checkbox" checked={hideCancelled} onChange={e => setHideCancelled(e.target.checked)} /> Fshih të anuluarat</label>
        <button className="btn primary small" onClick={() => setEdit({ start: (() => { const d = new Date(date); d.setHours(Math.max(START_H, now.getHours() + 1), 0, 0, 0); return d; })() })}>+ Termin</button>
      </div>
      <ErrorBox error={err} />
      <p className="small muted">Klikoni një vend bosh për termin të ri · Tërhiqni terminin për ta zhvendosur{view === 'dite' ? ' (edhe te një mjek tjetër)' : ''}.</p>

      {appts.loading && !appts.data ? <Spinner /> : (
        <div className="cal" style={{ ['--cols' as string]: columns.length } as CSSProperties}>
          <div className="cal-head">
            <div className="cal-gutter" />
            {columns.map(c => (
              <div key={c.key} className={`cal-col-head ${view === 'jave' && sameDay(c.date, now) ? 'today' : ''}`}>
                <b>{c.title}</b>{c.sub && <span>{c.sub}</span>}
                <span className="cal-count">{inColumn(c).length}</span>
              </div>
            ))}
          </div>
          <div className="cal-body" style={{ height: (END_H - START_H) * 60 * PPM }}>
            <div className="cal-gutter">
              {hours.map(h => <div key={h} className="cal-hour" style={{ height: 60 * PPM }}>{String(h).padStart(2, '0')}:00</div>)}
            </div>
            {columns.map(c => (
              <div key={c.key} className="cal-col" onClick={e => onEmptyClick(e, c)}
                onDragOver={e => { e.preventDefault(); e.dataTransfer.dropEffect = 'move'; }} onDrop={e => onDrop(e, c)}>
                {hours.map(h => <div key={h} className="cal-line" style={{ top: (h - START_H) * 60 * PPM }} />)}
                {sameDay(c.date, now) && nowTop > 0 && nowTop < (END_H - START_H) * 60 * PPM && <div className="cal-now" style={{ top: nowTop }} />}
                {layout(inColumn(c)).map(({ a, lane, lanes }) => {
                  const st = new Date(a.startsAt);
                  const top = (minutesOf(st) - START_H * 60) * PPM;
                  return (
                    <div key={a.id} className={`cal-evt st-${a.status} ${a.requestedByClient && a.status === 'Planifikuar' ? 'req' : ''}`}
                      draggable
                      onDragStart={e => { drag.current = { id: a.id, offsetY: e.nativeEvent.offsetY }; e.dataTransfer.effectAllowed = 'move'; e.dataTransfer.setData('text/plain', a.id); }}
                      onClick={e => { e.stopPropagation(); setSelected(a); }}
                      style={{ top: Math.max(0, top), height: Math.max(20, a.durationMinutes * PPM - 2), left: `${(lane / lanes) * 100}%`, width: `calc(${100 / lanes}% - 3px)` }}
                      title={`${fmtTime(a.startsAt)} ${a.patientName} – ${a.serviceName ?? ''}`}>
                      <b>{fmtTime(a.startsAt)}{' '}
                        <span className="cal-name" title="Hap kartelën e pacientit"
                          onClick={e => { e.stopPropagation(); nav(`/pacientet/${a.patientId}`); }}>{a.patientName}</span>
                      </b>
                      {a.durationMinutes >= 25 && <span>{a.serviceName ?? a.notes ?? ''}{view === 'jave' && a.staffName ? ` · ${a.staffName}` : ''}</span>}
                      {a.reminderSentAt && <i className="cal-bell" title="Kujtesa u dërgua">🔔</i>}
                    </div>
                  );
                })}
              </div>
            ))}
          </div>
        </div>
      )}

      {selected && (
        <Modal title={selected.patientName} onClose={() => setSelected(null)}>
          <Link className="patient-link" to={`/pacientet/${selected.patientId}`}>👤 {selected.patientName} – hap kartelën e pacientit →</Link>
          <dl className="dl compact">
            <dt>Ora</dt><dd>{fmtDateTime(selected.startsAt)} · {selected.durationMinutes} min</dd>
            <dt>Shërbimi</dt><dd>{selected.serviceName ?? '—'}</dd>
            <dt>{business?.doctorLabel ?? 'Stafi'}</dt><dd>{selected.staffName ?? '—'}</dd>
            <dt>Telefoni</dt><dd>{selected.patientPhone ?? '—'}</dd>
            {selected.notes && <><dt>Shënime</dt><dd>{selected.notes}</dd></>}
            <dt>Statusi</dt><dd><Badge>{selected.statusLabel}</Badge>{selected.requestedByClient && <> <Badge tone="blue">Nga aplikacioni</Badge></>}</dd>
            {selected.reminderSentAt && <><dt>Kujtesa</dt><dd>🔔 {fmtDateTime(selected.reminderSentAt)} · {reminderChannelLabel(selected.reminderChannel)}</dd></>}
          </dl>
          <div className="row gap" style={{ flexWrap: 'wrap' }}>
            {(Object.keys(statusLabels) as AppointmentStatus[]).filter(s => s !== selected.status).map(s => (
              <button key={s} className="btn ghost small" onClick={() => setStatus(selected, s)}>{statusLabels[s]}</button>
            ))}
          </div>
          <div className="modal-actions">
            <Link className="btn ghost" to={`/pacientet/${selected.patientId}`}>Kartela</Link>
            {hasFeature('reminders') && <button className="btn ghost" onClick={() => { setRemind(selected); setSelected(null); }}>🔔 Kujtesë</button>}
            <button className="btn primary" onClick={() => { setEdit({ appt: selected }); setSelected(null); }}>Ndrysho</button>
          </div>
        </Modal>
      )}
      {edit && (
        <AppointmentModal appt={edit.appt} defaultStart={edit.start} defaultStaffId={edit.staffId}
          onClose={() => setEdit(null)} onSaved={() => { setEdit(null); appts.reload(); onChanged?.(); }} />
      )}
      {remind && <ReminderModal appt={remind} onClose={() => setRemind(null)} onSent={() => appts.reload()} />}
    </div>
  );
}

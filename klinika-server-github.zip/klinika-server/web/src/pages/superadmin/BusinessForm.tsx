import { useEffect, useState, type FormEvent } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { api } from '../../api/client';
import type { Business, FeatureInfo, Specialty, SpecialtyInfo } from '../../api/types';
import { Badge } from '../../components/ui';
import { Card, ErrorBox, Field, Spinner, clean, useAsync, useForm } from '../../components/ui';
import { fmtMoney } from '../../sq';

const empty = {
  name: '', specialty: 'MjekFamiljes' as Specialty, nipt: '', address: '', city: '', phone: '', email: '',
  currency: 'EUR', accessUntil: '', maxStaff: '20', notes: '',
  adminFullName: '', adminEmail: '', adminPassword: '', seedDefaultServices: true,
  features: ['client_portal', 'online_booking'] as string[],
};

/** Regjistrimi / ndryshimi i një biznesi. Zgjidhni specialitetin dhe sistemi përgatit gjithçka. */
export default function BusinessForm() {
  const { id } = useParams();
  const editing = !!id;
  const nav = useNavigate();
  const specs = useAsync(() => api.get<SpecialtyInfo[]>('/api/specialties'));
  const featureCatalog = useAsync(() => api.get<FeatureInfo[]>('/api/superadmin/features'));
  const { values, bind, set, setValues } = useForm(empty);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!id) return;
    api.get<Business>(`/api/superadmin/businesses/${id}`).then(b => setValues({
      ...empty, name: b.name, specialty: b.specialty, nipt: b.nipt ?? '', address: b.address ?? '', city: b.city ?? '',
      phone: b.phone ?? '', email: b.email ?? '', currency: b.currency, accessUntil: b.accessUntil?.slice(0, 10) ?? '',
      maxStaff: String(b.maxStaff), notes: b.notes ?? '',
    })).catch(e => setError(e.message));
  }, [id, setValues]);

  const spec = specs.data?.find(s => s.value === values.specialty);

  const genPassword = () => {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789';
    const p = Array.from(crypto.getRandomValues(new Uint32Array(10)), n => chars[n % chars.length]).join('');
    set('adminPassword', p + '!7');
  };

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true); setError(null);
    const body = clean({ ...values, maxStaff: Number(values.maxStaff) || 20, accessUntil: values.accessUntil ? `${values.accessUntil}T23:59:59Z` : '' });
    try {
      const b = editing
        ? await api.put<Business>(`/api/superadmin/businesses/${id}`, body)
        : await api.post<Business>('/api/superadmin/businesses', body);
      nav(`/sa/bizneset/${b.id}`, { state: editing ? undefined : { created: true, email: values.adminEmail, password: values.adminPassword } });
    } catch (err: any) { setError(err.message); } finally { setBusy(false); }
  };

  if (specs.loading) return <Spinner />;

  return (
    <div className="page">
      <h1>{editing ? 'Ndrysho biznesin' : 'Regjistro biznes të ri'}</h1>
      <form onSubmit={submit} className="stack">
        <ErrorBox error={error} />

        <Card title="1. Zgjidh llojin e biznesit">
          <div className="spec-grid">
            {specs.data?.map(s => (
              <button type="button" key={s.value} className={`spec ${values.specialty === s.value ? 'on' : ''}`} onClick={() => set('specialty', s.value)}>
                <b>{s.label}</b><span>{s.services.length} shërbime · {s.visitFields.length} fusha kartele</span>
              </button>
            ))}
          </div>
          {spec && (
            <div className="spec-preview">
              <div><h4>Fushat e kartelës së vizitës</h4><ul>{spec.visitFields.map(f => <li key={f.key}>{f.label}</li>)}</ul></div>
              <div><h4>Shërbimet fillestare</h4><ul>{spec.services.map(s => <li key={s.name}>{s.name} <span className="muted">— {fmtMoney(s.price, values.currency)}</span></li>)}</ul></div>
            </div>
          )}
        </Card>

        <Card title="2. Të dhënat e biznesit">
          <div className="form-grid">
            <Field label="Emri i biznesit *" full><input {...bind('name')} required maxLength={200} /></Field>
            <Field label="NIPT / Nr. fiskal"><input {...bind('nipt')} /></Field>
            <Field label="Qyteti"><input {...bind('city')} /></Field>
            <Field label="Adresa" full><input {...bind('address')} /></Field>
            <Field label="Telefoni"><input {...bind('phone')} /></Field>
            <Field label="Email"><input type="email" {...bind('email')} /></Field>
            <Field label="Monedha">
              <select {...bind('currency')}><option value="EUR">EUR (€)</option><option value="ALL">ALL (Lekë)</option><option value="MKD">MKD (Denarë)</option><option value="USD">USD ($)</option></select>
            </Field>
            <Field label="Numri maksimal i stafit"><input type="number" min={1} {...bind('maxStaff')} /></Field>
            <Field label="Qasja deri më (bosh = pa afat)"><input type="date" {...bind('accessUntil')} /></Field>
            <Field label="Shënime të brendshme" full><textarea rows={2} {...bind('notes')} /></Field>
          </div>
        </Card>

        {!editing && (
          <Card title="3. Llogaria e Administratorit">
            <p className="muted">Ky person do të hyjë në panel dhe do të shtojë stafin dhe pacientët e vet.</p>
            <div className="form-grid">
              <Field label="Emri i plotë *"><input {...bind('adminFullName')} required placeholder="p.sh. Dr. Arben Hoxha" /></Field>
              <Field label="Email-i i hyrjes *"><input type="email" {...bind('adminEmail')} required /></Field>
              <Field label="Fjalëkalimi fillestar * (min. 8, shkronja + numra)">
                <div className="row gap"><input {...bind('adminPassword')} required minLength={8} /><button type="button" className="btn ghost" onClick={genPassword}>Gjenero</button></div>
              </Field>
              <label className="check"><input type="checkbox" checked={values.seedDefaultServices} onChange={e => set('seedDefaultServices', e.target.checked)} /> Shto shërbimet fillestare të specialitetit</label>
            </div>
          </Card>
        )}

        {!editing && (
          <Card title="4. Modulet shtesë për këtë klinikë">
            <p className="muted small">Mund t'i ndryshoni kurdoherë më vonë te faqja e biznesit – vetëm për këtë klinikë.</p>
            <div className="feature-list">
              {featureCatalog.data?.map(f => (
                <label key={f.key} className={`feature ${values.features.includes(f.key) ? 'on' : ''}`}>
                  <input type="checkbox" checked={values.features.includes(f.key)}
                    onChange={() => set('features', values.features.includes(f.key) ? values.features.filter(x => x !== f.key) : [...values.features, f.key])} />
                  <div>
                    <div className="row gap"><b>{f.label}</b>{f.recommendedFor.includes(values.specialty) && <Badge tone="blue">Rekomanduar</Badge>}</div>
                    <div className="small muted">{f.description}</div>
                  </div>
                </label>
              ))}
            </div>
          </Card>
        )}

        <div className="row gap">
          <button className="btn primary" disabled={busy}>{busy ? 'Duke ruajtur…' : editing ? 'Ruaj ndryshimet' : 'Regjistro dhe jep qasje'}</button>
          <button type="button" className="btn ghost" onClick={() => nav(-1)}>Anulo</button>
        </div>
      </form>
    </div>
  );
}

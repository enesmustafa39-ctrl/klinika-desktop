import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { api, assetUrl, qs } from '../../api/client';
import type { Business, SpecialtyInfo } from '../../api/types';
import { Badge, Card, Empty, ErrorBox, Spinner, useAsync } from '../../components/ui';
import { fmtDate } from '../../sq';

export default function Businesses() {
  const nav = useNavigate();
  const [q, setQ] = useState('');
  const [specialty, setSpecialty] = useState('');
  const [active, setActive] = useState('');
  const specs = useAsync(() => api.get<SpecialtyInfo[]>('/api/specialties'));
  const list = useAsync(() => api.get<Business[]>(`/api/superadmin/businesses${qs({ q, specialty, active })}`), [q, specialty, active]);

  return (
    <div className="page">
      <div className="page-head">
        <h1>Bizneset</h1>
        <Link className="btn primary" to="/sa/bizneset/i-ri">+ Regjistro biznes</Link>
      </div>
      <Card>
        <div className="toolbar">
          <input className="search" placeholder="Kërko sipas emrit, email-it të adminit, qytetit, NIPT…" value={q} onChange={e => setQ(e.target.value)} />
          <select value={specialty} onChange={e => setSpecialty(e.target.value)}>
            <option value="">Të gjitha specialitetet</option>
            {specs.data?.map(s => <option key={s.value} value={s.value}>{s.label}</option>)}
          </select>
          <select value={active} onChange={e => setActive(e.target.value)}>
            <option value="">Çdo status</option>
            <option value="true">Aktive</option>
            <option value="false">Të pezulluara</option>
          </select>
        </div>
        <ErrorBox error={list.error} />
        {list.loading ? <Spinner /> : !list.data?.length ? <Empty>Nuk ka biznese.</Empty> : (
          <table className="table hover">
            <thead><tr><th>Biznesi</th><th>Specialiteti</th><th>Qyteti</th><th className="num">Stafi</th><th className="num">Pacientë</th><th>Qasja deri</th><th>Statusi</th></tr></thead>
            <tbody>
              {list.data.map(b => (
                <tr key={b.id} onClick={() => nav(`/sa/bizneset/${b.id}`)}>
                  <td><div className="row gap">{b.logoUrl && <img className="brand-logo sm" src={assetUrl(b.logoUrl)} alt="" />}<b>{b.name}</b></div><div className="muted small">{b.adminEmail ?? b.email}</div>{b.features.includes('imaging') && <Badge tone="blue">Rrezet X</Badge>}</td>
                  <td>{b.specialtyLabel}</td>
                  <td>{b.city ?? '—'}</td>
                  <td className="num">{b.staffCount}/{b.maxStaff}</td>
                  <td className="num">{b.patientCount}</td>
                  <td>{b.accessUntil ? fmtDate(b.accessUntil) : 'Pa afat'}</td>
                  <td>{b.isActive ? <Badge tone="green">Aktiv</Badge> : <Badge tone="red">Pezulluar</Badge>}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </Card>
    </div>
  );
}

import { useState } from 'react';
import { api, assetUrl } from '../../api/client';
import type { Business, BusinessBrief } from '../../api/types';
import { Card, ErrorBox } from '../../components/ui';

type Kind = 'logo' | 'background';

/**
 * Logo dhe foto e sfondit të klinikës. Vetëm Super Admini i ngarkon;
 * administratori, stafi dhe pacientët e kësaj klinike i shohin pas rifreskimit.
 */
export default function BrandingCard({ b, onChanged }: { b: Business; onChanged: (patch: Partial<Business>) => void }) {
  const [busy, setBusy] = useState<Kind | null>(null);
  const [err, setErr] = useState<string | null>(null);

  const upload = async (kind: Kind, file?: File) => {
    if (!file) return;
    setBusy(kind); setErr(null);
    const form = new FormData();
    form.append('file', file);
    try {
      const r = await api.upload<BusinessBrief>(`/api/superadmin/businesses/${b.id}/branding/${kind}`, form);
      onChanged({ logoUrl: r.logoUrl, backgroundUrl: r.backgroundUrl });
    } catch (e: any) { setErr(e.message); } finally { setBusy(null); }
  };

  const remove = async (kind: Kind) => {
    if (!confirm(kind === 'logo' ? 'Të hiqet logo?' : 'Të hiqet foto e sfondit?')) return;
    setBusy(kind); setErr(null);
    try {
      const r = await api.del<BusinessBrief>(`/api/superadmin/businesses/${b.id}/branding/${kind}`);
      onChanged({ logoUrl: r.logoUrl, backgroundUrl: r.backgroundUrl });
    } catch (e: any) { setErr(e.message); } finally { setBusy(null); }
  };

  const slot = (kind: Kind, title: string, hint: string, url?: string | null) => (
    <div className="brand-slot">
      <h4>{title}</h4>
      <div className={`brand-preview ${kind}`}>
        {url ? <img src={assetUrl(url)} alt={title} /> : <span className="muted small">Nuk ka {kind === 'logo' ? 'logo' : 'sfond'}</span>}
      </div>
      <p className="small muted">{hint}</p>
      <div className="row gap">
        <label className={`btn ${url ? 'ghost' : 'primary'} small`}>
          {busy === kind ? 'Duke ngarkuar…' : url ? 'Ndrysho' : 'Ngarko'}
          <input type="file" accept="image/png,image/jpeg,image/webp,image/gif" hidden disabled={busy !== null}
            onChange={e => { upload(kind, e.target.files?.[0]); e.target.value = ''; }} />
        </label>
        {url && <button className="btn danger ghost small" disabled={busy !== null} onClick={() => remove(kind)}>Hiq</button>}
      </div>
    </div>
  );

  return (
    <Card title="Logo & sfondi i klinikës">
      <p className="muted small">Shfaqen vetëm te <b>{b.name}</b>: në menunë anësore, në panelin kryesor, në sfondin e faqeve, në faqen e hyrjes dhe në aplikacionin mobil.</p>
      <ErrorBox error={err} />
      <div className="brand-slots">
        {slot('logo', 'Logo', 'PNG me sfond transparent, katror (p.sh. 512×512). Max 10 MB.', b.logoUrl)}
        {slot('background', 'Foto e sfondit', 'Foto horizontale (p.sh. 1920×1080) – klinika, recepsioni. Max 10 MB.', b.backgroundUrl)}
      </div>
      <LoginLink id={b.id} />
    </Card>
  );
}

/** Linku i hyrjes së klinikës: kush e hap sheh logon dhe sfondin e klinikës që para se të kyçet. */
function LoginLink({ id }: { id: string }) {
  const url = `${window.location.origin}/hyrje/${id}`;
  const [copied, setCopied] = useState(false);
  const copy = async () => {
    try { await navigator.clipboard.writeText(url); } catch { window.prompt('Kopjoni linkun:', url); return; }
    setCopied(true); setTimeout(() => setCopied(false), 2000);
  };
  return (
    <div className="login-link">
      <div className="small"><b>Linku i hyrjes së klinikës</b></div>
      <p className="muted small">Jepjani stafit të kësaj klinike. Kur e hapin, faqja e hyrjes shfaq logon dhe sfondin e klinikës që para se të kyçen. Pajisja e mban mend klinikën edhe herët e tjera.</p>
      <div className="login-link-row">
        <input readOnly value={url} onFocus={e => e.target.select()} />
        <button type="button" className="btn small" onClick={copy}>{copied ? 'U kopjua ✓' : 'Kopjo'}</button>
        <a className="btn ghost small" href={url} target="_blank" rel="noreferrer">Hap</a>
      </div>
    </div>
  );
}

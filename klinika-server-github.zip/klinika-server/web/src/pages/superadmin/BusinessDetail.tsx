import { useState } from 'react';
import { Link, useLocation, useNavigate, useParams } from 'react-router-dom';
import { api } from '../../api/client';
import type { Business, User } from '../../api/types';
import { Badge, Card, ErrorBox, Field, Modal, Spinner, useAsync } from '../../components/ui';
import { fmtDate, fmtDateTime } from '../../sq';
import FeaturesCard from './FeaturesCard';
import BrandingCard from './BrandingCard';
import { assetUrl } from '../../api/client';

export default function BusinessDetail() {
  const { id } = useParams();
  const nav = useNavigate();
  const loc = useLocation() as { state?: { created?: boolean; email?: string; password?: string } };
  const biz = useAsync(() => api.get<Business>(`/api/superadmin/businesses/${id}`), [id]);
  const users = useAsync(() => api.get<User[]>(`/api/superadmin/businesses/${id}/users`), [id]);
  const [accessOpen, setAccessOpen] = useState(false);
  const [resetUser, setResetUser] = useState<User | null>(null);
  const [delOpen, setDelOpen] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);

  if (biz.loading) return <Spinner />;
  if (!biz.data) return <ErrorBox error={biz.error} />;
  const b = biz.data;

  return (
    <div className="page">
      <div className="page-head">
        <div>
          <Link to="/sa/bizneset" className="link small">← Bizneset</Link>
          <h1 className="row gap">{b.logoUrl && <img className="brand-logo" src={assetUrl(b.logoUrl)} alt="" />}{b.name}</h1>
          <div className="row gap"><Badge tone="blue">{b.specialtyLabel}</Badge>{b.isActive ? <Badge tone="green">Aktiv</Badge> : <Badge tone="red">Pezulluar</Badge>}</div>
        </div>
        <div className="row gap">
          <Link className="btn ghost" to={`/sa/bizneset/${b.id}/ndrysho`}>Ndrysho</Link>
          <button className={`btn ${b.isActive ? 'danger' : 'primary'}`} onClick={() => setAccessOpen(true)}>{b.isActive ? 'Pezullo qasjen' : 'Aktivizo qasjen'}</button>
        </div>
      </div>

      {loc.state?.created && (
        <div className="alert success">
          Biznesi u regjistrua me sukses. Dërgojini administratorit të dhënat e hyrjes:<br />
          <b>Email:</b> {loc.state.email} &nbsp; <b>Fjalëkalimi:</b> <code>{loc.state.password}</code>
        </div>
      )}
      {msg && <div className="alert success">{msg}</div>}

      <div className="grid-2">
        <Card title="Të dhënat">
          <dl className="dl">
            <dt>Email i adminit</dt><dd>{b.adminEmail ?? '—'}</dd>
            <dt>NIPT</dt><dd>{b.nipt ?? '—'}</dd>
            <dt>Adresa</dt><dd>{[b.address, b.city].filter(Boolean).join(', ') || '—'}</dd>
            <dt>Telefoni</dt><dd>{b.phone ?? '—'}</dd>
            <dt>Email</dt><dd>{b.email ?? '—'}</dd>
            <dt>Monedha</dt><dd>{b.currency}</dd>
            <dt>Regjistruar</dt><dd>{fmtDate(b.createdAt)}</dd>
            <dt>Qasja deri</dt><dd>{b.accessUntil ? fmtDate(b.accessUntil) : 'Pa afat'}</dd>
            <dt>Stafi</dt><dd>{b.staffCount} / {b.maxStaff}</dd>
            <dt>Pacientë</dt><dd>{b.patientCount}</dd>
            {b.notes && <><dt>Shënime</dt><dd>{b.notes}</dd></>}
          </dl>
        </Card>
        <Card title="Përdoruesit e biznesit">
          {users.loading ? <Spinner /> : (
            <table className="table">
              <thead><tr><th>Emri</th><th>Roli</th><th>Hyrja e fundit</th><th /></tr></thead>
              <tbody>
                {users.data?.map(u => (
                  <tr key={u.id}>
                    <td>{u.fullName}<div className="muted small">{u.email}</div></td>
                    <td>{u.roleLabel}{!u.isActive && <> <Badge tone="red">Joaktiv</Badge></>}</td>
                    <td className="small">{fmtDateTime(u.lastLoginAt)}</td>
                    <td><button className="btn ghost small" onClick={() => setResetUser(u)}>Rivendos fjalëkalimin</button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </Card>
      </div>

      <BrandingCard b={b} onChanged={patch => biz.setData({ ...b, ...patch })} />

      <FeaturesCard key={b.id} b={b} onSaved={saved => biz.setData(saved)} />

      <Card title="Zona e rrezikut" className="danger-zone">
        <p className="muted">Fshirja heq përgjithmonë biznesin, stafin, pacientët, historikun dhe financat. Rekomandohet pezullimi.</p>
        <button className="btn danger" onClick={() => setDelOpen(true)}>Fshi biznesin</button>
      </Card>

      {accessOpen && <AccessModal b={b} onClose={() => setAccessOpen(false)} onDone={m => { setMsg(m); setAccessOpen(false); biz.reload(); }} />}
      {resetUser && <ResetModal u={resetUser} onClose={() => setResetUser(null)} onDone={m => { setMsg(m); setResetUser(null); }} />}
      {delOpen && <DeleteModal b={b} onClose={() => setDelOpen(false)} onDone={() => nav('/sa/bizneset')} />}
    </div>
  );
}

function AccessModal({ b, onClose, onDone }: { b: Business; onClose: () => void; onDone: (m: string) => void }) {
  const [until, setUntil] = useState(b.accessUntil?.slice(0, 10) ?? '');
  const [err, setErr] = useState<string | null>(null);
  const activate = !b.isActive;
  const go = async () => {
    try {
      const r = await api.post<{ message: string }>(`/api/superadmin/businesses/${b.id}/access`, {
        isActive: activate, accessUntil: until ? `${until}T23:59:59Z` : null,
      });
      onDone(r.message);
    } catch (e: any) { setErr(e.message); }
  };
  return (
    <Modal title={activate ? 'Aktivizo qasjen' : 'Pezullo qasjen'} onClose={onClose}>
      <ErrorBox error={err} />
      {activate
        ? <Field label="Qasja deri më (bosh = pa afat)" full><input type="date" value={until} onChange={e => setUntil(e.target.value)} /></Field>
        : <p>I gjithë stafi dhe klientët e <b>{b.name}</b> nuk do të mund të hyjnë derisa ta aktivizoni përsëri. Të dhënat ruhen.</p>}
      <div className="modal-actions"><button className="btn ghost" onClick={onClose}>Anulo</button><button className={`btn ${activate ? 'primary' : 'danger'}`} onClick={go}>Konfirmo</button></div>
    </Modal>
  );
}

function ResetModal({ u, onClose, onDone }: { u: User; onClose: () => void; onDone: (m: string) => void }) {
  const [pwd, setPwd] = useState('');
  const [err, setErr] = useState<string | null>(null);
  const go = async () => {
    try { const r = await api.post<{ message: string }>(`/api/superadmin/users/${u.id}/reset-password`, { newPassword: pwd }); onDone(`${r.message} (${u.email})`); }
    catch (e: any) { setErr(e.message); }
  };
  return (
    <Modal title={`Rivendos fjalëkalimin – ${u.fullName}`} onClose={onClose}>
      <ErrorBox error={err} />
      <Field label="Fjalëkalimi i ri (min. 8, shkronja + numra)" full><input value={pwd} onChange={e => setPwd(e.target.value)} minLength={8} /></Field>
      <div className="modal-actions"><button className="btn ghost" onClick={onClose}>Anulo</button><button className="btn primary" disabled={pwd.length < 8} onClick={go}>Ruaj</button></div>
    </Modal>
  );
}

function DeleteModal({ b, onClose, onDone }: { b: Business; onClose: () => void; onDone: () => void }) {
  const [txt, setTxt] = useState('');
  const [err, setErr] = useState<string | null>(null);
  const go = async () => {
    try { await api.del(`/api/superadmin/businesses/${b.id}?confirm=${encodeURIComponent(txt)}`); onDone(); }
    catch (e: any) { setErr(e.message); }
  };
  return (
    <Modal title="Fshi biznesin përgjithmonë" onClose={onClose}>
      <ErrorBox error={err} />
      <p>Shkruani <b>{b.name}</b> për të konfirmuar.</p>
      <input value={txt} onChange={e => setTxt(e.target.value)} />
      <div className="modal-actions"><button className="btn ghost" onClick={onClose}>Anulo</button><button className="btn danger" disabled={txt !== b.name} onClick={go}>Fshi</button></div>
    </Modal>
  );
}

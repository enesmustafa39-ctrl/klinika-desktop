import { Link } from 'react-router-dom';
import { api } from '../../api/client';
import type { Business, PlatformStats } from '../../api/types';
import { Badge, Card, ErrorBox, Spinner, Stat, useAsync } from '../../components/ui';
import { fmtDate } from '../../sq';

export default function SaDashboard() {
  const stats = useAsync(() => api.get<PlatformStats>('/api/superadmin/stats'));
  const recent = useAsync(() => api.get<Business[]>('/api/superadmin/businesses'));

  return (
    <div className="page">
      <div className="page-head">
        <h1>Paneli i platformës</h1>
        <Link className="btn primary" to="/sa/bizneset/i-ri">+ Regjistro biznes</Link>
      </div>
      <ErrorBox error={stats.error} />
      {stats.data && (
        <div className="stats">
          <Stat label="Biznese gjithsej" value={stats.data.businesses} />
          <Stat label="Biznese aktive" value={stats.data.activeBusinesses} tone="green" />
          <Stat label="Përdorues (staf)" value={stats.data.users} />
          <Stat label="Pacientë në platformë" value={stats.data.patients} />
        </div>
      )}
      <div className="grid-2">
        <Card title="Sipas specialitetit">
          {stats.loading ? <Spinner /> : (
            <ul className="bars">
              {Object.entries(stats.data?.bySpecialty ?? {}).map(([k, v]) => (
                <li key={k}><span>{k}</span><div className="bar"><i style={{ width: `${(v / Math.max(1, stats.data!.businesses)) * 100}%` }} /></div><b>{v}</b></li>
              ))}
            </ul>
          )}
        </Card>
        <Card title="Regjistrimet e fundit" actions={<Link to="/sa/bizneset" className="link">Të gjitha →</Link>}>
          {recent.loading ? <Spinner /> : (
            <table className="table">
              <tbody>
                {recent.data?.slice(0, 6).map(b => (
                  <tr key={b.id}>
                    <td><Link to={`/sa/bizneset/${b.id}`} className="link">{b.name}</Link><div className="muted small">{b.specialtyLabel}</div></td>
                    <td>{fmtDate(b.createdAt)}</td>
                    <td>{b.isActive ? <Badge tone="green">Aktiv</Badge> : <Badge tone="red">Pezulluar</Badge>}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </Card>
      </div>
    </div>
  );
}

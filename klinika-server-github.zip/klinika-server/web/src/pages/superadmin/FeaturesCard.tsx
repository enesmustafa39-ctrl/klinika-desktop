import { useState } from 'react';
import { api } from '../../api/client';
import type { Business, FeatureInfo, FieldDef } from '../../api/types';
import { Badge, Card, ErrorBox, Spinner, useAsync } from '../../components/ui';

type FieldRow = { key: string; label: string; type: FieldDef['type']; options: string };

const typeLabels: Record<FieldDef['type'], string> = { text: 'Tekst', number: 'Numër', select: 'Listë me opsione', date: 'Datë' };

/**
 * Modulet dhe fushat shtesë VETËM për këtë biznes.
 * Ndryshimet nuk prekin asnjë biznes tjetër, edhe nëse ka të njëjtin specialitet.
 */
export default function FeaturesCard({ b, onSaved }: { b: Business; onSaved: (b: Business) => void }) {
  const catalog = useAsync(() => api.get<FeatureInfo[]>('/api/superadmin/features'));
  const [features, setFeatures] = useState<string[]>(b.features);
  const [fields, setFields] = useState<FieldRow[]>(b.customFields.map(f => ({ key: f.key, label: f.label, type: f.type, options: (f.options ?? []).join(', ') })));
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [ok, setOk] = useState(false);

  const toggle = (k: string) => { setOk(false); setFeatures(f => (f.includes(k) ? f.filter(x => x !== k) : [...f, k])); };
  const upd = (i: number, patch: Partial<FieldRow>) => { setOk(false); setFields(f => f.map((x, j) => (j === i ? { ...x, ...patch } : x))); };

  const save = async () => {
    setBusy(true); setErr(null); setOk(false);
    try {
      const saved = await api.put<Business>(`/api/superadmin/businesses/${b.id}/features`, {
        features,
        customFields: fields.filter(f => f.label.trim()).map(f => ({
          key: f.key, label: f.label, type: f.type,
          options: f.type === 'select' ? f.options.split(',').map(o => o.trim()).filter(Boolean) : null,
        })),
      });
      setFields(saved.customFields.map(f => ({ key: f.key, label: f.label, type: f.type, options: (f.options ?? []).join(', ') })));
      setOk(true);
      onSaved(saved);
    } catch (e: any) { setErr(e.message); } finally { setBusy(false); }
  };

  return (
    <Card title="Modulet & funksionet shtesë" actions={<button className="btn primary" disabled={busy} onClick={save}>{busy ? 'Duke ruajtur…' : 'Ruaj ndryshimet'}</button>}>
      <p className="muted small">
        Këto vlejnë <b>vetëm për {b.name}</b>{b.adminEmail && <> (admin: {b.adminEmail})</>}. Klinikat e tjera, edhe me të njëjtin specialitet,
        nuk ndryshojnë. Përdoruesit e shohin ndryshimin pas rifreskimit të faqes.
      </p>
      <ErrorBox error={err} />
      {ok && <div className="alert success">U ruajt. Ndryshimet vlejnë vetëm për këtë klinikë.</div>}

      {catalog.loading ? <Spinner /> : (
        <div className="feature-list">
          {catalog.data?.map(f => (
            <label key={f.key} className={`feature ${features.includes(f.key) ? 'on' : ''}`}>
              <input type="checkbox" checked={features.includes(f.key)} onChange={() => toggle(f.key)} />
              <div>
                <div className="row gap"><b>{f.label}</b>{f.recommendedFor.includes(b.specialty) && <Badge tone="blue">Rekomanduar për {b.specialtyLabel}</Badge>}</div>
                <div className="small muted">{f.description}</div>
              </div>
            </label>
          ))}
        </div>
      )}

      <h4 style={{ marginTop: 20 }}>Fusha shtesë në kartelën e vizitës</h4>
      <p className="muted small">P.sh. klinika kërkon "Ngjyra e dhëmbit (VITA)" ose "Saturimi O₂". Shfaqen te formulari i vizitës vetëm për këtë klinikë.</p>
      {fields.length > 0 && (
        <table className="table compact">
          <thead><tr><th>Emërtimi</th><th>Lloji</th><th>Opsionet (të ndara me presje)</th><th /></tr></thead>
          <tbody>
            {fields.map((f, i) => (
              <tr key={i}>
                <td><input value={f.label} onChange={e => upd(i, { label: e.target.value })} placeholder="p.sh. Ngjyra e dhëmbit" /></td>
                <td>
                  <select value={f.type} onChange={e => upd(i, { type: e.target.value as FieldDef['type'] })}>
                    {Object.entries(typeLabels).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
                  </select>
                </td>
                <td><input value={f.options} disabled={f.type !== 'select'} onChange={e => upd(i, { options: e.target.value })} placeholder={f.type === 'select' ? 'A1, A2, A3, B1' : '—'} /></td>
                <td><button className="icon-btn" title="Hiq" onClick={() => { setOk(false); setFields(x => x.filter((_, j) => j !== i)); }}>✕</button></td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
      <button className="btn ghost small" style={{ marginTop: 8 }} onClick={() => setFields(f => [...f, { key: '', label: '', type: 'text', options: '' }])}>+ Shto fushë</button>
    </Card>
  );
}

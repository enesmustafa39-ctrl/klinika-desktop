import { useState, type FormEvent } from 'react';
import { api, tokenStore } from '../api/client';
import { useAuth } from '../auth';
import { Card, Field } from '../components/ui';

export default function Profile() {
  const { user, business } = useAuth();
  const [cur, setCur] = useState('');
  const [next, setNext] = useState('');
  const [confirm, setConfirm] = useState('');
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (next !== confirm) return setMsg({ ok: false, text: 'Fjalëkalimet e reja nuk përputhen.' });
    try {
      const r = await api.post<{ message: string; token?: string }>('/api/auth/change-password', { currentPassword: cur, newPassword: next });
      if (r.token) tokenStore.replace(r.token); // seancat e tjera mbyllen, kjo vazhdon me token-in e ri
      setMsg({ ok: true, text: r.message });
      setCur(''); setNext(''); setConfirm('');
    } catch (err: any) { setMsg({ ok: false, text: err.message }); }
  };

  return (
    <div className="page narrow">
      <h1>Profili im</h1>
      <Card title="Të dhënat">
        <dl className="dl">
          <dt>Emri</dt><dd>{user?.fullName}</dd>
          <dt>Email</dt><dd>{user?.email}</dd>
          <dt>Roli</dt><dd>{user?.roleLabel}</dd>
          {business && <><dt>Biznesi</dt><dd>{business.name} · {business.specialtyLabel}</dd></>}
        </dl>
      </Card>
      <Card title="Ndrysho fjalëkalimin">
        <form className="form-grid" onSubmit={submit}>
          {msg && <div className={`alert full ${msg.ok ? 'success' : 'error'}`}>{msg.text}</div>}
          <Field label="Fjalëkalimi aktual" full><input type="password" value={cur} onChange={e => setCur(e.target.value)} required /></Field>
          <Field label="Fjalëkalimi i ri (min. 8, shkronja + numra)"><input type="password" minLength={8} value={next} onChange={e => setNext(e.target.value)} required /></Field>
          <Field label="Përsërit fjalëkalimin"><input type="password" minLength={8} value={confirm} onChange={e => setConfirm(e.target.value)} required /></Field>
          <div className="full"><button className="btn primary">Ruaj</button></div>
        </form>
      </Card>
    </div>
  );
}

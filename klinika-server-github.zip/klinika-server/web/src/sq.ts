// Etiketat dhe formatimi në shqip
import type { AppointmentStatus, Gender, PaymentMethod, UserRole } from './api/types';

export const roleLabels: Record<UserRole, string> = {
  SuperAdmin: 'Super Administrator', Admin: 'Administrator', Mjek: 'Mjek',
  Infermier: 'Infermier/e', Recepsion: 'Recepsionist/e', Klient: 'Klient',
};
export const statusLabels: Record<AppointmentStatus, string> = {
  Planifikuar: 'Planifikuar', Konfirmuar: 'Konfirmuar', Perfunduar: 'Përfunduar', Anuluar: 'Anuluar', NukErdhi: 'Nuk erdhi',
};
export const methodLabels: Record<PaymentMethod, string> = {
  Kesh: 'Kesh', Kartele: 'Kartelë', Transfer: 'Transfertë bankare', Sigurim: 'Sigurim shëndetësor',
};
export const genderLabels: Record<Gender, string> = { Mashkull: 'Mashkull', Femer: 'Femër', Tjeter: 'Tjetër' };

const months = ['janar', 'shkurt', 'mars', 'prill', 'maj', 'qershor', 'korrik', 'gusht', 'shtator', 'tetor', 'nëntor', 'dhjetor'];
const days = ['E diel', 'E hënë', 'E martë', 'E mërkurë', 'E enjte', 'E premte', 'E shtunë'];
const pad = (n: number) => String(n).padStart(2, '0');

export const fmtDate = (s?: string | null) => {
  if (!s) return '—';
  const d = new Date(s);
  return `${pad(d.getDate())}.${pad(d.getMonth() + 1)}.${d.getFullYear()}`;
};
export const fmtDateTime = (s?: string | null) => {
  if (!s) return '—';
  const d = new Date(s);
  return `${fmtDate(s)} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
};
export const fmtTime = (s: string) => { const d = new Date(s); return `${pad(d.getHours())}:${pad(d.getMinutes())}`; };
export const fmtLongDate = (d: Date) => `${days[d.getDay()]}, ${d.getDate()} ${months[d.getMonth()]} ${d.getFullYear()}`;

export const fmtMoney = (n: number | undefined | null, currency = 'EUR') =>
  `${(n ?? 0).toLocaleString('sq-AL', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ${currency === 'EUR' ? '€' : currency}`;

/** Vlera për <input type="datetime-local"> në orën lokale. */
export const toLocalInput = (d: Date) =>
  `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
export const todayIso = () => { const d = new Date(); return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`; };

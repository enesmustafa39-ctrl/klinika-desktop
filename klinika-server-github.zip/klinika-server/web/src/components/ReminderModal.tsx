import { useEffect, useState } from 'react';
import { api } from '../api/client';
import type { Appointment, ReminderPreview } from '../api/types';
import { fmtDateTime } from '../sq';
import { ErrorBox, Modal, Spinner } from './ui';

const channelLabel: Record<string, string> = {
  whatsapp: 'WhatsApp', viber: 'Viber', sms: 'SMS', telefon: 'Telefonatë', manual: 'Manual',
  'auto-sms': 'SMS automatik', 'auto-whatsapp': 'WhatsApp automatik',
};
export const reminderChannelLabel = (c?: string | null) => (c ? channelLabel[c] ?? c : '');

/**
 * Dërgo kujtesë për terminin: me një klik në WhatsApp / Viber / SMS (pa kosto),
 * ose automatikisht nëse platforma ka ofrues SMS të konfiguruar.
 */
export default function ReminderModal({ appt, onClose, onSent }: { appt: Appointment; onClose: () => void; onSent: () => void }) {
  const [data, setData] = useState<ReminderPreview | null>(null);
  const [text, setText] = useState('');
  const [err, setErr] = useState<string | null>(null);
  const [msg, setMsg] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    api.get<ReminderPreview>(`/api/appointments/${appt.id}/reminder`)
      .then(d => { setData(d); setText(d.text); })
      .catch(e => setErr(e.message));
  }, [appt.id]);

  const mark = async (channel: string) => {
    try { await api.post(`/api/appointments/${appt.id}/reminded`, { channel }); onSent(); } catch { /* jo kritike */ }
  };

  const openWhatsApp = () => {
    if (!data?.phone) return;
    window.open(`https://wa.me/${data.phone}?text=${encodeURIComponent(text)}`, '_blank');
    mark('whatsapp');
  };
  const openViber = async () => {
    if (!data?.phone) return;
    try { await navigator.clipboard.writeText(text); setMsg('Teksti u kopjua – ngjiteni (Ctrl+V) në Viber.'); } catch { /* */ }
    window.location.href = `viber://chat?number=%2B${data.phone}`;
    mark('viber');
  };
  const openSms = () => {
    if (!data?.phone) return;
    window.location.href = `sms:+${data.phone}?body=${encodeURIComponent(text)}`;
    mark('sms');
  };
  const copy = async () => {
    try { await navigator.clipboard.writeText(text); setMsg('Teksti u kopjua.'); } catch { setErr('Kopjimi nuk u lejua nga shfletuesi.'); }
  };
  const sendAuto = async () => {
    setBusy(true); setErr(null);
    try { const r = await api.post<{ message: string }>(`/api/appointments/${appt.id}/send-reminder`); setMsg(r.message); onSent(); }
    catch (e: any) { setErr(e.message); }
    finally { setBusy(false); }
  };

  return (
    <Modal title={`Kujtesë – ${appt.patientName}`} onClose={onClose}>
      <ErrorBox error={err} />
      {msg && <div className="alert success">{msg}</div>}
      {!data && !err ? <Spinner /> : data && (
        <>
          <p className="muted small">
            Termini: <b>{fmtDateTime(appt.startsAt)}</b> · Telefoni: <b>{data.phone ? `+${data.phone}` : '— (pacienti nuk ka numër)'}</b>
            {data.sentAt && <> · Dërguar më {fmtDateTime(data.sentAt)} ({reminderChannelLabel(data.channel)})</>}
          </p>
          <label className="field full"><span>Mesazhi (mund ta ndryshoni)</span>
            <textarea rows={4} value={text} onChange={e => setText(e.target.value)} />
          </label>
          <div className="reminder-actions">
            <button className="btn wa" disabled={!data.phone} onClick={openWhatsApp}>WhatsApp</button>
            <button className="btn viber" disabled={!data.phone} onClick={openViber}>Viber</button>
            <button className="btn ghost" disabled={!data.phone} onClick={openSms}>SMS nga telefoni</button>
            <button className="btn ghost" onClick={copy}>Kopjo tekstin</button>
            <button className="btn ghost" onClick={() => { mark('telefon'); setMsg('U shënua: pacienti u njoftua me telefon.'); }}>📞 E njoftova me telefon</button>
          </div>
          {data.autoAvailable && (
            <button className="btn primary block" disabled={busy || !data.phone} onClick={sendAuto}>{busy ? 'Duke dërguar…' : 'Dërgo automatikisht tani'}</button>
          )}
          <p className="small muted">
            WhatsApp hapet në shfletues ose në aplikacion me mesazhin gati. Viber nuk lejon tekst të gatshëm, prandaj teksti kopjohet.
            SMS nga telefoni funksionon kur paneli hapet në celular.
          </p>
        </>
      )}
    </Modal>
  );
}

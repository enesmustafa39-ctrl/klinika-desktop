import type { CSSProperties } from 'react';
import { NavLink, Outlet } from 'react-router-dom';
import { assetUrl } from '../api/client';
import { useAuth } from '../auth';
import type { UserRole } from '../api/types';

interface NavItem { to: string; label: string; icon: string; roles?: UserRole[] }

const superNav: NavItem[] = [
  { to: '/sa', label: 'Paneli', icon: '◧' },
  { to: '/sa/bizneset', label: 'Bizneset', icon: '▦' },
  { to: '/sa/bizneset/i-ri', label: 'Regjistro biznes', icon: '+' },
];

const bizNav: NavItem[] = [
  { to: '/', label: 'Paneli', icon: '◧' },
  { to: '/pacientet', label: 'Pacientët', icon: '☺' },
  { to: '/terminet', label: 'Terminet', icon: '◷' },
  { to: '/financat', label: 'Financat', icon: '€', roles: ['Admin', 'Recepsion', 'Mjek'] },
  { to: '/sherbimet', label: 'Shërbimet', icon: '☰' },
  { to: '/stafi', label: 'Stafi', icon: '♙', roles: ['Admin'] },
  { to: '/cilesimet', label: 'Cilësimet', icon: '⚙', roles: ['Admin'] },
];

export default function Layout() {
  const { user, business, logout, hasRole } = useAuth();
  const isSuper = user?.role === 'SuperAdmin';
  const nav = (isSuper ? superNav : bizNav).filter(n => !n.roles || hasRole(...n.roles));

  return (
    <div className="shell">
      <aside className="sidebar">
        <div className="brand">
          {!isSuper && business?.logoUrl
            ? <img className="brand-logo" src={assetUrl(business.logoUrl)} alt={business.name} />
            : <img className="brand-logo app" src="/logo.svg" alt="Klinika" />}
          <div>
            <div className="brand-name">{isSuper ? 'KLINIKA' : business?.name}</div>
            <div className="brand-sub">{isSuper ? 'Super Administrator' : business?.specialtyLabel}</div>
          </div>
        </div>
        <nav>
          {nav.map(n => (
            <NavLink key={n.to} to={n.to} end={n.to === '/' || n.to === '/sa'} className={({ isActive }) => (isActive ? 'active' : '')}>
              <span className="nav-icon">{n.icon}</span>{n.label}
            </NavLink>
          ))}
        </nav>
        <div className="sidebar-foot">
          <NavLink to="/profili" className="me">
            <div className="avatar">{user?.fullName.split(' ').map(s => s[0]).slice(0, 2).join('')}</div>
            <div><div className="me-name">{user?.fullName}</div><div className="me-role">{user?.roleLabel}</div></div>
          </NavLink>
          <button className="btn ghost small" onClick={logout}>Dil</button>
        </div>
      </aside>
      {/* Sfondi i klinikës (ngarkuar nga Super Admini), me shtresë të lehtë që teksti të lexohet */}
      <main className={`content ${!isSuper && business?.backgroundUrl ? 'has-bg' : ''}`}
        style={!isSuper && business?.backgroundUrl ? ({ '--brand-bg': `url("${assetUrl(business.backgroundUrl)}")` } as CSSProperties) : undefined}>
        <Outlet />
      </main>
    </div>
  );
}

import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from 'react';
import { api, clinicStore, lastLogin, setUnauthorizedHandler, tokenStore } from './api/client';
import type { BusinessBrief, LoginResponse, User, UserRole } from './api/types';

interface AuthState {
  user: User | null;
  business: BusinessBrief | null;
  loading: boolean;
  login: (email: string, password: string, remember?: boolean) => Promise<User>;
  setBusiness: (b: BusinessBrief | null) => void;
  logout: () => void;
  hasRole: (...roles: UserRole[]) => boolean;
  /** A e ka biznesi aktual të aktivizuar këtë funksion (nga Super Admini)? */
  hasFeature: (key: string) => boolean;
}

const Ctx = createContext<AuthState>(null as unknown as AuthState);
export const useAuth = () => useContext(Ctx);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [business, setBusiness] = useState<BusinessBrief | null>(null);
  const [loading, setLoading] = useState(true);

  const logout = useCallback(() => {
    tokenStore.clear();
    setUser(null);
    setBusiness(null);
  }, []);

  useEffect(() => {
    setUnauthorizedHandler(logout);
    if (!tokenStore.get()) { setLoading(false); return; }
    api.get<LoginResponse>('/api/auth/me')
      .then(r => {
        setUser(r.user);
        setBusiness(r.business ?? null);
        // Përditëso logon/sfondin e ruajtur për faqen e hyrjes
        if (r.business) clinicStore.set({ id: r.business.id, name: r.business.name, logoUrl: r.business.logoUrl, backgroundUrl: r.business.backgroundUrl });
        const last = lastLogin.get();
        if (last && last.email === r.user.email)
          lastLogin.set({ ...last, businessName: r.business?.name, logoUrl: r.business?.logoUrl, backgroundUrl: r.business?.backgroundUrl });
      })
      .catch(logout)
      .finally(() => setLoading(false));
  }, [logout]);

  const login = async (email: string, password: string, remember = false) => {
    const r = await api.post<LoginResponse>('/api/auth/login', { email, password, rememberMe: remember });
    if (r.user.role === 'Klient') throw new Error('Klientët përdorin aplikacionin mobil. Ky panel është për stafin.');
    tokenStore.set(r.token, remember);
    // Kjo pajisje i përket kësaj klinike: faqja e hyrjes do të shfaqë logon dhe sfondin e saj edhe herët e tjera.
    if (r.business) clinicStore.set({ id: r.business.id, name: r.business.name, logoUrl: r.business.logoUrl, backgroundUrl: r.business.backgroundUrl });
    if (remember) {
      lastLogin.set({ email: r.user.email, businessName: r.business?.name, logoUrl: r.business?.logoUrl, backgroundUrl: r.business?.backgroundUrl });
    } else {
      lastLogin.clear();
    }
    setUser(r.user);
    setBusiness(r.business ?? null);
    return r.user;
  };

  const hasRole = (...roles: UserRole[]) => !!user && roles.includes(user.role);
  const hasFeature = (key: string) => !!business?.features?.includes(key);

  return <Ctx.Provider value={{ user, business, loading, login, logout, hasRole, hasFeature, setBusiness }}>{children}</Ctx.Provider>;
}

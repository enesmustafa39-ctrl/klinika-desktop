import type { ReactNode } from 'react';
import { Navigate, Route, Routes } from 'react-router-dom';
import { useAuth } from './auth';
import Layout from './components/Layout';
import { Spinner } from './components/ui';
import type { UserRole } from './api/types';
import Login from './pages/Login';
import Profile from './pages/Profile';
import SaDashboard from './pages/superadmin/SaDashboard';
import Businesses from './pages/superadmin/Businesses';
import BusinessForm from './pages/superadmin/BusinessForm';
import BusinessDetail from './pages/superadmin/BusinessDetail';
import Dashboard from './pages/business/Dashboard';
import Patients from './pages/business/Patients';
import PatientDetail from './pages/business/PatientDetail';
import Appointments from './pages/business/Appointments';
import Finance from './pages/business/Finance';
import Services from './pages/business/Services';
import Staff from './pages/business/Staff';
import Settings from './pages/business/Settings';
import PrintPage from './pages/print/PrintPage';

function Guard({ roles, children }: { roles: UserRole[]; children: ReactNode }) {
  const { user } = useAuth();
  if (!user) return <Navigate to="/hyrje" replace />;
  if (!roles.includes(user.role)) return <Navigate to={user.role === 'SuperAdmin' ? '/sa' : '/'} replace />;
  return <>{children}</>;
}

const STAFF: UserRole[] = ['Admin', 'Mjek', 'Infermier', 'Recepsion'];

export default function App() {
  const { user, loading } = useAuth();
  if (loading) return <div className="center-screen"><Spinner /></div>;

  return (
    <Routes>
      <Route path="/hyrje" element={user ? <Navigate to={user.role === 'SuperAdmin' ? '/sa' : '/'} replace /> : <Login />} />
      <Route path="/hyrje/:clinicId" element={user ? <Navigate to={user.role === 'SuperAdmin' ? '/sa' : '/'} replace /> : <Login />} />

      {/* Faqet e printimit (pa menunë anësore) */}
      <Route path="/printo/:kind/:id" element={<Guard roles={STAFF}><PrintPage /></Guard>} />

      <Route element={<Guard roles={['SuperAdmin', ...STAFF]}><Layout /></Guard>}>
        <Route path="/profili" element={<Profile />} />

        {/* Super Admin */}
        <Route path="/sa" element={<Guard roles={['SuperAdmin']}><SaDashboard /></Guard>} />
        <Route path="/sa/bizneset" element={<Guard roles={['SuperAdmin']}><Businesses /></Guard>} />
        <Route path="/sa/bizneset/i-ri" element={<Guard roles={['SuperAdmin']}><BusinessForm /></Guard>} />
        <Route path="/sa/bizneset/:id" element={<Guard roles={['SuperAdmin']}><BusinessDetail /></Guard>} />
        <Route path="/sa/bizneset/:id/ndrysho" element={<Guard roles={['SuperAdmin']}><BusinessForm /></Guard>} />

        {/* Biznesi (Administratori + Stafi) */}
        <Route path="/" element={<Guard roles={STAFF}><Dashboard /></Guard>} />
        <Route path="/pacientet" element={<Guard roles={STAFF}><Patients /></Guard>} />
        <Route path="/pacientet/:id" element={<Guard roles={STAFF}><PatientDetail /></Guard>} />
        <Route path="/terminet" element={<Guard roles={STAFF}><Appointments /></Guard>} />
        <Route path="/financat" element={<Guard roles={['Admin', 'Recepsion', 'Mjek']}><Finance /></Guard>} />
        <Route path="/sherbimet" element={<Guard roles={STAFF}><Services /></Guard>} />
        <Route path="/stafi" element={<Guard roles={['Admin']}><Staff /></Guard>} />
        <Route path="/cilesimet" element={<Guard roles={['Admin']}><Settings /></Guard>} />
      </Route>

      <Route path="*" element={<Navigate to={user ? (user.role === 'SuperAdmin' ? '/sa' : '/') : '/hyrje'} replace />} />
    </Routes>
  );
}

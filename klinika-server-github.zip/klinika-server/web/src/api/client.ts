const BASE = (import.meta as any).env?.VITE_API_URL ?? '';
const TOKEN_KEY = 'klinika.token';

const LAST_KEY = 'klinika.last';

/**
 * Token-i ruhet:
 *  - në localStorage kur zgjidhet "Më mbaj të kyçur" (mbetet edhe pas mbylljes së shfletuesit, 30 ditë)
 *  - në sessionStorage përndryshe (fshihet kur mbyllet shfletuesi)
 */
export const tokenStore = {
  get: () => {
    try { return localStorage.getItem(TOKEN_KEY) ?? sessionStorage.getItem(TOKEN_KEY); } catch { return null; }
  },
  set: (t: string, remember = false) => {
    try {
      localStorage.removeItem(TOKEN_KEY); sessionStorage.removeItem(TOKEN_KEY);
      (remember ? localStorage : sessionStorage).setItem(TOKEN_KEY, t);
    } catch { /* ignore */ }
  },
  clear: () => { try { localStorage.removeItem(TOKEN_KEY); sessionStorage.removeItem(TOKEN_KEY); } catch { /* ignore */ } },
  /** Zëvendëson token-in duke ruajtur vendin ku ishte (p.sh. pas ndryshimit të fjalëkalimit). */
  replace: (t: string) => {
    try { tokenStore.set(t, localStorage.getItem(TOKEN_KEY) !== null); } catch { /* ignore */ }
  },
};

/** Hyrja e fundit (email + logo/sfondi i klinikës) – vetëm kur përdoruesi zgjedh "Më mbaj të kyçur". */
export interface LastLogin { email: string; businessName?: string; logoUrl?: string | null; backgroundUrl?: string | null }
export const lastLogin = {
  get: (): LastLogin | null => { try { return JSON.parse(localStorage.getItem(LAST_KEY) ?? 'null'); } catch { return null; } },
  set: (v: LastLogin) => { try { localStorage.setItem(LAST_KEY, JSON.stringify(v)); } catch { /* ignore */ } },
  clear: () => { try { localStorage.removeItem(LAST_KEY); } catch { /* ignore */ } },
};

/** Klinika e kësaj pajisjeje (nga linku /hyrje/{id}) – që logo dhe sfondi të shfaqen në faqen e hyrjes. */
export interface ClinicBrand { id: string; name: string; logoUrl?: string | null; backgroundUrl?: string | null }
const CLINIC_KEY = 'klinika.clinic';
export const clinicStore = {
  get: (): ClinicBrand | null => { try { return JSON.parse(localStorage.getItem(CLINIC_KEY) ?? 'null'); } catch { return null; } },
  set: (v: ClinicBrand) => { try { localStorage.setItem(CLINIC_KEY, JSON.stringify(v)); } catch { /* ignore */ } },
  clear: () => { try { localStorage.removeItem(CLINIC_KEY); } catch { /* ignore */ } },
};

/** URL e plotë për skedarët publikë të API-së (p.sh. logo). */
export const assetUrl = (u?: string | null) => (u ? `${BASE}${u}` : undefined);

export class ApiError extends Error {
  constructor(public status: number, message: string) { super(message); }
}

let onUnauthorized: (() => void) | null = null;
export const setUnauthorizedHandler = (fn: () => void) => { onUnauthorized = fn; };

/** Përgjigje jo-JSON (p.sh. faqe gabimi nga proxy) nuk duhet ta prishin aplikacionin. */
function parseJson(text: string): any {
  if (!text) return undefined;
  try { return JSON.parse(text); } catch { return undefined; }
}

async function request<T>(method: string, path: string, body?: unknown): Promise<T> {
  const headers: Record<string, string> = { Accept: 'application/json' };
  const token = tokenStore.get();
  if (token) headers.Authorization = `Bearer ${token}`;
  if (body !== undefined) headers['Content-Type'] = 'application/json';

  let res: Response;
  try {
    res = await fetch(`${BASE}${path}`, { method, headers, body: body === undefined ? undefined : JSON.stringify(body) });
  } catch {
    throw new ApiError(0, 'Nuk u arrit lidhja me serverin. Kontrolloni internetin.');
  }

  if (res.status === 401 && !path.includes('/auth/login')) {
    onUnauthorized?.();
    throw new ApiError(401, 'Seanca juaj ka skaduar. Hyni përsëri.');
  }
  if (res.status === 204) return undefined as T;
  if (res.status === 429 && !path.includes('/auth/login')) throw new ApiError(429, 'Shumë kërkesa. Prisni pak dhe provoni përsëri.');

  const data = parseJson(await res.text());
  if (!res.ok) {
    let msg: string = data?.message ?? data?.title ?? `Gabim (${res.status})`;
    if (data?.errors) msg = Object.values(data.errors as Record<string, string[]>).flat().join(' ');
    throw new ApiError(res.status, msg);
  }
  return data as T;
}

/** Ngarkim skedarësh (multipart/form-data). */
async function upload<T>(path: string, form: FormData): Promise<T> {
  const headers: Record<string, string> = { Accept: 'application/json' };
  const token = tokenStore.get();
  if (token) headers.Authorization = `Bearer ${token}`;
  let res: Response;
  try { res = await fetch(`${BASE}${path}`, { method: 'POST', headers, body: form }); }
  catch { throw new ApiError(0, 'Nuk u arrit lidhja me serverin.'); }
  if (res.status === 401) { onUnauthorized?.(); throw new ApiError(401, 'Seanca juaj ka skaduar. Hyni përsëri.'); }
  if (res.status === 413) throw new ApiError(413, 'Skedarët janë shumë të mëdhenj.');
  const data = parseJson(await res.text());
  if (!res.ok) throw new ApiError(res.status, data?.message ?? data?.title ?? `Gabim (${res.status})`);
  return data as T;
}

/** Merr një skedar (p.sh. rreze X) si Blob me token-in e hyrjes. */
async function blob(path: string): Promise<Blob> {
  const token = tokenStore.get();
  const res = await fetch(`${BASE}${path}`, { headers: token ? { Authorization: `Bearer ${token}` } : {} });
  if (res.status === 401) { onUnauthorized?.(); throw new ApiError(401, 'Seanca juaj ka skaduar.'); }
  if (!res.ok) throw new ApiError(res.status, 'Skedari nuk u ngarkua.');
  return res.blob();
}

export const api = {
  upload,
  blob,
  get: <T>(p: string) => request<T>('GET', p),
  post: <T>(p: string, b?: unknown) => request<T>('POST', p, b ?? {}),
  put: <T>(p: string, b: unknown) => request<T>('PUT', p, b),
  del: <T = void>(p: string) => request<T>('DELETE', p),
};

export const qs = (o: Record<string, unknown>) => {
  const s = new URLSearchParams();
  Object.entries(o).forEach(([k, v]) => { if (v !== undefined && v !== null && v !== '') s.set(k, String(v)); });
  const r = s.toString();
  return r ? `?${r}` : '';
};

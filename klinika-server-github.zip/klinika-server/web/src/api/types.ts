export type Specialty =
  | 'Stomatologji' | 'Kardiologji' | 'Ortopedi' | 'MjekFamiljes' | 'Pediatri'
  | 'Dermatologji' | 'Oftalmologji' | 'Gjinekologji' | 'Fizioterapi' | 'Neurologji' | 'Tjeter';

export type UserRole = 'SuperAdmin' | 'Admin' | 'Mjek' | 'Infermier' | 'Recepsion' | 'Klient';
export type AppointmentStatus = 'Planifikuar' | 'Konfirmuar' | 'Perfunduar' | 'Anuluar' | 'NukErdhi';
export type PaymentMethod = 'Kesh' | 'Kartele' | 'Transfer' | 'Sigurim';
export type Gender = 'Mashkull' | 'Femer' | 'Tjeter';

export interface User {
  id: string; fullName: string; email: string; phone?: string; role: UserRole; roleLabel: string;
  title?: string; isActive: boolean; businessId?: string; patientId?: string; lastLoginAt?: string;
}
export interface BusinessBrief {
  id: string; name: string; specialty: Specialty; specialtyLabel: string; doctorLabel: string; currency: string;
  features: string[];
  logoUrl?: string | null; backgroundUrl?: string | null;
}
export interface LoginResponse { token: string; expiresAt: string; user: User; business?: BusinessBrief }

export interface FieldDef { key: string; label: string; type: 'text' | 'number' | 'select' | 'date'; options?: string[] }
export interface ServiceTemplate { name: string; category: string; price: number; durationMinutes: number }
export interface SpecialtyInfo {
  value: Specialty; label: string; doctorLabel: string; visitFields: FieldDef[]; services: ServiceTemplate[];
}

export interface Business {
  id: string; name: string; specialty: Specialty; specialtyLabel: string; nipt?: string; address?: string; city?: string;
  phone?: string; email?: string; currency: string; isActive: boolean; accessUntil?: string; maxStaff: number;
  notes?: string; createdAt: string; staffCount: number; patientCount: number;
  features: string[]; customFields: FieldDef[]; adminEmail?: string;
  logoUrl?: string | null; backgroundUrl?: string | null;
}
export interface FeatureInfo { key: string; label: string; description: string; recommendedFor: Specialty[] }

export type FileCategory = 'RrezeX' | 'OPG' | 'CBCT' | 'Ekografi' | 'Foto' | 'Dokument' | 'Tjeter';
export interface PatientFile {
  id: string; patientId: string; visitId?: string; fileName: string; contentType: string; sizeBytes: number;
  category: FileCategory; categoryLabel: string; tooth?: string; notes?: string; takenAt: string; createdAt: string;
  isImage: boolean; uploadedBy?: string;
}
export interface PlatformStats {
  businesses: number; activeBusinesses: number; users: number; patients: number; bySpecialty: Record<string, number>;
}

export interface Patient {
  id: string; firstName: string; lastName: string; fullName: string; personalNumber?: string; birthDate?: string;
  age?: number; gender?: Gender; phone?: string; email?: string; address?: string; bloodType?: string;
  allergies?: string; chronicConditions?: string; notes?: string; isArchived: boolean; createdAt: string;
  balance: number; hasPortalAccess: boolean; lastVisit?: string;
}
export type PatientInput = Omit<Patient, 'id' | 'fullName' | 'age' | 'isArchived' | 'createdAt' | 'balance' | 'hasPortalAccess' | 'lastVisit'>;

export interface Visit {
  id: string; patientId: string; patientName: string; doctorId?: string; doctorName?: string; visitDate: string;
  complaint?: string; diagnosis?: string; treatment?: string; prescription?: string; notes?: string;
  fields: Record<string, string | null>; nextVisitDate?: string; chargedAmount: number;
}

export interface ServiceItem { id: string; name: string; category?: string; price: number; durationMinutes: number; isActive: boolean }

export interface LedgerEntry {
  date: string; type: string; description: string; debit: number; credit: number; runningBalance: number; id: string;
}
export interface Statement {
  patientId: string; patientName: string; totalCharged: number; totalPaid: number; balance: number; entries: LedgerEntry[];
}
export interface Payment {
  id: string; patientId: string; patientName?: string; amount: number; method: PaymentMethod; methodLabel: string;
  date: string; reference?: string; notes?: string;
}
export interface Debtor {
  patientId: string; patientName: string; phone?: string; totalCharged: number; totalPaid: number; balance: number; lastPayment?: string;
}

export interface Appointment {
  id: string; patientId: string; patientName: string; patientPhone?: string; staffId?: string; staffName?: string;
  serviceItemId?: string; serviceName?: string; startsAt: string; durationMinutes: number; status: AppointmentStatus;
  statusLabel: string; notes?: string; requestedByClient: boolean;
  reminderSentAt?: string | null; reminderChannel?: string | null;
}

export interface Dashboard {
  patients: number; newPatientsThisMonth: number; visitsToday: number; visitsThisMonth: number; appointmentsToday: number;
  revenueThisMonth: number; chargedThisMonth: number; totalOutstanding: number; debtors: number;
  upcomingToday: Appointment[]; revenue6Months: { month: string; charged: number; paid: number }[];
}

export interface Paged<T> { items: T[]; total: number; page: number; pageSize: number }

export interface Charge {
  id: string; patientId: string; visitId?: string; description: string; quantity: number; unitPrice: number;
  discount: number; amount: number; date: string;
}

export interface BusinessInfo {
  business: BusinessBrief; address?: string; city?: string; phone?: string; email?: string; nipt?: string;
  invoiceFooter?: string; timeZone?: string; visitFields: FieldDef[];
}

export interface BusinessSettings {
  name: string; nipt?: string; address?: string; city?: string; phone?: string; email?: string; timeZone: string;
  phoneCountryCode: string; reminderHoursBefore: number; reminderTemplate: string; defaultReminderTemplate: string;
  invoiceFooter?: string; autoRemindersAvailable: boolean; autoReminderChannel: string;
}

export interface ReminderPreview {
  text: string; phone?: string; whatsAppUrl?: string; smsUrl?: string; viberUrl?: string; autoAvailable: boolean;
  sentAt?: string; channel?: string;
}

export type ToothCondition = 'Shendoshe' | 'Karies' | 'Mbushje' | 'Kurore' | 'Ure' | 'Implant' | 'Kanal' | 'Mungon' | 'PerHeqje' | 'Fraktura' | 'Tjeter';
export interface ToothRecord {
  tooth: number; condition: ToothCondition; conditionLabel: string; surfaces?: string; notes?: string; updatedAt: string; updatedBy?: string;
}

export type PlanStatus = 'Propozuar' | 'Aktiv' | 'Perfunduar' | 'Anuluar';
export interface PlanItem {
  id: string; serviceItemId?: string; description: string; tooth?: string; quantity: number; unitPrice: number;
  discount: number; amount: number; done: boolean; doneAt?: string;
}
export interface Installment { id: string; number: number; dueDate: string; amount: number; paidAt?: string; isOverdue: boolean }
export interface TreatmentPlan {
  id: string; patientId: string; patientName: string; title: string; status: PlanStatus; statusLabel: string; notes?: string;
  doctorId?: string; doctorName?: string; total: number; paid: number; remaining: number; itemsDone: number; itemsTotal: number;
  overdueCount: number; nextDueDate?: string; createdAt: string; activatedAt?: string; items: PlanItem[]; installments: Installment[];
}
export interface OverdueInstallment {
  planId: string; planTitle: string; patientId: string; patientName: string; phone?: string; installmentId: string;
  number: number; dueDate: string; amount: number; daysLate: number;
}
